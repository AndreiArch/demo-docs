---
title: Advanced filtering
slug: aMpA-advanced-filtering
createdAt: Fri Jan 23 2026 10:31:19 GMT+0000 (Coordinated Universal Time)
updatedAt: Fri Jan 23 2026 10:32:40 GMT+0000 (Coordinated Universal Time)
---

In the "faceting" section, we highlight how one can obtain available filters for a search query and apply filters to narrow down search results. For example, after searching for "shoes", a shopper may want to narrow down results by applying a filter on the color attribute and choosing a value such as red. Doing so will show only "red" shoes in the results. If at this point, the shopper chooses yet another color, e.g., blue, Klevu will now show both the "red" and the "blue" shoes. Thus, it will apply the OR operation between the values of the same attribute. If at this stage, the shopper chooses "cotton" as a material, the system will show both the red and blue shoes, but it will also ensure all products have "cotton" as a material as well. In other words, it applies the AND operation among the different types of selected attributes.

However, there comes a time when one may want to perform complex filtering operations, or in other words, advanced filtering operations. For example, you may want to show a group of shoes where the "color is red", and the "brand is NOT Adidas". You may also want to add another group of shoes to this result set. For example, where the "color is blue or black", "brand is Nike", and the "price range is between 100 and 400". As you can see, unlike the behaviour of "faceting", in our example here, we like to have one or more groups of products matching different groups of conditions for the final set of products to be returned.

It is with this intention to allow advanced filtering operations on the result set that we have introduced a new functionality called "advanced filtering" in our API.

Before the introduction of advanced filtering, if a user had requested filters to be returned or some to be applied, Klevu used to find out a set of relevant products matching the user query. It then included/excluded any products requested explicitly in this result set. It is after this stage that it calculates all possible filters to be returned and also applies the selected filters to narrow down the search results. Thus, if an explicitly added product did not match the applied filter, it would be excluded from the final result set.

With the addition of advanced filtering, Klevu now identifies a set of relevant products matching the query. It then applies advanced filtering to this. It is after this step that it includes/excludes any products requested explicitly, calculates filters based on this result set, and finally applies the selected filters to narrow down the search results. This way, if there is any filtering to be applied prior to including/excluding products explicitly, advanced filtering should be used.

:::hint{type="info"}
Please note that the advanced filtering can also be used with Category Merchandising and Recommendation APIs.
:::

The **groupCondition&#x20;**&#x6F;bject can be used for applying the advanced filtering conditions so your customers can fine-tune their results based on relevant attributes.

:::ApiMethodV2
```json
{
  "tab": "examples",
  "url": "https://{{hostname}}/cs/v2/search",
  "name": "Apply Advanced Filtering",
  "method": "POST",
  "request": {
    "pathParameters": [],
    "queryParameters": [],
    "headerParameters": [],
    "bodyDataParameters": [
      {
        "kind": "optional",
        "name": "groupOperator",
        "type": "string",
        "description": "Defining the condition of filtering. Here are the options available.\nALL_OF:This is used to filter data using AND query i.e. the search results are matching with all the attributes.\n\nANY_OF:This is used to filter data using OR query i.e. the search results are matching with at least one attributes.\n\nNONE_OF: This is used as negation AND query i.e.  when search results are matching with none of the attribute values."
      },
      {
        "kind": "optional",
        "name": "key",
        "type": "string",
        "children": [],
        "description": "The ID of the attribute to filter by, eg. color"
      },
      {
        "kind": "optional",
        "name": "valueOperator",
        "type": "string",
        "children": [],
        "description": "\t\nDefining an attribute's operation, Here are the options available.\n\nINCLUDE : This is used to include specific attribute for the filter purpose.\n\nEXCLUDE :  This is used to exclude specific attribute for the filter purpose.\n\nEXISTS: This is used to find if the specific indexed attribute value exists with product.\n\n NOT_EXISTS : This is used to find if the specific indexed attribute value does not exist at all."
      },
      {
        "kind": "optional",
        "name": "singleSelect",
        "type": "Boolean",
        "children": [],
        "description": "The behaviour when specifying multiple filters or values.\n\nIf it is set to \"true\", the products returned must have both the values.\nIf it is set to \"false\", the products returned must have at least one of the values.\n"
      },
      {
        "kind": "optional",
        "name": "excludeValuesInResult",
        "type": "Boolean",
        "children": [],
        "description": "For numeric filter like price, can be used to exclude data of the starting or ending values. For example if the range is defined as \"1200 - 1232\" in values, and excludeValuesInResult is set to true, Klevu will use range as “1201 - 1231“.\n\nThis can be used to achieve greater than or less than condition. For example,if  you want to get the products greater than price 200, the values field will be “200 - *“ and the excludeValuesInResult will be set to true."
      },
      {
        "kind": "optional",
        "name": "values",
        "type": "Array",
        "children": [],
        "description": "An array of values to filter by, eg. Red, Blue. When using range filters, specify the first value as the minimum value and the second as the max value. For example to retrieve records with prices between 60 to 80, use: \"key\": \"klevu_price\", \"values\": [60, 80]. \nTo retrieve steps of prices, for example those with values between 0-50 or 150-200, use: \"key\": \"klevu_price\", \"values\": [\"0-50\", \"150-200\"]. \n\nTo retrieve exact values, for example records with exact values 100 or 200, use: \"key\": \"klevu_price\", \"values\": [\"100-100\", \"200-200\"]. \nBy default all attributes submitted to Klevu are indexed as STRING attributes, which means they cannot be used as range filters. The product sale price field is the only exception to this rule, which is filtered using the key klevu_price. If you have explicitly requested and Klevu has approved that certain attributes be indexed as numerical attributes, you can also retrieve those as range filters."
      }
    ],
    "formDataParameters": []
  },
  "results": {
    "languages": [
      {
        "id": "r-TJAKr3_5xMIwv1KRrWj",
        "code": "{\n    \"meta\": {\n        \"qTime\": 9,\n        \"responseCode\": 200\n    },\n    \"queryResults\": [\n        {\n            \"id\": \"productSearch\",\n            \"meta\": {\n                \"qTime\": 7,\n                \"noOfResults\": 2,\n                \"totalResultsFound\": 6,\n                \"typeOfSearch\": \"WILDCARD_AND\",\n                \"offset\": 0,\n                \"debuggingInformation\": {},\n                \"notificationCode\": 1,\n                \"searchedTerm\": \"tee\",\n                \"apiKey\": \"klevu-156925593843210765\",\n                \"isPersonalised\": false\n            },\n            \"records\": [\n                {\n                    \"discount\": \"\",\n                    \"hideGroupPrices\": \"\",\n                    \"type\": \"Tees\",\n                    \"itemGroupId\": \"4384027344958\",\n                    \"freeShipping\": \"\",\n                    \"storeBaseCurrency\": \"GBP\",\n                    \"price\": \"24.00\",\n                    \"toPrice\": \"\",\n                    \"imageUrl\": \"https://cdn.shopify.com/s/files/1/0116/9457/1582/products/ws05-yellow_main_fe09e105-6b7e-4269-9b53-edc3735127ba_medium.jpg?v=1575477895\",\n                    \"currency\": \"GBP\",\n                    \"inStock\": \"yes\",\n                    \"id\": \"31366447038526\",\n                    \"imageHover\": \"\",\n                    \"sku\": \"WS05-XS-Yellow\",\n                    \"brand\": \"KKE\",\n                    \"basePrice\": \"24.0\",\n                    \"startPrice\": \"\",\n                    \"image\": \"https://cdn.shopify.com/s/files/1/0116/9457/1582/products/ws05-yellow_main_fe09e105-6b7e-4269-9b53-edc3735127ba_medium.jpg?v=1575477895\",\n                    \"deliveryInfo\": \"\",\n                    \"hideAddToCart\": \"\",\n                    \"salePrice\": \"24.0\",\n                    \"swatchesInfo\": \"\",\n                    \"weight\": \"\",\n                    \"klevu_category\": \"KLEVU_PRODUCT;Products;;Tees  @ku@kuCategory@ku@\",\n                    \"totalVariants\": 0,\n                    \"groupPrices\": \"\",\n                    \"url\": \"https://jsv2-shopify-demo.ksearchmisc.com/products/desiree-fitness-tee-yellow\",\n                    \"tags\": \"comfort, flattering fit, micro-sleeve, summer, v-neck\",\n                    \"size\": \"Medium\",\n                    \"name\": \"Desiree Fitness Tee\",\n                    \"shortDesc\": \"When you're too far to turn back, thank yourself for choosing the Desiree Fitness Tee. Its ultra-lightweight, ultra-breathable fabric wicks sweat away from your body and helps keeps you cool for the distance. • Short-Sleeves. • Performan\",\n                    \"category\": \"Tees\",\n                    \"typeOfRecord\": \"KLEVU_PRODUCT\"\n                },\n                {\n                    \"discount\": \"\",\n                    \"hideGroupPrices\": \"\",\n                    \"type\": \"Tees\",\n                    \"itemGroupId\": \"4384047759422\",\n                    \"freeShipping\": \"\",\n                    \"storeBaseCurrency\": \"GBP\",\n                    \"price\": \"24.00\",\n                    \"toPrice\": \"\",\n                    \"imageUrl\": \"https://cdn.shopify.com/s/files/1/0116/9457/1582/products/ms01-yellow_main_11be227e-034a-4bb1-ae91-ef28227d26ed_medium.jpg?v=1575478213\",\n                    \"currency\": \"GBP\",\n                    \"inStock\": \"yes\",\n                    \"id\": \"31366478200894\",\n                    \"imageHover\": \"\",\n                    \"sku\": \"MS01-XS-Yellow\",\n                    \"brand\": \"MNH\",\n                    \"basePrice\": \"24.0\",\n                    \"startPrice\": \"\",\n                    \"image\": \"https://cdn.shopify.com/s/files/1/0116/9457/1582/products/ms01-yellow_main_11be227e-034a-4bb1-ae91-ef28227d26ed_medium.jpg?v=1575478213\",\n                    \"deliveryInfo\": \"\",\n                    \"hideAddToCart\": \"\",\n                    \"salePrice\": \"24.0\",\n                    \"swatchesInfo\": \"\",\n                    \"weight\": \"\",\n                    \"klevu_category\": \"KLEVU_PRODUCT;Products;;Tees  @ku@kuCategory@ku@\",\n                    \"totalVariants\": 0,\n                    \"groupPrices\": \"\",\n                    \"url\": \"https://jsv2-shopify-demo.ksearchmisc.com/products/aero-daily-fitness-tee-yellow\",\n                    \"tags\": \"Comfort, crew-neck, machine, relaxed-fit, short-sleev, Yellow\",\n                    \"size\": \"Medium\",\n                    \"name\": \"Aero Daily Fitness Tee\",\n                    \"shortDesc\": \"Need an everyday action tee that helps keep you dry? The Aero Daily Fitness Tee is made of 100% polyester wicking knit that funnels moisture away from your skin. Don't be fooled by its classic style; this tee hides premium performance technology b\",\n                    \"category\": \"Tees\",\n                    \"typeOfRecord\": \"KLEVU_PRODUCT\"\n                }\n            ],\n            \"filters\": []\n        }\n    ]\n}",
        "language": "200",
        "customLabel": ""
      }
    ],
    "selectedLanguageId": "r-TJAKr3_5xMIwv1KRrWj"
  },
  "examples": {
    "languages": [
      {
        "id": "ckgzYslV7r8QJUVAtHyzF",
        "language": "javascript",
        "code": "{\n   \"context\":{\n      \"apiKeys\":[\n         \"klevu-156925593843210765\"\n      ]\n   },\n   \"recordQueries\":[\n      {\n         \"id\":\"productSearch\",\n         \"typeOfRequest\":\"SEARCH\",\n         \"settings\":{\n            \"typeOfRecords\":[\n               \"KLEVU_PRODUCT\"\n            ],\n            \"groupCondition\":{\n               \"groupOperator\":\"ANY_OF\",\n               \"conditions\":[\n                  {\n                     \"key\":\"klevu_price\",\n                     \"valueOperator\":\"INCLUDE\",\n                     \"singleSelect\":true,\n                     \"excludeValuesInResult\":true,\n                     \"values\":[\n                        \"20 - 25\"\n                     ]\n                  },\n                  {\n                     \"key\":\"itemGroupId\",\n                     \"valueOperator\":\"EXCLUDE\",\n                     \"singleSelect\":false,\n                     \"values\":[\n                        \"4384028262462\"\n                     ]\n                  },\n                  {\n                     \"key\":\"size\",\n                     \"valueOperator\":\"EXCLUDE\",\n                     \"singleSelect\":false,\n                     \"values\":[\n                        \"Small\",\n                        \"Large\"\n                     ]\n                  },\n                  {\n                     \"key\":\"brand\",\n                     \"valueOperator\":\"EXISTS\"\n                  },\n                  {\n                     \"key\":\"discount\",\n                     \"valueOperator\":\"NOT_EXISTS\"\n                  }\n               ]\n            },\n            \"query\":{\n               \"term\":\"tee\"\n            },\n            \"limit\":2\n         }\n      }\n   ]\n}",
        "customLabel": "Request Body (JSON)"
      },
      {
        "id": "KzctSNC3rkjgpRBccF8m9",
        "language": "php",
        "code": "<?php\n\n$curl = curl_init();\n\ncurl_setopt_array($curl, array(\n  CURLOPT_URL => 'https://eucs15v2.ksearchnet.com/cs/v2/search',\n  CURLOPT_RETURNTRANSFER => true,\n  CURLOPT_ENCODING => '',\n  CURLOPT_MAXREDIRS => 10,\n  CURLOPT_TIMEOUT => 0,\n  CURLOPT_FOLLOWLOCATION => true,\n  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,\n  CURLOPT_CUSTOMREQUEST => 'POST',\n  CURLOPT_POSTFIELDS =>'{\n    \"context\": {\n        \"apiKeys\": [\n            \"klevu-156925593843210765\"\n        ]\n    },\n    \"recordQueries\": [\n        {\n            \"id\": \"productSearch\",\n            \"typeOfRequest\": \"SEARCH\",\n            \"settings\": {\n                \"typeOfRecords\": [\n                    \"KLEVU_PRODUCT\"\n                ],\n                \"groupCondition\": {\n                    \"groupOperator\": \"ANY_OF\",\n                    \"conditions\": [\n                        {\n                            \"key\":\"klevu_price\",\n                            \"valueOperator\":\"INCLUDE\",\n                            \"singleSelect\":true,\n                            \"excludeValuesInResult\":true,\n                            \"values\":[\n                                \"20 - 25\"\n                            ]\n                        },\n                        {\n                            \"key\": \"itemGroupId\",\n                            \"valueOperator\": \"EXCLUDE\",\n                            \"singleSelect\": false, \n                            \"values\": [\n                                \"4384028262462\"\n                            ]\n                        },\n\t\t\t\t\t\t{\n\t\t\t\t\t\t \"key\":\"size\",\n\t\t\t\t\t\t \"valueOperator\":\"EXCLUDE\",\n\t\t\t\t\t\t \"singleSelect\":false,\n\t\t\t\t\t\t \"values\":[\n\t\t\t\t\t\t\t\"Small\",\n                            \"Large\"\n\t\t\t\t\t\t ]\n\t\t\t\t\t  },\n                      {\n\"key\": \"brand\",\n\"valueOperator\": \"EXISTS\"\n},\n{\n\"key\": \"discount\",\n\"valueOperator\": \"NOT_EXISTS\"\n}\n                    ]\n                },\n                \"query\": {\n                    \"term\": \"tee\"\n                },\n                \"limit\": 2\n            }\n        }\n    ]\n}',\n  CURLOPT_HTTPHEADER => array(\n    'Content-Type: application/json'\n  ),\n));\n\n$response = curl_exec($curl);\n\ncurl_close($curl);\necho $response;\n",
        "customLabel": ""
      },
      {
        "id": "0Km4dtw6lHpnb6PVYe38Z",
        "language": "javascript",
        "code": "// WARNING: For POST requests, body is set to null by browsers.\nvar data = JSON.stringify({\n  \"context\": {\n    \"apiKeys\": [\n      \"klevu-156925593843210765\"\n    ]\n  },\n  \"recordQueries\": [\n    {\n      \"id\": \"productSearch\",\n      \"typeOfRequest\": \"SEARCH\",\n      \"settings\": {\n        \"typeOfRecords\": [\n          \"KLEVU_PRODUCT\"\n        ],\n        \"groupCondition\": {\n          \"groupOperator\": \"ANY_OF\",\n          \"conditions\": [\n            {\n              \"key\": \"klevu_price\",\n              \"valueOperator\": \"INCLUDE\",\n              \"singleSelect\": true,\n              \"excludeValuesInResult\": true,\n              \"values\": [\n                \"20 - 25\"\n              ]\n            },\n            {\n              \"key\": \"itemGroupId\",\n              \"valueOperator\": \"EXCLUDE\",\n              \"singleSelect\": false,\n              \"values\": [\n                \"4384028262462\"\n              ]\n            },\n            {\n              \"key\": \"size\",\n              \"valueOperator\": \"EXCLUDE\",\n              \"singleSelect\": false,\n              \"values\": [\n                \"Small\",\n                \"Large\"\n              ]\n            },\n            {\n              \"key\": \"brand\",\n              \"valueOperator\": \"EXISTS\"\n            },\n            {\n              \"key\": \"discount\",\n              \"valueOperator\": \"NOT_EXISTS\"\n            }\n          ]\n        },\n        \"query\": {\n          \"term\": \"tee\"\n        },\n        \"limit\": 2\n      }\n    }\n  ]\n});\n\nvar xhr = new XMLHttpRequest();\nxhr.withCredentials = true;\n\nxhr.addEventListener(\"readystatechange\", function() {\n  if(this.readyState === 4) {\n    console.log(this.responseText);\n  }\n});\n\nxhr.open(\"POST\", \"https://eucs15v2.ksearchnet.com/cs/v2/search\");\nxhr.setRequestHeader(\"Content-Type\", \"application/json\");\n\nxhr.send(data);",
        "customLabel": ""
      },
      {
        "id": "KzIQNEra_BMHMph_5WFvo",
        "language": "java",
        "code": "OkHttpClient client = new OkHttpClient().newBuilder()\n  .build();\nMediaType mediaType = MediaType.parse(\"application/json\");\nRequestBody body = RequestBody.create(mediaType, \"{\\r\\n    \\\"context\\\": {\\r\\n        \\\"apiKeys\\\": [\\r\\n            \\\"klevu-156925593843210765\\\"\\r\\n        ]\\r\\n    },\\r\\n    \\\"recordQueries\\\": [\\r\\n        {\\r\\n            \\\"id\\\": \\\"productSearch\\\",\\r\\n            \\\"typeOfRequest\\\": \\\"SEARCH\\\",\\r\\n            \\\"settings\\\": {\\r\\n                \\\"typeOfRecords\\\": [\\r\\n                    \\\"KLEVU_PRODUCT\\\"\\r\\n                ],\\r\\n                \\\"groupCondition\\\": {\\r\\n                    \\\"groupOperator\\\": \\\"ANY_OF\\\",\\r\\n                    \\\"conditions\\\": [\\r\\n                        {\\r\\n                            \\\"key\\\":\\\"klevu_price\\\",\\r\\n                            \\\"valueOperator\\\":\\\"INCLUDE\\\",\\r\\n                            \\\"singleSelect\\\":true,\\r\\n                            \\\"excludeValuesInResult\\\":true,\\r\\n                            \\\"values\\\":[\\r\\n                                \\\"20 - 25\\\"\\r\\n                            ]\\r\\n                        },\\r\\n                        {\\r\\n                            \\\"key\\\": \\\"itemGroupId\\\",\\r\\n                            \\\"valueOperator\\\": \\\"EXCLUDE\\\",\\r\\n                            \\\"singleSelect\\\": false, \\r\\n                            \\\"values\\\": [\\r\\n                                \\\"4384028262462\\\"\\r\\n                            ]\\r\\n                        },\\r\\n\\t\\t\\t\\t\\t\\t{\\r\\n\\t\\t\\t\\t\\t\\t \\\"key\\\":\\\"size\\\",\\r\\n\\t\\t\\t\\t\\t\\t \\\"valueOperator\\\":\\\"EXCLUDE\\\",\\r\\n\\t\\t\\t\\t\\t\\t \\\"singleSelect\\\":false,\\r\\n\\t\\t\\t\\t\\t\\t \\\"values\\\":[\\r\\n\\t\\t\\t\\t\\t\\t\\t\\\"Small\\\",\\r\\n                            \\\"Large\\\"\\r\\n\\t\\t\\t\\t\\t\\t ]\\r\\n\\t\\t\\t\\t\\t  },\\r\\n                      {\\r\\n\\\"key\\\": \\\"brand\\\",\\r\\n\\\"valueOperator\\\": \\\"EXISTS\\\"\\r\\n},\\r\\n{\\r\\n\\\"key\\\": \\\"discount\\\",\\r\\n\\\"valueOperator\\\": \\\"NOT_EXISTS\\\"\\r\\n}\\r\\n                    ]\\r\\n                },\\r\\n                \\\"query\\\": {\\r\\n                    \\\"term\\\": \\\"tee\\\"\\r\\n                },\\r\\n                \\\"limit\\\": 2\\r\\n            }\\r\\n        }\\r\\n    ]\\r\\n}\");\nRequest request = new Request.Builder()\n  .url(\"https://eucs15v2.ksearchnet.com/cs/v2/search\")\n  .method(\"POST\", body)\n  .addHeader(\"Content-Type\", \"application/json\")\n  .build();\nResponse response = client.newCall(request).execute();",
        "customLabel": ""
      },
      {
        "id": "zhIqFphBHfQcSzStcYLq_",
        "language": "nodejs",
        "code": "var request = require('request');\nvar options = {\n  'method': 'POST',\n  'url': 'https://eucs15v2.ksearchnet.com/cs/v2/search',\n  'headers': {\n    'Content-Type': 'application/json'\n  },\n  body: JSON.stringify({\n    \"context\": {\n      \"apiKeys\": [\n        \"klevu-156925593843210765\"\n      ]\n    },\n    \"recordQueries\": [\n      {\n        \"id\": \"productSearch\",\n        \"typeOfRequest\": \"SEARCH\",\n        \"settings\": {\n          \"typeOfRecords\": [\n            \"KLEVU_PRODUCT\"\n          ],\n          \"groupCondition\": {\n            \"groupOperator\": \"ANY_OF\",\n            \"conditions\": [\n              {\n                \"key\": \"klevu_price\",\n                \"valueOperator\": \"INCLUDE\",\n                \"singleSelect\": true,\n                \"excludeValuesInResult\": true,\n                \"values\": [\n                  \"20 - 25\"\n                ]\n              },\n              {\n                \"key\": \"itemGroupId\",\n                \"valueOperator\": \"EXCLUDE\",\n                \"singleSelect\": false,\n                \"values\": [\n                  \"4384028262462\"\n                ]\n              },\n              {\n                \"key\": \"size\",\n                \"valueOperator\": \"EXCLUDE\",\n                \"singleSelect\": false,\n                \"values\": [\n                  \"Small\",\n                  \"Large\"\n                ]\n              },\n              {\n                \"key\": \"brand\",\n                \"valueOperator\": \"EXISTS\"\n              },\n              {\n                \"key\": \"discount\",\n                \"valueOperator\": \"NOT_EXISTS\"\n              }\n            ]\n          },\n          \"query\": {\n            \"term\": \"tee\"\n          },\n          \"limit\": 2\n        }\n      }\n    ]\n  })\n\n};\nrequest(options, function (error, response) {\n  if (error) throw new Error(error);\n  console.log(response.body);\n});\n",
        "customLabel": ""
      }
    ],
    "selectedLanguageId": "ckgzYslV7r8QJUVAtHyzF"
  },
  "description": "Example is as below:",
  "currentNewParameter": {
    "label": "Body Parameter",
    "value": "bodyDataParameters"
  },
  "hasTryItOut": false
}
```
:::

:::Iframe{code="<iframe src=&#x22;https://codesandbox.io/embed/klevu-api-sendbox-4ktfrp?fontsize=14&hidenavigation=0&theme=dark&view=preview&initialpath=?payload=advanceFiltering&#x22;&#xD;&#xA;     style=&#x22;width:100%; height:550px; border:0; border-radius: 4px; overflow:hidden;&#x22;&#xD;&#xA;     title=&#x22;klevu_api sendbox&#x22;&#xD;&#xA;     allow=&#x22;accelerometer; ambient-light-sensor; camera; encrypted-media; geolocation; gyroscope; hid; microphone; midi; payment; usb; vr; xr-spatial-tracking&#x22;&#xD;&#xA;     sandbox=&#x22;allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts&#x22;&#xD;&#xA;     &#xD;&#xA;   ></iframe>" iframeHeight="550"}

:::

