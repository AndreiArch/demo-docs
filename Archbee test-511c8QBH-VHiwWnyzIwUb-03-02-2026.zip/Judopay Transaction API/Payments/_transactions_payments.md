---
title: /transactions/payments
createdAt: Tue Feb 03 2026 08:50:33 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "XIxA_56oUy_enW7NkKpoP",
  "type": "api-oas-v2",
  "data": {
    "method": "POST",
    "url": "https://api-sandbox.judopay.com/transactions/payments",
    "servers": [
      {
        "url": "https://api-sandbox.judopay.com/transactions/payments",
        "description": "Sandbox environment"
      }
    ],
    "name": "",
    "description": "<p><strong>Note</strong> To reduce your PCI scope, you can store a card token instead of the card number.  The card token is a randomly generated string linked to a card saved securely within the Judopay Card Vault. You can also use a card token to pre-authorise repeat payments without the consumer having to re-enter their details.</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [
        {
          "kind": "required",
          "name": "Api-Version",
          "type": "string",
          "example": "6.23",
          "description": "The version of this API."
        }
      ],
      "queryParameters": [],
      "bodyDataParameters": [
        {
          "kind": "required",
          "name": "body",
          "type": "object",
          "description": "Request can be sent with\n  * full card details,\n  * a cardToken generated with a call to [POST /transactions/savecard](), or\n  * wallet details from Apple Pay or Google Pay\n",
          "schema": [],
          "complexItems": [
            {
              "name": "object",
              "schema": [
                {
                  "name": "cardNumber",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. The unique number printed on a credit card (13 to 19 digits depending on card type).  Submitted without whitespace or non-numeric characters.",
                  "example": 1234567890123456
                },
                {
                  "name": "cv2",
                  "kind": "optional",
                  "type": "string",
                  "description": "The 3 or 4 digit number on the back of a credit card. Also known as the card verification value (CVV) or security code.  If not specified, contact Judopay support to confirm gateway settings are configured to reflect this.",
                  "example": "123"
                },
                {
                  "name": "expiryDate",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. The expiry date of the card in format MM/YY",
                  "example": "01/28"
                },
                {
                  "name": "startDate",
                  "kind": "optional",
                  "type": "string",
                  "description": "For Maestro cards only, start date in format MM/YY",
                  "example": "07/20"
                },
                {
                  "name": "cardAddress",
                  "kind": "optional",
                  "type": "object",
                  "description": "",
                  "modelRef": "#/components/schemas/cardAddressRequestAttributes",
                  "customType": "cardAddressRequestAttributes",
                  "schema": [],
                  "complexType": "allOf",
                  "complexItems": [
                    {
                      "name": "cardAddressCommonAttributes",
                      "description": "",
                      "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                      "schema": [
                        {
                          "name": "address1",
                          "kind": "optional",
                          "type": "string",
                          "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder House"
                        },
                        {
                          "name": "address2",
                          "kind": "optional",
                          "type": "string",
                          "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "1 CardHolder Street"
                        },
                        {
                          "name": "town",
                          "kind": "optional",
                          "type": "string",
                          "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder Town"
                        },
                        {
                          "name": "postCode",
                          "kind": "required",
                          "type": "string",
                          "description": "Postcode of the card holder's address.",
                          "example": "AB1 2CD"
                        },
                        {
                          "name": "state",
                          "kind": "optional",
                          "type": "string",
                          "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                          "example": "FL"
                        }
                      ]
                    },
                    {
                      "name": "object",
                      "description": "",
                      "schema": [
                        {
                          "name": "countryCode",
                          "kind": "optional",
                          "type": "string",
                          "description": "ISO 3166-1 (3 digit) country code of the card holder's address.",
                          "example": "826"
                        }
                      ]
                    }
                  ]
                },
                {
                  "name": "judoId",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique merchant and/or location ID supplied by Judopay.  Do not include spaces or dashes.  If not specified, then your default judoId will be used.",
                  "example": "100100100"
                },
                {
                  "name": "yourConsumerReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique reference to anonymously identify your customer.  Advisable to use GUIDs.",
                  "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                },
                {
                  "name": "yourPaymentReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Your unique reference for this payment. This value should be unique in order to protect your customers against duplicate transactions. With a server side integration, if a payment reference is not supplied, the transaction will not be processed.",
                  "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
                },
                {
                  "name": "yourPaymentMetaData",
                  "kind": "required",
                  "type": "object",
                  "description": "Optional key-value map for additional metadata associated with this transaction.   Will be stored but not processed or passed to gateways.   Do not include sensitive information like card numbers.",
                  "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                  "schema": []
                },
                {
                  "name": "currency",
                  "kind": "required",
                  "type": "string",
                  "description": "The ISO-4217 alphabetic code for the currency to use for the transaction, only required if different from the currency set during onboarding (default is GBP)",
                  "example": "GBP"
                },
                {
                  "name": "amount",
                  "kind": "required",
                  "type": "number<float>",
                  "description": "REQUIRED. The amount to process. Format for default currencies is to two decimal places.  For currencies using a different structure please contact Judopay for support.",
                  "example": 10.99
                },
                {
                  "name": "webPaymentReference",
                  "kind": "required",
                  "type": "string",
                  "description": "The unique reference of the Judopay payment session associated with this transaction.",
                  "example": "5QcAAAIAAAAMAAAADwAAAPwlgcQCLU6sLrNhi8kt1vEoVLwiFJc2EKTqT7JXb2xeQRqyYw"
                },
                {
                  "name": "clientDetails",
                  "kind": "required",
                  "type": "object",
                  "description": "A set of encrypted fraud signals sent by the mobile SDK",
                  "example": "",
                  "schema": []
                },
                {
                  "name": "initialRecurringPayment",
                  "kind": "required",
                  "type": "boolean",
                  "description": "Indicates if this is the first transaction that forms part of a recurring payment schedule. This flag should be set to 'true' if this is a customer-initiated payment which will be followed by a series of scheduled recurring payments.\n",
                  "example": false
                },
                {
                  "name": "primaryAccountDetails",
                  "kind": "required",
                  "type": "object",
                  "description": "Information about the primary account holder of the transaction.  Used for MCC 6012, MCC 6051 and MCC 7299 accounts only.  Does not need to be specified if these details were set on a payment session associated with this transaction.",
                  "example": "",
                  "schema": []
                },
                {
                  "name": "acceptHeaders",
                  "kind": "optional",
                  "type": "string",
                  "description": "Passed to ACS for use in rendering challenge screens.",
                  "example": "text/html",
                  "default": "text/html"
                },
                {
                  "name": "userAgent",
                  "kind": "optional",
                  "type": "string",
                  "description": "Passed to ACS for use in rendering challenge screens.",
                  "example": "Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
                },
                {
                  "name": "cardHolderName",
                  "kind": "optional",
                  "type": "string",
                  "description": "The full name of the card holder, required for 3DS2 authentication.  **Note:** When testing in the sandbox environment, it is the cardHolderName that is used to determine the test card for 3D Secure 2 authentication.",
                  "example": "John Doe"
                },
                {
                  "name": "emailAddress",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Email address of consumer, recommended but not required for 3DS2 authentication.",
                  "example": "test.user@judopay.com"
                },
                {
                  "name": "shippingAddress",
                  "kind": "optional",
                  "type": "object",
                  "description": "(Optional) Shipping address",
                  "example": "",
                  "schema": [
                    {
                      "name": "address1",
                      "kind": "optional",
                      "type": "string",
                      "description": "First line of the shipping address.",
                      "example": "CardHolder House"
                    },
                    {
                      "name": "address2",
                      "kind": "optional",
                      "type": "string",
                      "description": "Second line of the shipping address.",
                      "example": "1 CardHolder Street"
                    },
                    {
                      "name": "town",
                      "kind": "optional",
                      "type": "string",
                      "description": "Town of the shipping address.",
                      "example": "CardHolder Town"
                    },
                    {
                      "name": "postCode",
                      "kind": "optional",
                      "type": "string",
                      "description": "Postcode of the shipping address.",
                      "example": "AB1 2CD"
                    },
                    {
                      "name": "countryCode",
                      "kind": "optional",
                      "type": "string",
                      "description": "ISO 3166-1 (3 digit) country code of the shipping address.",
                      "example": "826"
                    },
                    {
                      "name": "isBillingAddress",
                      "kind": "optional",
                      "type": "boolean",
                      "description": "Indicator of whether the billing address is the same as the shipping address.",
                      "example": true
                    }
                  ]
                },
                {
                  "name": "mobileNumber",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Phone number of consumer, recommended for 3DS2 authentication, but not required.   Must be set if phoneCountryCode is set.",
                  "example": "7999999999"
                },
                {
                  "name": "phoneCountryCode",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Phone country code matching mobileNumber, recommended for 3DS2 authentication, but not required.   Should be set if mobileNumber is set, defaulted to 44 if not.",
                  "example": "44",
                  "default": "44"
                },
                {
                  "name": "threeDSecure",
                  "kind": "optional",
                  "type": "object",
                  "description": "",
                  "example": "",
                  "schema": [
                    {
                      "name": "authenticationSource",
                      "kind": "optional",
                      "type": "string<Browser>",
                      "description": "Type of device that will be used for challenge authentication.",
                      "example": "Browser"
                    },
                    {
                      "name": "methodNotificationUrl",
                      "kind": "optional",
                      "type": "string",
                      "description": "URL of the page that will receive a POST event after a device details call is completed.   Example is a Judo-hosted page that triggers a call to [POST /transactions/{receiptId}/resume3ds]() (which will be used if this attribute is not set)",
                      "example": "https://api.judopay.com/order/3ds/methodNotification",
                      "default": "https://api.judopay.com/order/3ds/methodNotification"
                    },
                    {
                      "name": "challengeNotificationUrl",
                      "kind": "optional",
                      "type": "string",
                      "description": "URL of the page that will receive a POST event after a challenge is completed. Example is a Judo-hosted page that triggers a call to [POST /transactions/{receiptId}/complete3ds]() (which will be used if this attribute is not set)",
                      "example": "https://api.judopay.com/order/3ds/challengeNotification",
                      "default": "https://api.judopay.com/order/3ds/challengeNotification"
                    },
                    {
                      "name": "challengeRequestIndicator",
                      "kind": "optional",
                      "type": "string",
                      "description": "Indicates whether a challenge is requested for this transaction (this may be over-ruled by the issuer).   Should not be specified in the same request as scaExemption\n",
                      "example": "challengePreferred",
                      "default": "noPreference",
                      "modelRef": "#/components/schemas/challengeRequestIndicatorRequest",
                      "customType": "challengeRequestIndicatorRequest",
                      "schema": []
                    },
                    {
                      "name": "scaExemption",
                      "kind": "optional",
                      "type": "string",
                      "description": "Indicates reason why challenge may not be necessary (this may be over-ruled by the issuer).   Should not be specified in the same request as challengeRequestIndicator\n",
                      "example": "transactionRiskAnalysis",
                      "modelRef": "#/components/schemas/scaExemptionRequest",
                      "customType": "scaExemptionRequest",
                      "schema": []
                    }
                  ]
                },
                {
                  "name": "threeDSecureMpi",
                  "kind": "optional",
                  "type": "object",
                  "description": "Optional block to pass in 3DS2 authentication results performed outside of Judopay.\n",
                  "example": "",
                  "schema": [
                    {
                      "name": "dsTransId",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Unique identifier for the authentication assigned by the Directory Server (Card Scheme).\n",
                      "example": "41aadf4c-e73f-4bd1-a0c4-acb2615a32af"
                    },
                    {
                      "name": "cavv",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Unique value for the authentication provided by the ACS. May be used to provide proof of authentication.\n",
                      "example": "AJkBCWUyZwAAAABugmKTdAAAAAA="
                    },
                    {
                      "name": "eci",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Electronic Commerce Indicator (ECI) is the value returned by Directory Servers (namely Visa, MasterCard, JCB, and American Express) indicating the outcome of authentication attempted on transactions enforced by 3DS.\n",
                      "example": "02"
                    },
                    {
                      "name": "threeDSecureVersion",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Version of 3DSecure that the card is enrolled into.\n",
                      "example": "2.2.0"
                    }
                  ]
                },
                {
                  "name": "recurringPayment",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "Indicates this transaction is not being initiated by the customer. This should be set to 'true' if the merchant is trying to initiate a scheduled (recurring) or unscheduled (MIT) transaction in the absence of the customer.\n",
                  "example": true
                },
                {
                  "name": "recurringPaymentType",
                  "kind": "optional",
                  "type": "string<RECURRING | MIT | >",
                  "description": "Indicates the type of recurring payment that the merchant is attempting to process. This can be set to 'RECURRING' (for scheduled payments) or 'MIT' (for unscheduled payments)\n",
                  "example": "MIT"
                },
                {
                  "name": "relatedReceiptId",
                  "kind": "optional",
                  "type": "string",
                  "description": "Receipt identifier of the initial payment/pre-auth transaction that was customer initiated. If recurringPayment is true and recurringPaymentType is set, setting this to the Judo receipt identifier of the initial transaction in the sequence will check that original transaction was successful and on the same account, and pass the gateway transaction identifier of the original transaction on to the gateway with this transaction\n",
                  "example": "1001131610340495360"
                },
                {
                  "name": "relatedPaymentNetworkTransactionId",
                  "kind": "optional",
                  "type": "string",
                  "description": "Card scheme identifier of the initial payment/pre-auth transaction that was customer initiated. If recurringPayment is true and recurringPaymentType is set, setting this to the card scheme identifier of the initial transaction in the sequence will pass this on on to the gateway with this transaction (no checks are made on this identifier).   Should not be specified if relatedReceiptId is specified. Only supported by certain processors. Please check with Developer Support if you intend to use this field\n",
                  "example": "MNKWQVNQS0915"
                },
                {
                  "name": "disableNetworkTokenisation",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "(Optional) Set to true to specify that network tokenisation should not be used for this transaction, even\nif network token registration has been enabled on the account.\n",
                  "example": true,
                  "default": false
                }
              ],
              "modelRef": "#/components/schemas/paymentRequestPan",
              "customType": "paymentRequestPan"
            },
            {
              "name": "object",
              "schema": [
                {
                  "name": "cardToken",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. A randomly generated string linked to a card saved securely within the Judopay Card Vault.",
                  "example": "Cw8eZ7nLBM2rFXx12WiRI0YveZPinkPm"
                },
                {
                  "name": "cv2",
                  "kind": "required",
                  "type": "string",
                  "description": "The 3 or 4 digit number on the back of a credit card. Also known as the card verification value (CVV) or security code.",
                  "example": "123"
                },
                {
                  "name": "cardAddress",
                  "kind": "required",
                  "type": "object",
                  "description": "",
                  "modelRef": "#/components/schemas/cardAddressRequestAttributes",
                  "customType": "cardAddressRequestAttributes",
                  "schema": [],
                  "complexType": "allOf",
                  "complexItems": [
                    {
                      "name": "cardAddressCommonAttributes",
                      "description": "",
                      "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                      "schema": [
                        {
                          "name": "address1",
                          "kind": "optional",
                          "type": "string",
                          "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder House"
                        },
                        {
                          "name": "address2",
                          "kind": "optional",
                          "type": "string",
                          "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "1 CardHolder Street"
                        },
                        {
                          "name": "town",
                          "kind": "optional",
                          "type": "string",
                          "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder Town"
                        },
                        {
                          "name": "postCode",
                          "kind": "required",
                          "type": "string",
                          "description": "Postcode of the card holder's address.",
                          "example": "AB1 2CD"
                        },
                        {
                          "name": "state",
                          "kind": "optional",
                          "type": "string",
                          "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                          "example": "FL"
                        }
                      ]
                    },
                    {
                      "name": "object",
                      "description": "",
                      "schema": [
                        {
                          "name": "countryCode",
                          "kind": "optional",
                          "type": "string",
                          "description": "ISO 3166-1 (3 digit) country code of the card holder's address.",
                          "example": "826"
                        }
                      ]
                    }
                  ]
                },
                {
                  "name": "judoId",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique merchant and/or location ID supplied by Judopay.  Do not include spaces or dashes.  If not specified, then your default judoId will be used.",
                  "example": "100100100"
                },
                {
                  "name": "yourConsumerReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique reference to anonymously identify your customer.  Advisable to use GUIDs.",
                  "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                },
                {
                  "name": "yourPaymentReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Your unique reference for this payment. This value should be unique in order to protect your customers against duplicate transactions. With a server side integration, if a payment reference is not supplied, the transaction will not be processed.",
                  "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
                },
                {
                  "name": "yourPaymentMetaData",
                  "kind": "required",
                  "type": "object",
                  "description": "Optional key-value map for additional metadata associated with this transaction.   Will be stored but not processed or passed to gateways.   Do not include sensitive information like card numbers.",
                  "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                  "schema": []
                },
                {
                  "name": "currency",
                  "kind": "required",
                  "type": "string",
                  "description": "The ISO-4217 alphabetic code for the currency to use for the transaction, only required if different from the currency set during onboarding (default is GBP)",
                  "example": "GBP"
                },
                {
                  "name": "amount",
                  "kind": "required",
                  "type": "number<float>",
                  "description": "REQUIRED. The amount to process. Format for default currencies is to two decimal places.  For currencies using a different structure please contact Judopay for support.",
                  "example": 10.99
                },
                {
                  "name": "webPaymentReference",
                  "kind": "required",
                  "type": "string",
                  "description": "The unique reference of the Judopay payment session associated with this transaction.",
                  "example": "5QcAAAIAAAAMAAAADwAAAPwlgcQCLU6sLrNhi8kt1vEoVLwiFJc2EKTqT7JXb2xeQRqyYw"
                },
                {
                  "name": "clientDetails",
                  "kind": "required",
                  "type": "object",
                  "description": "A set of encrypted fraud signals sent by the mobile SDK",
                  "example": "",
                  "schema": []
                },
                {
                  "name": "initialRecurringPayment",
                  "kind": "required",
                  "type": "boolean",
                  "description": "Indicates if this is the first transaction that forms part of a recurring payment schedule. This flag should be set to 'true' if this is a customer-initiated payment which will be followed by a series of scheduled recurring payments.\n",
                  "example": false
                },
                {
                  "name": "primaryAccountDetails",
                  "kind": "required",
                  "type": "object",
                  "description": "Information about the primary account holder of the transaction.  Used for MCC 6012, MCC 6051 and MCC 7299 accounts only.  Does not need to be specified if these details were set on a payment session associated with this transaction.",
                  "example": "",
                  "schema": []
                },
                {
                  "name": "acceptHeaders",
                  "kind": "optional",
                  "type": "string",
                  "description": "Passed to ACS for use in rendering challenge screens.",
                  "example": "text/html",
                  "default": "text/html"
                },
                {
                  "name": "userAgent",
                  "kind": "optional",
                  "type": "string",
                  "description": "Passed to ACS for use in rendering challenge screens.",
                  "example": "Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
                },
                {
                  "name": "cardHolderName",
                  "kind": "optional",
                  "type": "string",
                  "description": "The full name of the card holder, required for 3DS2 authentication.  **Note:** When testing in the sandbox environment, it is the cardHolderName that is used to determine the test card for 3D Secure 2 authentication.",
                  "example": "John Doe"
                },
                {
                  "name": "emailAddress",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Email address of consumer, recommended but not required for 3DS2 authentication.",
                  "example": "test.user@judopay.com"
                },
                {
                  "name": "shippingAddress",
                  "kind": "optional",
                  "type": "object",
                  "description": "(Optional) Shipping address",
                  "example": "",
                  "schema": [
                    {
                      "name": "address1",
                      "kind": "optional",
                      "type": "string",
                      "description": "First line of the shipping address.",
                      "example": "CardHolder House"
                    },
                    {
                      "name": "address2",
                      "kind": "optional",
                      "type": "string",
                      "description": "Second line of the shipping address.",
                      "example": "1 CardHolder Street"
                    },
                    {
                      "name": "town",
                      "kind": "optional",
                      "type": "string",
                      "description": "Town of the shipping address.",
                      "example": "CardHolder Town"
                    },
                    {
                      "name": "postCode",
                      "kind": "optional",
                      "type": "string",
                      "description": "Postcode of the shipping address.",
                      "example": "AB1 2CD"
                    },
                    {
                      "name": "countryCode",
                      "kind": "optional",
                      "type": "string",
                      "description": "ISO 3166-1 (3 digit) country code of the shipping address.",
                      "example": "826"
                    },
                    {
                      "name": "isBillingAddress",
                      "kind": "optional",
                      "type": "boolean",
                      "description": "Indicator of whether the billing address is the same as the shipping address.",
                      "example": true
                    }
                  ]
                },
                {
                  "name": "mobileNumber",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Phone number of consumer, recommended for 3DS2 authentication, but not required.   Must be set if phoneCountryCode is set.",
                  "example": "7999999999"
                },
                {
                  "name": "phoneCountryCode",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Phone country code matching mobileNumber, recommended for 3DS2 authentication, but not required.   Should be set if mobileNumber is set, defaulted to 44 if not.",
                  "example": "44",
                  "default": "44"
                },
                {
                  "name": "threeDSecure",
                  "kind": "optional",
                  "type": "object",
                  "description": "",
                  "example": "",
                  "schema": [
                    {
                      "name": "authenticationSource",
                      "kind": "optional",
                      "type": "string<Browser>",
                      "description": "Type of device that will be used for challenge authentication.",
                      "example": "Browser"
                    },
                    {
                      "name": "methodNotificationUrl",
                      "kind": "optional",
                      "type": "string",
                      "description": "URL of the page that will receive a POST event after a device details call is completed.   Example is a Judo-hosted page that triggers a call to [POST /transactions/{receiptId}/resume3ds]() (which will be used if this attribute is not set)",
                      "example": "https://api.judopay.com/order/3ds/methodNotification",
                      "default": "https://api.judopay.com/order/3ds/methodNotification"
                    },
                    {
                      "name": "challengeNotificationUrl",
                      "kind": "optional",
                      "type": "string",
                      "description": "URL of the page that will receive a POST event after a challenge is completed. Example is a Judo-hosted page that triggers a call to [POST /transactions/{receiptId}/complete3ds]() (which will be used if this attribute is not set)",
                      "example": "https://api.judopay.com/order/3ds/challengeNotification",
                      "default": "https://api.judopay.com/order/3ds/challengeNotification"
                    },
                    {
                      "name": "challengeRequestIndicator",
                      "kind": "optional",
                      "type": "string",
                      "description": "Indicates whether a challenge is requested for this transaction (this may be over-ruled by the issuer).   Should not be specified in the same request as scaExemption\n",
                      "example": "challengePreferred",
                      "default": "noPreference",
                      "modelRef": "#/components/schemas/challengeRequestIndicatorRequest",
                      "customType": "challengeRequestIndicatorRequest",
                      "schema": []
                    },
                    {
                      "name": "scaExemption",
                      "kind": "optional",
                      "type": "string",
                      "description": "Indicates reason why challenge may not be necessary (this may be over-ruled by the issuer).   Should not be specified in the same request as challengeRequestIndicator\n",
                      "example": "transactionRiskAnalysis",
                      "modelRef": "#/components/schemas/scaExemptionRequest",
                      "customType": "scaExemptionRequest",
                      "schema": []
                    }
                  ]
                },
                {
                  "name": "threeDSecureMpi",
                  "kind": "optional",
                  "type": "object",
                  "description": "Optional block to pass in 3DS2 authentication results performed outside of Judopay.\n",
                  "example": "",
                  "schema": [
                    {
                      "name": "dsTransId",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Unique identifier for the authentication assigned by the Directory Server (Card Scheme).\n",
                      "example": "41aadf4c-e73f-4bd1-a0c4-acb2615a32af"
                    },
                    {
                      "name": "cavv",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Unique value for the authentication provided by the ACS. May be used to provide proof of authentication.\n",
                      "example": "AJkBCWUyZwAAAABugmKTdAAAAAA="
                    },
                    {
                      "name": "eci",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Electronic Commerce Indicator (ECI) is the value returned by Directory Servers (namely Visa, MasterCard, JCB, and American Express) indicating the outcome of authentication attempted on transactions enforced by 3DS.\n",
                      "example": "02"
                    },
                    {
                      "name": "threeDSecureVersion",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Version of 3DSecure that the card is enrolled into.\n",
                      "example": "2.2.0"
                    }
                  ]
                },
                {
                  "name": "recurringPayment",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "Indicates this transaction is not being initiated by the customer. This should be set to 'true' if the merchant is trying to initiate a scheduled (recurring) or unscheduled (MIT) transaction in the absence of the customer.\n",
                  "example": true
                },
                {
                  "name": "recurringPaymentType",
                  "kind": "optional",
                  "type": "string<RECURRING | MIT | >",
                  "description": "Indicates the type of recurring payment that the merchant is attempting to process. This can be set to 'RECURRING' (for scheduled payments) or 'MIT' (for unscheduled payments)\n",
                  "example": "MIT"
                },
                {
                  "name": "relatedReceiptId",
                  "kind": "optional",
                  "type": "string",
                  "description": "Receipt identifier of the initial payment/pre-auth transaction that was customer initiated. If recurringPayment is true and recurringPaymentType is set, setting this to the Judo receipt identifier of the initial transaction in the sequence will check that original transaction was successful and on the same account, and pass the gateway transaction identifier of the original transaction on to the gateway with this transaction\n",
                  "example": "1001131610340495360"
                },
                {
                  "name": "relatedPaymentNetworkTransactionId",
                  "kind": "optional",
                  "type": "string",
                  "description": "Card scheme identifier of the initial payment/pre-auth transaction that was customer initiated. If recurringPayment is true and recurringPaymentType is set, setting this to the card scheme identifier of the initial transaction in the sequence will pass this on on to the gateway with this transaction (no checks are made on this identifier).   Should not be specified if relatedReceiptId is specified. Only supported by certain processors. Please check with Developer Support if you intend to use this field\n",
                  "example": "MNKWQVNQS0915"
                },
                {
                  "name": "disableNetworkTokenisation",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "(Optional) Set to true to specify that network tokenisation should not be used for this transaction, even\nif network token registration has been enabled on the account.\n",
                  "example": true,
                  "default": false
                }
              ],
              "modelRef": "#/components/schemas/paymentRequestCardToken",
              "customType": "paymentRequestCardToken"
            },
            {
              "name": "object",
              "schema": [
                {
                  "name": "pkPayment",
                  "kind": "required",
                  "type": "object",
                  "description": "",
                  "example": "",
                  "schema": [
                    {
                      "name": "token",
                      "kind": "required",
                      "type": "object",
                      "description": "",
                      "example": "",
                      "schema": [
                        {
                          "name": "paymentMethod",
                          "kind": "optional",
                          "type": "object",
                          "description": "",
                          "example": "",
                          "schema": [
                            {
                              "name": "displayName",
                              "kind": "optional",
                              "type": "string",
                              "description": "Card description suitable for display, provided by the ApplePay session.",
                              "example": "Visa 1234"
                            },
                            {
                              "name": "network",
                              "kind": "optional",
                              "type": "string",
                              "description": "Name of the payment network backing the card, provided by the ApplePay session.",
                              "example": "Visa"
                            },
                            {
                              "name": "type",
                              "kind": "optional",
                              "type": "string",
                              "description": "Card's type of payment, provided by the ApplePay session.",
                              "example": "debit"
                            }
                          ]
                        },
                        {
                          "name": "paymentData",
                          "kind": "required",
                          "type": "object",
                          "description": "",
                          "example": "",
                          "schema": [
                            {
                              "name": "data",
                              "kind": "required",
                              "type": "string",
                              "description": "Encrypted payment data.",
                              "example": "CXnUZAtPGWfkLGsHksn5WTzfFhEzNMqSJZXKTmbaWGYnyB8z3Zt4fjqv7Snm5FVWbTQXXA8sRRS828t5hhmDpnuyzFBj7kYCJCw4y2rkMdRkj5yVXcmgTDMFWtMZdvRtYVvvkaqALQ86zFuNPFJG9tX6GHzSLnDfjzg5wzrAL3SzQTzxGYE6CWTuk27KF3UDRdRDTVXbyUN9ptKT2CDL9vwtZn7mBLqvubUvGsezJG7HMLZt4qMVFZVMUVyRWQXG54uwfDmSfJcVALD5ZKdmpPBGHn36DtPppwkn2jFyJdFYrARb3HtejQHsXGSafwUzP79XaEJCFGVk3dTX25DX6quWJFVwfwu9cMTcLpQYNWdkrrBkMnEDdRSTu9Zx6jCg2SgZ6FXmnpQhuPxDG662tcuuk4En6QgQsbqsP5z2"
                            },
                            {
                              "name": "signature",
                              "kind": "required",
                              "type": "string",
                              "description": "Signature of the payment and header data. The signature includes the signing certificate, its intermediate CA certificate, and information about the signing algorithm.",
                              "example": "gbtqw7Zy9LcfsV53pSRxDJjwUKmrLAWkxVxL6NQzzChwGRMQ3dncrEb69HuyR3ZScMAU6HcKhFD5yPMhdZ95EMq6ggcTqGNYn86U9fd6kC5gdN2PdKzdUH4GEzGkRcYXk4n5WJW8xamMvgsNwuKccbcvhmJXFcxe2G3JQzwjK6YDP6UdEJPNhRLAQjJaCdbGzvMe9zTaTWpeY8d9qBvG32EaVqeLtcEhayAmh4PMmc2RTqAfHVtDVRszXtRSCAPuCtq9Ebh4EGCRNyejgVjaUQqqA25J3fTDQNmwbEj3MzNcX6gDYAbA2WksuXPAjJUkLFwLfpHrZg8GQpHMkEyxT7s38TRXkgZ7ajQm8438XmNT2CRgtsFgkt4LgYA53XEtRMdnqUC8BvtbhkKyhTHZT6hw96aYawHy2k3KVS9Cwzq5kNgjvsR5fVw44dthejfMFrA3typX3VAXTeBKVayzXpa3Br3GxB4vKcUtw3G5sx3aT2DngGsvDSeEfv2Mxvw3p8nThsaqX9zz7jVWB6KpMpFA3bFnRFTdvWscXV9BbK8ZmDavaSVM8gaJPJmMaqxmTc9eaganfeen3f3NNnrxv7DZZDQ9SqSaWJ5SQZtRJh3wQfRvbjyNBAzHZvKzVHjDnwhHbhscu2twcMNMLwmZ7Ta3Ldjs7RTYqQbvFUYT92nUtEEmGJJs2DRXLkVFwTAFLRLcdVQuUs2JtYHmJRFhHDX3MRF6ZGESKyEsuUPHxmpaMm6Bm2yBfGqaxGsLbgWLdsDaKnmX8PWnefWXjADgnZKtbM94VxUp5Lt7qcyLFB2B7JNNfHEvnVgvWp2dbjWxTdQtUQyTcYg6MCgRTSxrGTve7MwfvqN6zWmjELEHBjNftDp6N6q9WXwhKgeFLUTtuTq3XVSahrDsBfwcSUWDAHrsUUYBj35y9SmQDsv2EKPnAZyuZGfpGvwJ5BAMkux7mNkFFffQytHhA29qEy3q9j6nrdp2xwWSf7g8qpvLyv3rCdKkNbaBjMYMEKYwuXAPBDN5jVsyKRz9X4XM9Evgd4Upbq4rjhw3t8eTJaMAdw7VSSLuacRyKG8kRuvfehBenWPtpeuN6EQaJ9z27sePQkUK4HPHRQrCwM3B9X8BVfrXrXGyxusGrbML8gHeK8jDH6xhSnuMwn2J2a9Uh77MG3NT34rUHy7NjansarA3WHgmVNJaeD9c4D9xSftgeWQZQCrd3SpY3gbaDPpuU2jEFnADftC7na2t2ZEWkxrv9LbPRT9U8zx9MUhTvx3KPdYMFL3dHZtKJ78vkkpjLC34EJGGLeNeDARabkNuUQQGbzPWSQpQfUSYVkue2bms3EBQ6cBnTsvHYh9PXPUDvM5fVFTyqGsxLRKA2xEWKbwhAuCa6yE2aCVC8sbKE7z3bPrC5EeA2r2GFyw6abKpkWFKdZ2DV3h7b2Fum4gNcp9UsdyH4qfybJgeMyDm4HwL2eR9aKNKM4DPM6yW2TXyNvqrDT7887tPsK8Svfbzt3s3Gm8queGFBZFZEJmaTpTXkHDND8KP2zGfmzHX7GMK5ZeHqAkNYNC5zXuFcH8GsDVShtfAjjUTybeFTCEWyh3DgEtt9gjbMecz4Axjb867RgxgPdeMVUJUTwmqXmgmfb69JNPYpVq7gcxwX8PB8EcavP3txD5mWseQWftw9wbNaf72uyaBe9fv2KZLywRBm383j4fjsKK4CkC4Dd4khw4WFqcZVLRwBgRT8QptL4xBVZcz5XPtP5G5QWJkYXA2PqU4QeWT9jq8dy4AaZNqtMxDvzRw7daQpwJ3hxH8mDLXSDatSGAqsdjUZdhNu4JTe5JZY7ungYsFjPfXBHhHnY67wXrpXECaYXC8tZCffPuX6A6b6VSWMXScJj6BsvwbvhzDTnBj8W497spMDfvE9UDK5YL4njtnpcAeDLKy24tPqJVBJQP5PA2LRSvdGRMe7sYT4WRfykH3dnVTQvw9vpcJM5s2xe4gauXzAQ66P9FzNBTbJ7f76ZUDKUCSuLZKAmDuUL6XhPPj8vthcjqTwjk8jxYfaqPxL4SABrFh9bpcwrtuJank53DH8rgyE2KzTDErfFngyYWJQqNQ7UP4qaFDg3yMmruTfkRrMJT3e4PBWnwceEvbRb3yV32JyXVEDkHgmJ2ufcEWWr4tNLKv2AjvvwpS5444rEdspvrWxSUSAzjJz7DB7qKSSQuzd52SVr5Lrgk5Cx8qyv5ZVmJTCKMLR6PcJgz8dqmcnfswvMrcwe4aXtWTcXZMYNKdpUUP6zpQrJ4BZe83nRc4geLWYV9qJuwzCyru2E7wRpupHGMsqhfdeVzxjeqYeQV7Qz3g7DDyyh68kmWs3BxgJWSNmpgH3vds3t9kmaBTarhdXdsC25tsjSTwNcVNmpehvZadxeZ6r4WCDvmuKGjVc8UyXhJtWKTjhSZMHkYvvjzE2Fmq5NnSSTygXGcPUSHL4xJZSTn6v7XQWnF8N5H3Ukw4J43NrGzbFJR99H6XTUyCxxpCmEjXS5B2ZpYqk3uHcGbTYBrntBTmVbYxjTfDsmuRwPVrr8G5mBpgkb7qwmm6cf2F8CAHgk44v48vsmVZg47wrEn8tvAMcrG6mRXyMXkxU8G92wHWEDemLWPy7PZYVNZzgeW7ahzcaHT7ck7VfpG4qNFQeWMNzfg3azsFjGB4wmUghF4ZDjZh5pLfKdm4pwYfce5UjnCkBWRRrzyxJGker4E8PeeUnvA8ufcDHcsC4YgUnHf2ANuLM6FALFJsD8hD73dNNRNyKFBs9zCMgL8nmKShRvJJBpFEsRYCRnHZLVfubk5wUMvhHgJHJRQGBD3GatJunfbkRQ5wmSPDW8zb7zfB8kswEEPagfmdzkCyVFPuBqFkxhyUZGxu7zxLv4YUG6BzEgjutVGUEjLKSPvcbaDVuZNmjZeFA5WJvn4Ccn8Xv2Et2jPVsQma"
                            },
                            {
                              "name": "header",
                              "kind": "optional",
                              "type": "object",
                              "description": "Additional version-dependent information used to decrypt and verify the payment.",
                              "example": "",
                              "schema": [
                                {
                                  "name": "publicKeyHash",
                                  "kind": "optional",
                                  "type": "string",
                                  "description": "",
                                  "example": "EMq6ggcTqGNYn86U9fd6kC5gdN2PdKzdUH4GEzGkRcYX"
                                },
                                {
                                  "name": "ephemeralPublicKey",
                                  "kind": "optional",
                                  "type": "string",
                                  "description": "",
                                  "example": "Y5q3gWSJL8byWFHkWtx8nzvMNkqrDMvtxLmkq6zMXQ36FvsFX64qRe7fAkmvMR7bwupmaZE7RNmzEHDssURbb6q3cCDuTv76d9vF8PH76u5SCBvk3UqqEz2t8Yqs"
                                },
                                {
                                  "name": "transactionId",
                                  "kind": "optional",
                                  "type": "string",
                                  "description": "",
                                  "example": "7c3b36d16bb0f6eac87e15359befa7b805b55408f9620443bd6d361cd604916d"
                                }
                              ]
                            },
                            {
                              "name": "version",
                              "kind": "optional",
                              "type": "string",
                              "description": "Version information about the payment token. The token uses EC_v1 for ECC-encrypted data, and RSA_v1 for RSA-encrypted data.",
                              "example": "EC_V1"
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "name": "cardAddress",
                  "kind": "optional",
                  "type": "object",
                  "description": "",
                  "modelRef": "#/components/schemas/cardAddressRequestAttributes",
                  "customType": "cardAddressRequestAttributes",
                  "schema": [],
                  "complexType": "allOf",
                  "complexItems": [
                    {
                      "name": "cardAddressCommonAttributes",
                      "description": "",
                      "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                      "schema": [
                        {
                          "name": "address1",
                          "kind": "optional",
                          "type": "string",
                          "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder House"
                        },
                        {
                          "name": "address2",
                          "kind": "optional",
                          "type": "string",
                          "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "1 CardHolder Street"
                        },
                        {
                          "name": "town",
                          "kind": "optional",
                          "type": "string",
                          "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder Town"
                        },
                        {
                          "name": "postCode",
                          "kind": "required",
                          "type": "string",
                          "description": "Postcode of the card holder's address.",
                          "example": "AB1 2CD"
                        },
                        {
                          "name": "state",
                          "kind": "optional",
                          "type": "string",
                          "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                          "example": "FL"
                        }
                      ]
                    },
                    {
                      "name": "object",
                      "description": "",
                      "schema": [
                        {
                          "name": "countryCode",
                          "kind": "optional",
                          "type": "string",
                          "description": "ISO 3166-1 (3 digit) country code of the card holder's address.",
                          "example": "826"
                        }
                      ]
                    }
                  ]
                },
                {
                  "name": "judoId",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique merchant and/or location ID supplied by Judopay.  Do not include spaces or dashes.  If not specified, then your default judoId will be used.",
                  "example": "100100100"
                },
                {
                  "name": "yourConsumerReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique reference to anonymously identify your customer.  Advisable to use GUIDs.",
                  "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                },
                {
                  "name": "yourPaymentReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Your unique reference for this payment. This value should be unique in order to protect your customers against duplicate transactions. With a server side integration, if a payment reference is not supplied, the transaction will not be processed.",
                  "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
                },
                {
                  "name": "yourPaymentMetaData",
                  "kind": "required",
                  "type": "object",
                  "description": "Optional key-value map for additional metadata associated with this transaction.   Will be stored but not processed or passed to gateways.   Do not include sensitive information like card numbers.",
                  "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                  "schema": []
                },
                {
                  "name": "currency",
                  "kind": "required",
                  "type": "string",
                  "description": "The ISO-4217 alphabetic code for the currency to use for the transaction, only required if different from the currency set during onboarding (default is GBP)",
                  "example": "GBP"
                },
                {
                  "name": "amount",
                  "kind": "required",
                  "type": "number<float>",
                  "description": "REQUIRED. The amount to process. Format for default currencies is to two decimal places.  For currencies using a different structure please contact Judopay for support.",
                  "example": 10.99
                },
                {
                  "name": "webPaymentReference",
                  "kind": "required",
                  "type": "string",
                  "description": "The unique reference of the Judopay payment session associated with this transaction.",
                  "example": "5QcAAAIAAAAMAAAADwAAAPwlgcQCLU6sLrNhi8kt1vEoVLwiFJc2EKTqT7JXb2xeQRqyYw"
                },
                {
                  "name": "clientDetails",
                  "kind": "required",
                  "type": "object",
                  "description": "A set of encrypted fraud signals sent by the mobile SDK",
                  "example": "",
                  "schema": []
                },
                {
                  "name": "initialRecurringPayment",
                  "kind": "required",
                  "type": "boolean",
                  "description": "Indicates if this is the first transaction that forms part of a recurring payment schedule. This flag should be set to 'true' if this is a customer-initiated payment which will be followed by a series of scheduled recurring payments.\n",
                  "example": false
                },
                {
                  "name": "primaryAccountDetails",
                  "kind": "required",
                  "type": "object",
                  "description": "Information about the primary account holder of the transaction.  Used for MCC 6012, MCC 6051 and MCC 7299 accounts only.  Does not need to be specified if these details were set on a payment session associated with this transaction.",
                  "example": "",
                  "schema": []
                }
              ],
              "modelRef": "#/components/schemas/paymentRequestApplePay",
              "customType": "paymentRequestApplePay"
            },
            {
              "name": "object",
              "schema": [
                {
                  "name": "googlePayWallet",
                  "kind": "required",
                  "type": "object",
                  "description": "",
                  "example": "",
                  "schema": [
                    {
                      "name": "token",
                      "kind": "required",
                      "type": "string",
                      "description": "JSON serialized payment token generated by Google Pay API\n",
                      "example": "\"{\\\"signature\\\":\\\"MEUCIQD6IX46z4mg8SCoS\\/UnbrgeUk+azwYFOHOHltdsO8D\\/VQIge3tia\\/4WD4UGrY3n\\/LkshnLLqm4YSr1tDVgOhoxxxxx\\\\u003d\\\",\\\"protocolVersion\\\":\\\"ECv1\\\",\\\"signedMessage\\\":\\\"{\\\\\\\"encryptedMessage\\\\\\\":\\\\\\\"Vp5ofRY6BkFnIdM1kNvHdwAfORynkLah8nBXwCPUt5Jt5RFAx+zvpjB4kAWr75eLjp+qTrz4PStuZQeQ84FUgc89LHCldBvR8G9XMEowZLhDEriPxnFOzL7H4c5NrD6PJIjC8X1zSUnS\\/KQ7DnmuK0RrKMG80Q7uZf2VXr\\/0Ibfx\\/TjNEMVqqtX+W63D7AkFJaAMrSUTTe2vBle7VBNgP9+w4GGVukxYdkzbc798Xpih3Rf9JhLBw1Kt+UNvc\\/KJyvgH+hP1xSUAReRzbcBJXUzw2jl\\/pMMrufKu5uk\\/yvUbg6WtQvJOJ\\/3FExY4EDsQdtmGdxFx2lvvWgpdGsT4q6MFkS8NLPP7hr9sMAlgOpN2USyuW1GGY2XwHBCXqBM5\\/5kYznmJlPuWNHjdcufAeuq+JPbeKW3IL\\/K47A+oGr7tK4tGQZufge0q2LnrkNhbAmDB\\/q7AXh2Rocm\\/W1oazA\\\\\\\\u003d\\\\\\\\u003d\\\\\\\",\\\\\\\"ephemeralPublicKey\\\\\\\":\\\\\\\"BE1bIBhKcBKqWaW2\\/OeE\\/ju8iepmmURJLPr1xwANCsGtHWkGhPH7ZYLr05Y8zuN\\/pij59r1aKGkiVK\\/eAB9QcZA\\\\\\\\u003d\\\\\\\",\\\\\\\"tag\\\\\\\":\\\\\\\"awRhL4dpt5JVA662aGt\\/Qt0N6T8apznSHyhWP+xxxxx\\\\\\\\u003d\\\\\\\"}\\\"}\"\n"
                    },
                    {
                      "name": "cardNetwork",
                      "kind": "optional",
                      "type": "string",
                      "description": "The payment card network returned by Google Pay API. Value should match one of the allowedCardNetworks in https://developers.google.com/pay/api/web/reference/request-objects#CardParameters\n",
                      "example": "VISA"
                    },
                    {
                      "name": "cardDetails",
                      "kind": "optional",
                      "type": "string",
                      "description": "The details about the card returned by Google Pay API. This value is commonly the last four digits of the selected payment account number.\n",
                      "example": "1234"
                    }
                  ]
                },
                {
                  "name": "cardAddress",
                  "kind": "optional",
                  "type": "object",
                  "description": "",
                  "modelRef": "#/components/schemas/cardAddressRequestAttributes",
                  "customType": "cardAddressRequestAttributes",
                  "schema": [],
                  "complexType": "allOf",
                  "complexItems": [
                    {
                      "name": "cardAddressCommonAttributes",
                      "description": "",
                      "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                      "schema": [
                        {
                          "name": "address1",
                          "kind": "optional",
                          "type": "string",
                          "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder House"
                        },
                        {
                          "name": "address2",
                          "kind": "optional",
                          "type": "string",
                          "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "1 CardHolder Street"
                        },
                        {
                          "name": "town",
                          "kind": "optional",
                          "type": "string",
                          "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder Town"
                        },
                        {
                          "name": "postCode",
                          "kind": "required",
                          "type": "string",
                          "description": "Postcode of the card holder's address.",
                          "example": "AB1 2CD"
                        },
                        {
                          "name": "state",
                          "kind": "optional",
                          "type": "string",
                          "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                          "example": "FL"
                        }
                      ]
                    },
                    {
                      "name": "object",
                      "description": "",
                      "schema": [
                        {
                          "name": "countryCode",
                          "kind": "optional",
                          "type": "string",
                          "description": "ISO 3166-1 (3 digit) country code of the card holder's address.",
                          "example": "826"
                        }
                      ]
                    }
                  ]
                },
                {
                  "name": "judoId",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique merchant and/or location ID supplied by Judopay.  Do not include spaces or dashes.  If not specified, then your default judoId will be used.",
                  "example": "100100100"
                },
                {
                  "name": "yourConsumerReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique reference to anonymously identify your customer.  Advisable to use GUIDs.",
                  "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                },
                {
                  "name": "yourPaymentReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Your unique reference for this payment. This value should be unique in order to protect your customers against duplicate transactions. With a server side integration, if a payment reference is not supplied, the transaction will not be processed.",
                  "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
                },
                {
                  "name": "yourPaymentMetaData",
                  "kind": "required",
                  "type": "object",
                  "description": "Optional key-value map for additional metadata associated with this transaction.   Will be stored but not processed or passed to gateways.   Do not include sensitive information like card numbers.",
                  "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                  "schema": []
                },
                {
                  "name": "currency",
                  "kind": "required",
                  "type": "string",
                  "description": "The ISO-4217 alphabetic code for the currency to use for the transaction, only required if different from the currency set during onboarding (default is GBP)",
                  "example": "GBP"
                },
                {
                  "name": "amount",
                  "kind": "required",
                  "type": "number<float>",
                  "description": "REQUIRED. The amount to process. Format for default currencies is to two decimal places.  For currencies using a different structure please contact Judopay for support.",
                  "example": 10.99
                },
                {
                  "name": "webPaymentReference",
                  "kind": "required",
                  "type": "string",
                  "description": "The unique reference of the Judopay payment session associated with this transaction.",
                  "example": "5QcAAAIAAAAMAAAADwAAAPwlgcQCLU6sLrNhi8kt1vEoVLwiFJc2EKTqT7JXb2xeQRqyYw"
                },
                {
                  "name": "clientDetails",
                  "kind": "required",
                  "type": "object",
                  "description": "A set of encrypted fraud signals sent by the mobile SDK",
                  "example": "",
                  "schema": []
                },
                {
                  "name": "initialRecurringPayment",
                  "kind": "required",
                  "type": "boolean",
                  "description": "Indicates if this is the first transaction that forms part of a recurring payment schedule. This flag should be set to 'true' if this is a customer-initiated payment which will be followed by a series of scheduled recurring payments.\n",
                  "example": false
                },
                {
                  "name": "primaryAccountDetails",
                  "kind": "required",
                  "type": "object",
                  "description": "Information about the primary account holder of the transaction.  Used for MCC 6012, MCC 6051 and MCC 7299 accounts only.  Does not need to be specified if these details were set on a payment session associated with this transaction.",
                  "example": "",
                  "schema": []
                },
                {
                  "name": "acceptHeaders",
                  "kind": "optional",
                  "type": "string",
                  "description": "Passed to ACS for use in rendering challenge screens.",
                  "example": "text/html",
                  "default": "text/html"
                },
                {
                  "name": "userAgent",
                  "kind": "optional",
                  "type": "string",
                  "description": "Passed to ACS for use in rendering challenge screens.",
                  "example": "Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
                },
                {
                  "name": "cardHolderName",
                  "kind": "optional",
                  "type": "string",
                  "description": "The full name of the card holder, required for 3DS2 authentication.  **Note:** When testing in the sandbox environment, it is the cardHolderName that is used to determine the test card for 3D Secure 2 authentication.",
                  "example": "John Doe"
                },
                {
                  "name": "emailAddress",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Email address of consumer, recommended but not required for 3DS2 authentication.",
                  "example": "test.user@judopay.com"
                },
                {
                  "name": "shippingAddress",
                  "kind": "optional",
                  "type": "object",
                  "description": "(Optional) Shipping address",
                  "example": "",
                  "schema": [
                    {
                      "name": "address1",
                      "kind": "optional",
                      "type": "string",
                      "description": "First line of the shipping address.",
                      "example": "CardHolder House"
                    },
                    {
                      "name": "address2",
                      "kind": "optional",
                      "type": "string",
                      "description": "Second line of the shipping address.",
                      "example": "1 CardHolder Street"
                    },
                    {
                      "name": "town",
                      "kind": "optional",
                      "type": "string",
                      "description": "Town of the shipping address.",
                      "example": "CardHolder Town"
                    },
                    {
                      "name": "postCode",
                      "kind": "optional",
                      "type": "string",
                      "description": "Postcode of the shipping address.",
                      "example": "AB1 2CD"
                    },
                    {
                      "name": "countryCode",
                      "kind": "optional",
                      "type": "string",
                      "description": "ISO 3166-1 (3 digit) country code of the shipping address.",
                      "example": "826"
                    },
                    {
                      "name": "isBillingAddress",
                      "kind": "optional",
                      "type": "boolean",
                      "description": "Indicator of whether the billing address is the same as the shipping address.",
                      "example": true
                    }
                  ]
                },
                {
                  "name": "mobileNumber",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Phone number of consumer, recommended for 3DS2 authentication, but not required.   Must be set if phoneCountryCode is set.",
                  "example": "7999999999"
                },
                {
                  "name": "phoneCountryCode",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Phone country code matching mobileNumber, recommended for 3DS2 authentication, but not required.   Should be set if mobileNumber is set, defaulted to 44 if not.",
                  "example": "44",
                  "default": "44"
                },
                {
                  "name": "threeDSecure",
                  "kind": "optional",
                  "type": "object",
                  "description": "",
                  "example": "",
                  "schema": [
                    {
                      "name": "authenticationSource",
                      "kind": "optional",
                      "type": "string<Browser>",
                      "description": "Type of device that will be used for challenge authentication.",
                      "example": "Browser"
                    },
                    {
                      "name": "methodNotificationUrl",
                      "kind": "optional",
                      "type": "string",
                      "description": "URL of the page that will receive a POST event after a device details call is completed.   Example is a Judo-hosted page that triggers a call to [POST /transactions/{receiptId}/resume3ds]() (which will be used if this attribute is not set)",
                      "example": "https://api.judopay.com/order/3ds/methodNotification",
                      "default": "https://api.judopay.com/order/3ds/methodNotification"
                    },
                    {
                      "name": "challengeNotificationUrl",
                      "kind": "optional",
                      "type": "string",
                      "description": "URL of the page that will receive a POST event after a challenge is completed. Example is a Judo-hosted page that triggers a call to [POST /transactions/{receiptId}/complete3ds]() (which will be used if this attribute is not set)",
                      "example": "https://api.judopay.com/order/3ds/challengeNotification",
                      "default": "https://api.judopay.com/order/3ds/challengeNotification"
                    },
                    {
                      "name": "challengeRequestIndicator",
                      "kind": "optional",
                      "type": "string",
                      "description": "Indicates whether a challenge is requested for this transaction (this may be over-ruled by the issuer).   Should not be specified in the same request as scaExemption\n",
                      "example": "challengePreferred",
                      "default": "noPreference",
                      "modelRef": "#/components/schemas/challengeRequestIndicatorRequest",
                      "customType": "challengeRequestIndicatorRequest",
                      "schema": []
                    },
                    {
                      "name": "scaExemption",
                      "kind": "optional",
                      "type": "string",
                      "description": "Indicates reason why challenge may not be necessary (this may be over-ruled by the issuer).   Should not be specified in the same request as challengeRequestIndicator\n",
                      "example": "transactionRiskAnalysis",
                      "modelRef": "#/components/schemas/scaExemptionRequest",
                      "customType": "scaExemptionRequest",
                      "schema": []
                    }
                  ]
                },
                {
                  "name": "threeDSecureMpi",
                  "kind": "optional",
                  "type": "object",
                  "description": "Optional block to pass in 3DS2 authentication results performed outside of Judopay.\n",
                  "example": "",
                  "schema": [
                    {
                      "name": "dsTransId",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Unique identifier for the authentication assigned by the Directory Server (Card Scheme).\n",
                      "example": "41aadf4c-e73f-4bd1-a0c4-acb2615a32af"
                    },
                    {
                      "name": "cavv",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Unique value for the authentication provided by the ACS. May be used to provide proof of authentication.\n",
                      "example": "AJkBCWUyZwAAAABugmKTdAAAAAA="
                    },
                    {
                      "name": "eci",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Electronic Commerce Indicator (ECI) is the value returned by Directory Servers (namely Visa, MasterCard, JCB, and American Express) indicating the outcome of authentication attempted on transactions enforced by 3DS.\n",
                      "example": "02"
                    },
                    {
                      "name": "threeDSecureVersion",
                      "kind": "required",
                      "type": "string",
                      "description": "REQUIRED. Version of 3DSecure that the card is enrolled into.\n",
                      "example": "2.2.0"
                    }
                  ]
                }
              ],
              "modelRef": "#/components/schemas/paymentRequestGooglePay",
              "customType": "paymentRequestGooglePay"
            }
          ],
          "complexType": "oneOf",
          "isExpanded": true
        }
      ],
      "formDataParameters": [],
      "oAuthParameters": [
        {
          "id": "TokenSecretAuth",
          "name": "TokenSecretAuth",
          "kind": "optional",
          "type": "http",
          "description": "<p>This is the typical authorisation scenario to use, specify your token in Username and secret in Password.</p>\n<p>Sent as Base64 encoded string representing token</p><div></div> in Authorization header.<p></p>",
          "scheme": "basic"
        },
        {
          "id": "PaymentSessionAuthToken",
          "name": "Api-Token",
          "kind": "optional",
          "type": "apiKey",
          "description": "<p>For Payment Session authentication, supply the token used to authenticate the call to generate a payment session</p>\n<p>PaymentSessionAuthReference section must also be completed.</p>",
          "in": "header"
        },
        {
          "id": "PaymentSessionAuthReference",
          "name": "Payment-Session",
          "kind": "optional",
          "type": "apiKey",
          "description": "<p>For Payment Session authentication, supply the reference returned in the create payment session response</p>\n<p>PaymentSessionAuthToken section must also be completed.</p>",
          "in": "header"
        }
      ]
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "Successful response will be one of\n  * transaction receipt\n  * request for 3DS2 device details\n  * request for 3DS2 challenge\n",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Successful response will be one of\n  * transaction receipt\n  * request for 3DS2 device details\n  * request for 3DS2 challenge\n \n{}"
          },
          {
            "label": "PaymentReceipt",
            "code": ""
          },
          {
            "label": "ThreeDSecure2DeviceDetailsRequired",
            "code": ""
          },
          {
            "label": "ThreeDSecure2ChallengeRequired",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "schema": [],
            "complexItems": [
              {
                "name": "object",
                "schema": [
                  {
                    "name": "receiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "Judopay's reference for the transaction.",
                    "example": "1001131610340495360"
                  },
                  {
                    "name": "originalReceiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Judopay's reference for any linked transaction (for collections, refunds and voids)\n",
                    "example": "1001124307998347264"
                  },
                  {
                    "name": "yourPaymentReference",
                    "kind": "optional",
                    "type": "string",
                    "description": "Your unique reference for this payment.",
                    "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
                  },
                  {
                    "name": "type",
                    "kind": "optional",
                    "type": "string<Payment | Refund | PreAuth | VOID | Collection | Save | Register | CheckCard>",
                    "description": "The type of the transaction.",
                    "example": "PreAuth"
                  },
                  {
                    "name": "createdAt",
                    "kind": "optional",
                    "type": "string<date-time>",
                    "description": "Date and time of creation.",
                    "example": "2025-02-05T16:28:32.8596+00:00"
                  },
                  {
                    "name": "result",
                    "kind": "optional",
                    "type": "string",
                    "description": "Result of transaction.",
                    "example": "Success"
                  },
                  {
                    "name": "message",
                    "kind": "optional",
                    "type": "string",
                    "description": "Message detailing the outcome.",
                    "example": "AuthCode: 123456"
                  },
                  {
                    "name": "judoId",
                    "kind": "optional",
                    "type": "integer",
                    "description": "Unique merchant and/or location ID supplied by Judopay.",
                    "example": 100100100
                  },
                  {
                    "name": "merchantName",
                    "kind": "optional",
                    "type": "string",
                    "description": "Merchant's trading name.",
                    "example": "Test Merchant"
                  },
                  {
                    "name": "appearsOnStatementAs",
                    "kind": "optional",
                    "type": "string",
                    "description": "Merchant description as it appears on the consumer's statement.",
                    "example": "APL*/TestMerchant       "
                  },
                  {
                    "name": "originalAmount",
                    "kind": "optional",
                    "type": "string",
                    "description": "Amount of original transaction (not affected by refunds or collections).",
                    "example": "10.99"
                  },
                  {
                    "name": "amountCollected",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional - PreAuth and Void only] Amount that has been collected on original pre-authorisation.\n",
                    "example": "1.99"
                  },
                  {
                    "name": "netAmount",
                    "kind": "optional",
                    "type": "string",
                    "description": "For payments, preauths and voids this is equal to the amount on the request.  For incremental auths this is\nthe original preauth amount plus the total of all incremental auths. For collections, this is the original\npreauth amount plus the total of all incremental auths minus the total of all collections.  For refunds,\nthis is the original sale amount minus the total of all refunds.\n",
                    "example": "1.00"
                  },
                  {
                    "name": "amount",
                    "kind": "optional",
                    "type": "string",
                    "description": "The amount of this transaction, for refunds and collections the amount that has been refunded or collected in this transaction.",
                    "example": "1.00"
                  },
                  {
                    "name": "currency",
                    "kind": "optional",
                    "type": "string",
                    "description": "The ISO-217 alphabetic code of the currency of the transaction",
                    "example": "GBP"
                  },
                  {
                    "name": "recurringPaymentType",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Type of recurring payment (RECURRING for scheduled, MIT for non-scheduled)\n",
                    "example": "MIT"
                  },
                  {
                    "name": "acquirerTransactionId",
                    "kind": "optional",
                    "type": "string",
                    "description": "The unique ID of the transaction set by the acquirer.",
                    "example": "33666277256892153705"
                  },
                  {
                    "name": "externalBankResponseCode",
                    "kind": "optional",
                    "type": "string",
                    "description": "Response code set by the acquirer.",
                    "example": "A"
                  },
                  {
                    "name": "authCode",
                    "kind": "optional",
                    "type": "string",
                    "description": "Authorisation code set by acquirer",
                    "example": "123456"
                  },
                  {
                    "name": "walletType",
                    "kind": "optional",
                    "type": "integer",
                    "description": "[Conditional] For digital wallet transactions, the type of wallet (1=ApplePay, 2=AndroidPay, 4=GooglePay)\n",
                    "example": 1
                  },
                  {
                    "name": "riskScore",
                    "kind": "optional",
                    "type": "integer",
                    "description": "Consumers risk score\n",
                    "example": 0
                  },
                  {
                    "name": "paymentNetworkTransactionId",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Unique identifier of the transaction returned by the payment network/ card scheme.\n",
                    "example": "123456789012345"
                  },
                  {
                    "name": "allowIncrement",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true for customer initiated pre-auths that had the allowIncrement request attribute set to true\n",
                    "example": true
                  },
                  {
                    "name": "isIncrementalAuth",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true for calls to POST /transactions/incrementalAuth\n",
                    "example": true
                  },
                  {
                    "name": "emailAddress",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] email address of consumer, if supplied on the request\n",
                    "example": "test.user@judopay.com"
                  },
                  {
                    "name": "cardDetails",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/cardDetailsResponse",
                    "customType": "cardDetailsResponse",
                    "schema": [
                      {
                        "name": "cardLastfour",
                        "kind": "optional",
                        "type": "string",
                        "description": "Last four digits of card",
                        "example": "1234"
                      },
                      {
                        "name": "endDate",
                        "kind": "optional",
                        "type": "string",
                        "description": "Card expiry date in format MMYY",
                        "example": "1225"
                      },
                      {
                        "name": "cardToken",
                        "kind": "optional",
                        "type": "string",
                        "description": "Tokenized representation of card which can be used in future transactions instead of card number",
                        "example": "Ck3AeNlBfjvs9d61MNZiG0gtCvijqvKr"
                      },
                      {
                        "name": "cardType",
                        "kind": "optional",
                        "type": "integer",
                        "description": "Integer representing the type of card, see Reference Codes - Card Types on https://docs.judopay.com/Content/Developer%20Tools/Codes.htm#CardTypes",
                        "example": 2
                      },
                      {
                        "name": "startDate",
                        "kind": "optional",
                        "type": "string",
                        "description": "Card start date in format MMYY",
                        "example": "0121"
                      },
                      {
                        "name": "cardScheme",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of card scheme (determined from matching start of card number against issuer data)",
                        "example": "Mastercard"
                      },
                      {
                        "name": "cardFunding",
                        "kind": "optional",
                        "type": "string",
                        "description": "Type of card (determined from matching start of card number against issuer data)",
                        "example": "Credit"
                      },
                      {
                        "name": "cardCategory",
                        "kind": "optional",
                        "type": "string",
                        "description": "Category of card (determined from matching start of card number against issuer data)",
                        "example": "Acquirer Only"
                      },
                      {
                        "name": "cardCountry",
                        "kind": "optional",
                        "type": "string",
                        "description": "ISO 3166-1 alpha-2 code of country that issued the card (determined from matching start of card number against issuer data)",
                        "example": "GB"
                      },
                      {
                        "name": "bank",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of bank that issued the card (determined from matching start of card number against issuer data)",
                        "example": "Santander Uk Plc"
                      },
                      {
                        "name": "cardHolderName",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of card holder as supplied on request",
                        "example": "John Doe"
                      },
                      {
                        "name": "ownerType",
                        "kind": "optional",
                        "type": "string<Personal | Commercial | >",
                        "description": "[Conditional] Indicator of whether a card is personal or commercial, if known\n",
                        "example": "Personal"
                      }
                    ]
                  },
                  {
                    "name": "billingAddress",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/cardAddressResponseAttributes",
                    "customType": "cardAddressResponseAttributes",
                    "schema": [],
                    "complexType": "allOf",
                    "complexItems": [
                      {
                        "name": "cardAddressCommonAttributes",
                        "description": "",
                        "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                        "schema": [
                          {
                            "name": "address1",
                            "kind": "optional",
                            "type": "string",
                            "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                            "example": "CardHolder House"
                          },
                          {
                            "name": "address2",
                            "kind": "optional",
                            "type": "string",
                            "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                            "example": "1 CardHolder Street"
                          },
                          {
                            "name": "town",
                            "kind": "optional",
                            "type": "string",
                            "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                            "example": "CardHolder Town"
                          },
                          {
                            "name": "postCode",
                            "kind": "required",
                            "type": "string",
                            "description": "Postcode of the card holder's address.",
                            "example": "AB1 2CD"
                          },
                          {
                            "name": "state",
                            "kind": "optional",
                            "type": "string",
                            "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                            "example": "FL"
                          }
                        ]
                      },
                      {
                        "name": "object",
                        "description": "",
                        "schema": [
                          {
                            "name": "countryCode",
                            "kind": "optional",
                            "type": "integer",
                            "description": "ISO 3166-1 (3 digit) country code of the card holder's address.   If the first digit of the\nof the code is 0 this will not be shown\n",
                            "example": 826
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "name": "consumer",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/consumerResponse",
                    "customType": "consumerResponse",
                    "schema": [
                      {
                        "name": "yourConsumerReference",
                        "kind": "optional",
                        "type": "string",
                        "description": "Your unique reference to anonymously identify your customer.",
                        "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                      }
                    ]
                  },
                  {
                    "name": "device",
                    "kind": "optional",
                    "type": "object",
                    "description": "[Conditional] If clientDetails was provided containing a kdeviceid\n",
                    "modelRef": "#/components/schemas/deviceResponse",
                    "customType": "deviceResponse",
                    "schema": [
                      {
                        "name": "identifier",
                        "kind": "optional",
                        "type": "string",
                        "description": "Judopay generated GUID associated with the kdeviceid passed in the clientDetails request attribute",
                        "example": "d73b4a7b58ce4e54a3bd73b7eda061e6"
                      }
                    ]
                  },
                  {
                    "name": "yourPaymentMetaData",
                    "kind": "optional",
                    "type": "object",
                    "description": "Merchant metadata passed with transaction request.\n",
                    "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                    "schema": []
                  },
                  {
                    "name": "threeDSecure",
                    "kind": "optional",
                    "type": "object",
                    "description": "[Conditional] Only returned for transactions using 3DS\n",
                    "modelRef": "#/components/schemas/threeDSecureCompletedResponse",
                    "customType": "threeDSecureCompletedResponse",
                    "schema": [
                      {
                        "name": "attempted",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Did the consumer attempt to authenticate through 3DSecure",
                        "example": true
                      },
                      {
                        "name": "result",
                        "kind": "optional",
                        "type": "string",
                        "description": "[Conditional] Outcome of the 3DSecure authentication, only present on initial receipt response, not historic receipts\n",
                        "example": "PASSED"
                      },
                      {
                        "name": "eci",
                        "kind": "optional",
                        "type": "string",
                        "description": "Electronic Commerce Indicator returned by 3DS servers indicating outcome of authentication",
                        "example": "05"
                      },
                      {
                        "name": "challengeRequestIndicator",
                        "kind": "optional",
                        "type": "string<NoPreference | NoChallenge | ChallengePreferred | ChallengeAsMandate | ChallengeWithWhitelistPrompt | >",
                        "description": "[Conditional] Challenge request indicator that was used for 3DS authentication\n",
                        "example": "ChallengeMandated"
                      },
                      {
                        "name": "scaExemption",
                        "kind": "optional",
                        "type": "string<TrustedBeneficiary | TransactionRiskAnalysis | DataShareOnly | ScaAlreadyPerformed | >",
                        "description": "[Conditional] SCA exemption that was used for 3DS authentication\n",
                        "example": ""
                      }
                    ]
                  },
                  {
                    "name": "risks",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/riskParametersResponse",
                    "customType": "riskParametersResponse",
                    "schema": [
                      {
                        "name": "postCodeCheck",
                        "kind": "optional",
                        "type": "string<PASSED | FAILED | UNKNOWN>",
                        "description": "Indication of whether supplied postCode was verified",
                        "example": "PASSED"
                      },
                      {
                        "name": "cv2Check",
                        "kind": "optional",
                        "type": "string<PASSED | FAILED | NOT_PROCESSED | NOT_SUBMITTED | NOT_SUPPORTED | NOT_CHECKED | SUSPICIOUS | UNKNOWN>",
                        "description": "Indication of whether supplied cv2 was verified",
                        "example": "PASSED"
                      },
                      {
                        "name": "merchantSuggestion",
                        "kind": "optional",
                        "type": "string",
                        "description": "Suggestion action for the merchant from the risk engine",
                        "example": "Allow"
                      }
                    ]
                  },
                  {
                    "name": "disableNetworkTokenisation",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true if the request explicitly disabled network tokens for this transaction\n",
                    "example": true
                  },
                  {
                    "name": "networkTokenisationDetails",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/networkTokenisationDetailsResponse",
                    "customType": "networkTokenisationDetailsResponse",
                    "schema": [
                      {
                        "name": "networkTokenProvisioned",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Indicates if a new network token was created during the course of this transaction",
                        "example": true
                      },
                      {
                        "name": "networkTokenUsed",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Indicates if this transaction was completed using a network token",
                        "example": true
                      },
                      {
                        "name": "virtualPan",
                        "kind": "optional",
                        "type": "object",
                        "description": "",
                        "example": "",
                        "schema": [
                          {
                            "name": "lastFour",
                            "kind": "optional",
                            "type": "string",
                            "description": "Last four digits of the virtual PAN used",
                            "example": "1234"
                          },
                          {
                            "name": "expiryDate",
                            "kind": "optional",
                            "type": "string",
                            "description": "Expiry date of the virtual PAN in format MMYY",
                            "example": "0129"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "modelRef": "#/components/schemas/transactionReceiptResponse",
                "customType": "transactionReceiptResponse"
              },
              {
                "name": "object",
                "schema": [
                  {
                    "name": "methodUrl",
                    "kind": "optional",
                    "type": "string",
                    "description": "URL to direct consumer to to complete challenge",
                    "example": "https://test.portal.gpwebpay.com/pay-sim/sim/acs"
                  },
                  {
                    "name": "version",
                    "kind": "optional",
                    "type": "string",
                    "description": "ThreeDSecure version",
                    "example": "2.2.0"
                  },
                  {
                    "name": "receiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "Judopay's reference for the transaction.",
                    "example": "1001131610340495360"
                  },
                  {
                    "name": "result",
                    "kind": "optional",
                    "type": "string",
                    "description": "Result of transaction.",
                    "example": "Additional device data is needed for 3D Secure 2"
                  },
                  {
                    "name": "message",
                    "kind": "optional",
                    "type": "string",
                    "description": "Message detailing the outcome.",
                    "example": "Issuer ACS has requested additional device data gathering"
                  },
                  {
                    "name": "md",
                    "kind": "optional",
                    "type": "string",
                    "description": "Encoded string representing ThreeDSecure transaction details.",
                    "example": "ewogICJ0aHJlZURTU2VydmVyVHJhbnNJRCIgOiAiOGU4ZDY2ZTctM2Y1Yy00MTQyLTk5ZTItY2Y4YWE4ODBhMTMxIiwKICAidGhyZWVEU01ldGhvZE5vdGlmaWNhdGlvblVSTCIgOiAiaHR0cHM6Ly9hcGkua2FyYXRlcGF5LmNvbS9vcmRlci8zZHMvbWV0aG9kTm90aWZpY2F0aW9uIgp9"
                  }
                ],
                "modelRef": "#/components/schemas/threeDSecureTwoDeviceDetailsRequiredResponse",
                "customType": "threeDSecureTwoDeviceDetailsRequiredResponse"
              },
              {
                "name": "object",
                "schema": [
                  {
                    "name": "challengeUrl",
                    "kind": "optional",
                    "type": "string",
                    "description": "URL to direct consumer to to complete challenge",
                    "example": "https://acs2.test.gpe.cz/tds/challenge/brw/ea510e00-90ab-41eb-8a54-482e20fc2a36"
                  },
                  {
                    "name": "cReq",
                    "kind": "optional",
                    "type": "string",
                    "description": "Encoded value that should be POSTed to the challengeUrl",
                    "example": "ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjEuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICI4ZThkNjZlNy0zZjVjLTQxNDItOTllMi1jZjhhYTg4MGExMzEiLAogICJhY3NUcmFuc0lEIiA6ICJlYTUxMGUwMC05MGFiLTQxZWItOGE1NC00ODJlMjBmYzJhMzYiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwMSIKfQ=="
                  },
                  {
                    "name": "version",
                    "kind": "optional",
                    "type": "string",
                    "description": "ThreeDSecure version",
                    "example": "2.2.0"
                  },
                  {
                    "name": "receiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "Judopay's reference for the transaction.",
                    "example": "1001131610340495360"
                  },
                  {
                    "name": "result",
                    "kind": "optional",
                    "type": "string",
                    "description": "Result of transaction .",
                    "example": "Challenge completion is needed for 3D Secure 2"
                  },
                  {
                    "name": "message",
                    "kind": "optional",
                    "type": "string",
                    "description": "Message detailing the outcome.",
                    "example": "Issuer ACS has responded with a Challenge URL"
                  },
                  {
                    "name": "md",
                    "kind": "optional",
                    "type": "string",
                    "description": "Encoded string representing ThreeDSecure transaction details.",
                    "example": "ewogICJ0aHJlZURTU2VydmVyVHJhbnNJRCIgOiAiOGU4ZDY2ZTctM2Y1Yy00MTQyLTk5ZTItY2Y4YWE4ODBhMTMxIiwKICAidGhyZWVEU01ldGhvZE5vdGlmaWNhdGlvblVSTCIgOiAiaHR0cHM6Ly9hcGkua2FyYXRlcGF5LmNvbS9vcmRlci8zZHMvbWV0aG9kTm90aWZpY2F0aW9uIgp9"
                  }
                ],
                "modelRef": "#/components/schemas/threeDSecureTwoChallengeRequiredResponse",
                "customType": "threeDSecureTwoChallengeRequiredResponse"
              }
            ],
            "complexType": "oneOf",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "401",
        "description": "Unauthorized",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Unauthorized",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "403",
        "description": "Forbidden if token used does not have required permission",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Forbidden",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "409",
        "description": "Conflict - unable to find a route for the transactions\n",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Conflict - unable to find a route for the transactions\n \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "JudoId Blocked",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "yMOI-7GNe_PcoMjVP1RlY",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --request POST 'https://api-sandbox.judopay.com/transactions/payments' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json' \\\n--header 'Api-Version: string'"
        },
        {
          "id": "43BvKJizbwBeB4pd5RzA5",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\nmyHeaders.append(\"Api-Version\", \"string\");\n\nvar requestOptions = {\n   method: 'POST',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api-sandbox.judopay.com/transactions/payments\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "xO7XeBcTbqdDTUPr0xJVj",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api-sandbox.judopay.com/transactions/payments\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Post.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\nrequest[\"Api-Version\"] = \"string\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "-E01e6So4W0u3Ey_daSRY",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api-sandbox.judopay.com/transactions/payments\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json',\n   'Api-Version': 'string'\n}\n\nresponse = requests.request(\"POST\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "yMOI-7GNe_PcoMjVP1RlY"
    },
    "results": {
      "languages": [
        {
          "id": "SxwH2tXN77twjqQw7aPN5",
          "language": "200",
          "code": "// Successful response will be one of\n  * transaction receipt\n  * request for 3DS2 device details\n  * request for 3DS2 challenge\n \n{}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Successful response will be one of\n  * transaction receipt\n  * request for 3DS2 device details\n  * request for 3DS2 challenge\n \n{}"
            },
            {
              "label": "PaymentReceipt",
              "code": ""
            },
            {
              "label": "ThreeDSecure2DeviceDetailsRequired",
              "code": ""
            },
            {
              "label": "ThreeDSecure2ChallengeRequired",
              "code": ""
            }
          ]
        },
        {
          "id": "XCsMZsxh-ZdMnfhXQYNGS",
          "language": "401",
          "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Unauthorized",
              "code": ""
            }
          ]
        },
        {
          "id": "a8Xv5ARK6aegQrjdgOqcX",
          "language": "403",
          "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Forbidden",
              "code": ""
            }
          ]
        },
        {
          "id": "nqBUN2uzSgScvPmWIi212",
          "language": "409",
          "code": "// Conflict - unable to find a route for the transactions\n \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Conflict - unable to find a route for the transactions\n \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "JudoId Blocked",
              "code": ""
            }
          ]
        }
      ],
      "selectedLanguageId": "SxwH2tXN77twjqQw7aPN5"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}