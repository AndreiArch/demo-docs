---
title: /info
createdAt: Tue Feb 03 2026 08:50:33 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "9RIwhBTS2Dwzu0-8bgBwV",
  "type": "api-oas-v2",
  "data": {
    "method": "GET",
    "url": "https://api-sandbox.judopay.com/info",
    "servers": [
      {
        "url": "https://api-sandbox.judopay.com/info",
        "description": "Sandbox environment"
      }
    ],
    "name": "",
    "description": "<p>Obtain information about service, including latest supported Api-Version</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [
        {
          "kind": "required",
          "name": "Api-Version",
          "type": "string",
          "example": "6.23",
          "description": "The version of this API."
        }
      ],
      "queryParameters": [],
      "bodyDataParameters": [],
      "formDataParameters": [],
      "oAuthParameters": [
        {
          "id": "TokenSecretAuth",
          "name": "TokenSecretAuth",
          "kind": "optional",
          "type": "http",
          "description": "<p>This is the typical authorisation scenario to use, specify your token in Username and secret in Password.</p>\n<p>Sent as Base64 encoded string representing token</p><div></div> in Authorization header.<p></p>",
          "scheme": "basic"
        }
      ]
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "Successful response",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "infoResponse",
            "schema": [
              {
                "name": "version",
                "kind": "optional",
                "type": "string",
                "description": "Latest supported Api-Version to be used in headers for requests.",
                "example": "6.23.0.0"
              }
            ],
            "modelRef": "#/components/schemas/infoResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "400",
        "description": "Bad request (Api-Version header missing)",
        "jsonExample": "",
        "isExpanded": true
      },
      {
        "statusCode": "401",
        "description": "Unauthorized",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Unauthorized",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "G5kRE-7BDgJBWQtJVQtHj",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location 'https://api-sandbox.judopay.com/info' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json' \\\n--header 'Api-Version: string'"
        },
        {
          "id": "mKXfiEjcpY5eDqEwkLTz_",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\nmyHeaders.append(\"Api-Version\", \"string\");\n\nvar requestOptions = {\n   method: 'GET',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api-sandbox.judopay.com/info\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "mTFFRnTRW349pgj0-AKAv",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api-sandbox.judopay.com/info\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Get.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\nrequest[\"Api-Version\"] = \"string\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "UiacA2k-1JhFDgoSSgZa4",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api-sandbox.judopay.com/info\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json',\n   'Api-Version': 'string'\n}\n\nresponse = requests.request(\"GET\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "G5kRE-7BDgJBWQtJVQtHj"
    },
    "results": {
      "languages": [
        {
          "id": "omwnEdU79Cv29gyb45fyw",
          "language": "200",
          "code": "// Successful response \n{\n  \"version\": \"6.23.0.0\"\n}"
        },
        {
          "id": "zLteXN0S6DOPXksjPf56l",
          "language": "400",
          "code": "// Bad request (Api-Version header missing) \n"
        },
        {
          "id": "w7OqflAYEmaHpJ14MHLZU",
          "language": "401",
          "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Unauthorized",
              "code": ""
            }
          ]
        }
      ],
      "selectedLanguageId": "omwnEdU79Cv29gyb45fyw"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}