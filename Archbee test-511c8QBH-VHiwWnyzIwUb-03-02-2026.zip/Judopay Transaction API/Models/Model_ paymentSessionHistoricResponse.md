---
title: Model: paymentSessionHistoricResponse
createdAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

### Code examples

```json
{
  "amount": "",
  "cardAddress": {},
  "clientIpAddress": "",
  "clientUserAgent": "",
  "companyName": "",
  "currency": "",
  "expiryDate": "",
  "judoId": "",
  "paymentCancelUrl": "",
  "paymentSuccessUrl": "",
  "reference": "",
  "allowedCardTyes": [
    0
  ],
  "response": {
    "postUrl": "",
    "reference": ""
  },
  "status": "",
  "transactionType": "",
  "yourConsumerReference": "",
  "yourPaymentMetaData": {},
  "yourPaymentReference": "",
  "receipt": {
    "receiptId": "",
    "originalReceiptId": "",
    "yourPaymentReference": "",
    "type": "",
    "createdAt": "",
    "result": "",
    "message": "",
    "judoId": 0,
    "merchantName": "",
    "appearsOnStatementAs": "",
    "originalAmount": "",
    "amountCollected": "",
    "netAmount": "",
    "amount": "",
    "currency": "",
    "recurringPaymentType": "",
    "acquirerTransactionId": "",
    "externalBankResponseCode": "",
    "authCode": "",
    "postCodeCheckResult": "",
    "walletType": 0,
    "acquirer": "",
    "webPaymentReference": "",
    "noOfAuthAttempts": 0,
    "paymentNetworkTransactionId": "",
    "allowIncrement": false,
    "isIncrementalAuth": false,
    "disableNetworkTokenisation": false,
    "cardDetails": {
      "cardLastfour": "",
      "endDate": "",
      "cardToken": "",
      "cardType": 0,
      "startDate": "",
      "cardScheme": "",
      "cardFunding": "",
      "cardCategory": "",
      "cardCountry": "",
      "bank": "",
      "cardHolderName": "",
      "ownerType": ""
    },
    "billingAddress": {},
    "consumer": {
      "yourConsumerReference": ""
    },
    "device": {
      "identifier": ""
    },
    "yourPaymentMetaData": {},
    "threeDSecure": {
      "attempted": false,
      "result": "",
      "eci": "",
      "challengeRequestIndicator": "",
      "scaExemption": ""
    },
    "risks": {
      "postCodeCheck": "",
      "cv2Check": "",
      "merchantSuggestion": ""
    },
    "networkTokenisationDetails": {
      "networkTokenProvisioned": false,
      "networkTokenUsed": false,
      "virtualPan": {
        "lastFour": "",
        "expiryDate": ""
      }
    }
  },
  "portalUserRecId": 0,
  "webPaymentOperation": 0,
  "isPayByLink": false,
  "isJudoAccept": false,
  "isThreeDSecureTwo": false,
  "mobileNumber": "",
  "phoneCountryCode": "",
  "emailAddress": "",
  "noOfAuthAttempts": 0,
  "shortReference": ""
}
```
