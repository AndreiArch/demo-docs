---
title: Model: cardAddressWebPaymentRequest
createdAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

### Code examples

```json
{
  "address1": "",
  "address2": "",
  "town": "",
  "postCode": "",
  "state": "",
  "countryCode": "",
  "cardHolderName": ""
}
```
