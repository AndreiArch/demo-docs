---
title: Model: errorResponse
createdAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

### Code examples

```json
{
  "requestId": "",
  "message": "",
  "code": 0,
  "category": 0
}
```
