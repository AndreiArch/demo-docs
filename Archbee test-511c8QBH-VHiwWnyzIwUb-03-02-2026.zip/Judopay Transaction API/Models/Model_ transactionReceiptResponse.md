---
title: Model: transactionReceiptResponse
createdAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

### Code examples

```json
{
  "receiptId": "",
  "originalReceiptId": "",
  "yourPaymentReference": "",
  "type": "",
  "createdAt": "",
  "result": "",
  "message": "",
  "judoId": 0,
  "merchantName": "",
  "appearsOnStatementAs": "",
  "originalAmount": "",
  "amountCollected": "",
  "netAmount": "",
  "amount": "",
  "currency": "",
  "recurringPaymentType": "",
  "acquirerTransactionId": "",
  "externalBankResponseCode": "",
  "authCode": "",
  "walletType": 0,
  "riskScore": 0,
  "paymentNetworkTransactionId": "",
  "allowIncrement": false,
  "isIncrementalAuth": false,
  "emailAddress": "",
  "cardDetails": {
    "cardLastfour": "",
    "endDate": "",
    "cardToken": "",
    "cardType": 0,
    "startDate": "",
    "cardScheme": "",
    "cardFunding": "",
    "cardCategory": "",
    "cardCountry": "",
    "bank": "",
    "cardHolderName": "",
    "ownerType": ""
  },
  "billingAddress": {},
  "consumer": {
    "yourConsumerReference": ""
  },
  "device": {
    "identifier": ""
  },
  "yourPaymentMetaData": {},
  "threeDSecure": {
    "attempted": false,
    "result": "",
    "eci": "",
    "challengeRequestIndicator": "",
    "scaExemption": ""
  },
  "risks": {
    "postCodeCheck": "",
    "cv2Check": "",
    "merchantSuggestion": ""
  },
  "disableNetworkTokenisation": false,
  "networkTokenisationDetails": {
    "networkTokenProvisioned": false,
    "networkTokenUsed": false,
    "virtualPan": {
      "lastFour": "",
      "expiryDate": ""
    }
  }
}
```
