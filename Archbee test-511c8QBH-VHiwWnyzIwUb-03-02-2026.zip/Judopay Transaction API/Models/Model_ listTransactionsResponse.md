---
title: Model: listTransactionsResponse
createdAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

### Code examples

```json
{
  "resultCount": 0,
  "pageSize": 0,
  "offset": 0,
  "results": [
    {
      "receiptId": "",
      "originalReceiptId": "",
      "yourPaymentReference": "",
      "type": "",
      "createdAt": "",
      "result": "",
      "message": "",
      "judoId": 0,
      "appearsOnStatementAs": "",
      "originalAmount": "",
      "amountCollected": "",
      "netAmount": "",
      "amount": "",
      "currency": "",
      "postCodeCheckResult": "",
      "walletType": 0,
      "allowIncrement": false,
      "isIncrementalAuth": false,
      "cardDetails": {
        "cardLastfour": "",
        "endDate": "",
        "cardType": 0
      },
      "consumer": {
        "yourConsumerReference": ""
      },
      "yourPaymentMetaData": {},
      "threeDSecure": {
        "attempted": false,
        "result": "",
        "eci": "",
        "challengeRequestIndicator": "",
        "scaExemption": ""
      }
    }
  ],
  "sort": ""
}
```
