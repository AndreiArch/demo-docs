---
title: Model: paymentSessionRequest
createdAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

### Code examples

```json
{
  "judoId": "",
  "yourConsumerReference": "",
  "yourPaymentReference": "",
  "yourPaymentMetaData": {},
  "currency": "",
  "amount": "",
  "cardAddress": {},
  "expiryDate": "",
  "isPayByLink": false,
  "isJudoAccept": false,
  "successUrl": "",
  "cancelUrl": "",
  "emailAddress": "",
  "mobileNumber": "",
  "phoneCountryCode": "44",
  "threeDSecure": {
    "challengeRequestIndicator": "noPreference",
    "scaExemption": ""
  },
  "hideBillingInfo": true,
  "hideReviewInfo": true,
  "disableNetworkTokenisation": false,
  "primaryAccountDetails": {
    "name": "",
    "accountNumber": "",
    "dateOfBirth": "",
    "postCode": ""
  }
}
```
