---
title: Model: complete3ds2Request
createdAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

### Code examples

```json
{
  "cv2": "",
  "version": "",
  "primaryAccountDetails": {
    "name": "",
    "accountNumber": "",
    "dateOfBirth": "",
    "postCode": ""
  }
}
```
