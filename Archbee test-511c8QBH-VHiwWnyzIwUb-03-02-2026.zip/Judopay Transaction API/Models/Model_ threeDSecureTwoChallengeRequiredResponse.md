---
title: Model: threeDSecureTwoChallengeRequiredResponse
createdAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

### Code examples

```json
{
  "challengeUrl": "",
  "cReq": "",
  "version": "",
  "receiptId": "",
  "result": "",
  "message": "",
  "md": ""
}
```
