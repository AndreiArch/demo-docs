---
title: Model: listPaymentSessionsResponse
createdAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

### Code examples

```json
{
  "resultCount": 0,
  "pageSize": 0,
  "offset": 0,
  "results": [
    {
      "amount": "",
      "cardAddress": {},
      "clientIpAddress": "",
      "clientUserAgent": "",
      "companyName": "",
      "currency": "",
      "expiryDate": "",
      "judoId": "",
      "paymentCancelUrl": "",
      "paymentSuccessUrl": "",
      "reference": "",
      "allowedCardTyes": [
        0
      ],
      "status": "",
      "transactionType": "",
      "yourConsumerReference": "",
      "yourPaymentMetaData": {},
      "yourPaymentReference": "",
      "webPaymentOperation": 0,
      "isPayByLink": false,
      "isJudoAccept": false,
      "tradingName": ""
    }
  ]
}
```
