---
title: /transactions/savecard
createdAt: Tue Feb 03 2026 08:50:33 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "6gCKkH1GamSHza-zK6B2I",
  "type": "api-oas-v2",
  "data": {
    "method": "POST",
    "url": "https://api-sandbox.judopay.com/transactions/savecard",
    "servers": [
      {
        "url": "https://api-sandbox.judopay.com/transactions/savecard",
        "description": "Sandbox environment"
      }
    ],
    "name": "",
    "description": "<h2>If you do not want to perform a pre-authorisation check on a customer's account, use this call to tokenize the card information into an encrypted string.</h2>\n<p><strong>Note:</strong> The Card Token is not tested until it is used.</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [
        {
          "kind": "required",
          "name": "Api-Version",
          "type": "string",
          "example": "6.23",
          "description": "The version of this API."
        }
      ],
      "queryParameters": [],
      "bodyDataParameters": [
        {
          "kind": "required",
          "name": "body",
          "type": "object",
          "description": "Request is sent with full card details\n",
          "customType": "saveCardRequestPan",
          "schema": [
            {
              "name": "cardNumber",
              "kind": "required",
              "type": "string",
              "description": "REQUIRED. The unique number printed on a credit card (13 to 19 digits depending on card type).  Submitted without whitespace or non-numeric characters.",
              "example": "1234567890123456"
            },
            {
              "name": "expiryDate",
              "kind": "required",
              "type": "string",
              "description": "REQUIRED. The expiry date of the card in format MM/YY",
              "example": "01/28"
            },
            {
              "name": "startDate",
              "kind": "optional",
              "type": "string",
              "description": "For Maestro cards only, start date in format MM/YY",
              "example": "07/20"
            },
            {
              "name": "yourConsumerReference",
              "kind": "required",
              "type": "string",
              "description": "REQUIRED. Unique reference to anonymously identify your customer.  Advisable to use GUIDs.",
              "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
            },
            {
              "name": "judoId",
              "kind": "optional",
              "type": "string",
              "description": "Unique merchant and/or location ID supplied by Judopay.  Do not include spaces or dashes.  If not specified, then your default judoId will be used.",
              "example": "100100100"
            },
            {
              "name": "currency",
              "kind": "optional",
              "type": "string",
              "description": "The currency to use for the pre-authorisation, only required if different from the currency set during onboarding (default is GBP)",
              "example": "GBP"
            },
            {
              "name": "cardHolderName",
              "kind": "optional",
              "type": "string",
              "description": "The full name of the card holder, used in 3DS2 authentication.  Not required if the cardHolderName will be supplied on the 3DS2 transaction using the cardToken generated from this request. **Note:** When testing in the sandbox environment, it is the cardHolderName that is used to determine the test card for 3D Secure 2 authentication.",
              "example": "John Doe"
            },
            {
              "name": "disableNetworkTokenisation",
              "kind": "optional",
              "type": "boolean",
              "description": "(Optional) Set to true to specify that network tokenisation should not be used for this transaction, even\nif network token registration has been enabled on the account.\n",
              "example": true,
              "default": false
            },
            {
              "name": "cardAddress",
              "kind": "optional",
              "type": "object",
              "description": "",
              "modelRef": "#/components/schemas/cardAddressRequestAttributes",
              "customType": "cardAddressRequestAttributes",
              "schema": [],
              "complexType": "allOf",
              "complexItems": [
                {
                  "name": "cardAddressCommonAttributes",
                  "description": "",
                  "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                  "schema": [
                    {
                      "name": "address1",
                      "kind": "optional",
                      "type": "string",
                      "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                      "example": "CardHolder House"
                    },
                    {
                      "name": "address2",
                      "kind": "optional",
                      "type": "string",
                      "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                      "example": "1 CardHolder Street"
                    },
                    {
                      "name": "town",
                      "kind": "optional",
                      "type": "string",
                      "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                      "example": "CardHolder Town"
                    },
                    {
                      "name": "postCode",
                      "kind": "required",
                      "type": "string",
                      "description": "Postcode of the card holder's address.",
                      "example": "AB1 2CD"
                    },
                    {
                      "name": "state",
                      "kind": "optional",
                      "type": "string",
                      "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                      "example": "FL"
                    }
                  ]
                },
                {
                  "name": "object",
                  "description": "",
                  "schema": [
                    {
                      "name": "countryCode",
                      "kind": "optional",
                      "type": "string",
                      "description": "ISO 3166-1 (3 digit) country code of the card holder's address.",
                      "example": "826"
                    }
                  ]
                }
              ]
            }
          ],
          "modelRef": "#/components/schemas/saveCardRequestPan",
          "complexItems": [
            {
              "name": "object",
              "schema": [
                {
                  "name": "cardNumber",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. The unique number printed on a credit card (13 to 19 digits depending on card type).  Submitted without whitespace or non-numeric characters.",
                  "example": "1234567890123456"
                },
                {
                  "name": "expiryDate",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. The expiry date of the card in format MM/YY",
                  "example": "01/28"
                }
              ]
            },
            {
              "name": "object",
              "schema": [
                {
                  "name": "startDate",
                  "kind": "optional",
                  "type": "string",
                  "description": "For Maestro cards only, start date in format MM/YY",
                  "example": "07/20"
                }
              ],
              "modelRef": "#/components/schemas/cardDetailsStartDateRequest",
              "customType": "cardDetailsStartDateRequest"
            },
            {
              "name": "object",
              "schema": [
                {
                  "name": "yourConsumerReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique reference to anonymously identify your customer.  Advisable to use GUIDs.",
                  "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                },
                {
                  "name": "judoId",
                  "kind": "optional",
                  "type": "string",
                  "description": "Unique merchant and/or location ID supplied by Judopay.  Do not include spaces or dashes.  If not specified, then your default judoId will be used.",
                  "example": "100100100"
                },
                {
                  "name": "currency",
                  "kind": "optional",
                  "type": "string",
                  "description": "The currency to use for the pre-authorisation, only required if different from the currency set during onboarding (default is GBP)",
                  "example": "GBP"
                },
                {
                  "name": "cardHolderName",
                  "kind": "optional",
                  "type": "string",
                  "description": "The full name of the card holder, used in 3DS2 authentication.  Not required if the cardHolderName will be supplied on the 3DS2 transaction using the cardToken generated from this request. **Note:** When testing in the sandbox environment, it is the cardHolderName that is used to determine the test card for 3D Secure 2 authentication.",
                  "example": "John Doe"
                },
                {
                  "name": "disableNetworkTokenisation",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "(Optional) Set to true to specify that network tokenisation should not be used for this transaction, even\nif network token registration has been enabled on the account.\n",
                  "example": true,
                  "default": false
                },
                {
                  "name": "cardAddress",
                  "kind": "optional",
                  "type": "object",
                  "description": "",
                  "modelRef": "#/components/schemas/cardAddressRequestAttributes",
                  "customType": "cardAddressRequestAttributes",
                  "schema": [],
                  "complexType": "allOf",
                  "complexItems": [
                    {
                      "name": "cardAddressCommonAttributes",
                      "description": "",
                      "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                      "schema": [
                        {
                          "name": "address1",
                          "kind": "optional",
                          "type": "string",
                          "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder House"
                        },
                        {
                          "name": "address2",
                          "kind": "optional",
                          "type": "string",
                          "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "1 CardHolder Street"
                        },
                        {
                          "name": "town",
                          "kind": "optional",
                          "type": "string",
                          "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder Town"
                        },
                        {
                          "name": "postCode",
                          "kind": "required",
                          "type": "string",
                          "description": "Postcode of the card holder's address.",
                          "example": "AB1 2CD"
                        },
                        {
                          "name": "state",
                          "kind": "optional",
                          "type": "string",
                          "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                          "example": "FL"
                        }
                      ]
                    },
                    {
                      "name": "object",
                      "description": "",
                      "schema": [
                        {
                          "name": "countryCode",
                          "kind": "optional",
                          "type": "string",
                          "description": "ISO 3166-1 (3 digit) country code of the card holder's address.",
                          "example": "826"
                        }
                      ]
                    }
                  ]
                }
              ],
              "modelRef": "#/components/schemas/saveCardRequestCommon",
              "customType": "saveCardRequestCommon"
            }
          ],
          "complexType": "allOf",
          "isExpanded": true
        }
      ],
      "formDataParameters": [],
      "oAuthParameters": [
        {
          "id": "TokenSecretAuth",
          "name": "TokenSecretAuth",
          "kind": "optional",
          "type": "http",
          "description": "<p>This is the typical authorisation scenario to use, specify your token in Username and secret in Password.</p>\n<p>Sent as Base64 encoded string representing token</p><div></div> in Authorization header.<p></p>",
          "scheme": "basic"
        }
      ]
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "Successful response",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Successful response \n{\n  \"receiptId\": \"1001131610340495360\",\n  \"originalReceiptId\": \"1001124307998347264\",\n  \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n  \"type\": \"PreAuth\",\n  \"createdAt\": \"2025-02-05T16:28:32.8596+00:00\",\n  \"result\": \"Success\",\n  \"message\": \"AuthCode: 123456\",\n  \"judoId\": 100100100,\n  \"merchantName\": \"Test Merchant\",\n  \"appearsOnStatementAs\": \"APL*/TestMerchant       \",\n  \"originalAmount\": \"10.99\",\n  \"amountCollected\": \"1.99\",\n  \"netAmount\": \"1.00\",\n  \"amount\": \"1.00\",\n  \"currency\": \"GBP\",\n  \"recurringPaymentType\": \"MIT\",\n  \"acquirerTransactionId\": \"33666277256892153705\",\n  \"externalBankResponseCode\": \"A\",\n  \"authCode\": \"123456\",\n  \"walletType\": 1,\n  \"riskScore\": 0,\n  \"paymentNetworkTransactionId\": \"123456789012345\",\n  \"allowIncrement\": true,\n  \"isIncrementalAuth\": true,\n  \"emailAddress\": \"test.user@judopay.com\",\n  \"cardDetails\": {\n    \"cardLastfour\": \"1234\",\n    \"endDate\": \"1225\",\n    \"cardToken\": \"Ck3AeNlBfjvs9d61MNZiG0gtCvijqvKr\",\n    \"cardType\": 2,\n    \"startDate\": \"0121\",\n    \"cardScheme\": \"Mastercard\",\n    \"cardFunding\": \"Credit\",\n    \"cardCategory\": \"Acquirer Only\",\n    \"cardCountry\": \"GB\",\n    \"bank\": \"Santander Uk Plc\",\n    \"cardHolderName\": \"John Doe\",\n    \"ownerType\": \"Personal\"\n  },\n  \"billingAddress\": {},\n  \"consumer\": {\n    \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\"\n  },\n  \"device\": {\n    \"identifier\": \"d73b4a7b58ce4e54a3bd73b7eda061e6\"\n  },\n  \"yourPaymentMetaData\": {},\n  \"threeDSecure\": {\n    \"attempted\": true,\n    \"result\": \"PASSED\",\n    \"eci\": \"05\",\n    \"challengeRequestIndicator\": \"ChallengeMandated\",\n    \"scaExemption\": \"\"\n  },\n  \"risks\": {\n    \"postCodeCheck\": \"PASSED\",\n    \"cv2Check\": \"PASSED\",\n    \"merchantSuggestion\": \"Allow\"\n  },\n  \"disableNetworkTokenisation\": true,\n  \"networkTokenisationDetails\": {\n    \"networkTokenProvisioned\": true,\n    \"networkTokenUsed\": true,\n    \"virtualPan\": {\n      \"lastFour\": \"1234\",\n      \"expiryDate\": \"0129\"\n    }\n  }\n}"
          },
          {
            "label": "SaveCardWithCardHolderNameResponse",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "transactionReceiptResponse",
            "schema": [
              {
                "name": "receiptId",
                "kind": "optional",
                "type": "string",
                "description": "Judopay's reference for the transaction.",
                "example": "1001131610340495360"
              },
              {
                "name": "originalReceiptId",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] Judopay's reference for any linked transaction (for collections, refunds and voids)\n",
                "example": "1001124307998347264"
              },
              {
                "name": "yourPaymentReference",
                "kind": "optional",
                "type": "string",
                "description": "Your unique reference for this payment.",
                "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
              },
              {
                "name": "type",
                "kind": "optional",
                "type": "string<Payment | Refund | PreAuth | VOID | Collection | Save | Register | CheckCard>",
                "description": "The type of the transaction.",
                "example": "PreAuth"
              },
              {
                "name": "createdAt",
                "kind": "optional",
                "type": "string<date-time>",
                "description": "Date and time of creation.",
                "example": "2025-02-05T16:28:32.8596+00:00"
              },
              {
                "name": "result",
                "kind": "optional",
                "type": "string",
                "description": "Result of transaction.",
                "example": "Success"
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Message detailing the outcome.",
                "example": "AuthCode: 123456"
              },
              {
                "name": "judoId",
                "kind": "optional",
                "type": "integer",
                "description": "Unique merchant and/or location ID supplied by Judopay.",
                "example": 100100100
              },
              {
                "name": "merchantName",
                "kind": "optional",
                "type": "string",
                "description": "Merchant's trading name.",
                "example": "Test Merchant"
              },
              {
                "name": "appearsOnStatementAs",
                "kind": "optional",
                "type": "string",
                "description": "Merchant description as it appears on the consumer's statement.",
                "example": "APL*/TestMerchant       "
              },
              {
                "name": "originalAmount",
                "kind": "optional",
                "type": "string",
                "description": "Amount of original transaction (not affected by refunds or collections).",
                "example": "10.99"
              },
              {
                "name": "amountCollected",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional - PreAuth and Void only] Amount that has been collected on original pre-authorisation.\n",
                "example": "1.99"
              },
              {
                "name": "netAmount",
                "kind": "optional",
                "type": "string",
                "description": "For payments, preauths and voids this is equal to the amount on the request.  For incremental auths this is\nthe original preauth amount plus the total of all incremental auths. For collections, this is the original\npreauth amount plus the total of all incremental auths minus the total of all collections.  For refunds,\nthis is the original sale amount minus the total of all refunds.\n",
                "example": "1.00"
              },
              {
                "name": "amount",
                "kind": "optional",
                "type": "string",
                "description": "The amount of this transaction, for refunds and collections the amount that has been refunded or collected in this transaction.",
                "example": "1.00"
              },
              {
                "name": "currency",
                "kind": "optional",
                "type": "string",
                "description": "The ISO-217 alphabetic code of the currency of the transaction",
                "example": "GBP"
              },
              {
                "name": "recurringPaymentType",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] Type of recurring payment (RECURRING for scheduled, MIT for non-scheduled)\n",
                "example": "MIT"
              },
              {
                "name": "acquirerTransactionId",
                "kind": "optional",
                "type": "string",
                "description": "The unique ID of the transaction set by the acquirer.",
                "example": "33666277256892153705"
              },
              {
                "name": "externalBankResponseCode",
                "kind": "optional",
                "type": "string",
                "description": "Response code set by the acquirer.",
                "example": "A"
              },
              {
                "name": "authCode",
                "kind": "optional",
                "type": "string",
                "description": "Authorisation code set by acquirer",
                "example": "123456"
              },
              {
                "name": "walletType",
                "kind": "optional",
                "type": "integer",
                "description": "[Conditional] For digital wallet transactions, the type of wallet (1=ApplePay, 2=AndroidPay, 4=GooglePay)\n",
                "example": 1
              },
              {
                "name": "riskScore",
                "kind": "optional",
                "type": "integer",
                "description": "Consumers risk score\n",
                "example": 0
              },
              {
                "name": "paymentNetworkTransactionId",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] Unique identifier of the transaction returned by the payment network/ card scheme.\n",
                "example": "123456789012345"
              },
              {
                "name": "allowIncrement",
                "kind": "optional",
                "type": "boolean",
                "description": "[Conditional] true for customer initiated pre-auths that had the allowIncrement request attribute set to true\n",
                "example": true
              },
              {
                "name": "isIncrementalAuth",
                "kind": "optional",
                "type": "boolean",
                "description": "[Conditional] true for calls to POST /transactions/incrementalAuth\n",
                "example": true
              },
              {
                "name": "emailAddress",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] email address of consumer, if supplied on the request\n",
                "example": "test.user@judopay.com"
              },
              {
                "name": "cardDetails",
                "kind": "optional",
                "type": "object",
                "description": "",
                "modelRef": "#/components/schemas/cardDetailsResponse",
                "customType": "cardDetailsResponse",
                "schema": [
                  {
                    "name": "cardLastfour",
                    "kind": "optional",
                    "type": "string",
                    "description": "Last four digits of card",
                    "example": "1234"
                  },
                  {
                    "name": "endDate",
                    "kind": "optional",
                    "type": "string",
                    "description": "Card expiry date in format MMYY",
                    "example": "1225"
                  },
                  {
                    "name": "cardToken",
                    "kind": "optional",
                    "type": "string",
                    "description": "Tokenized representation of card which can be used in future transactions instead of card number",
                    "example": "Ck3AeNlBfjvs9d61MNZiG0gtCvijqvKr"
                  },
                  {
                    "name": "cardType",
                    "kind": "optional",
                    "type": "integer",
                    "description": "Integer representing the type of card, see Reference Codes - Card Types on https://docs.judopay.com/Content/Developer%20Tools/Codes.htm#CardTypes",
                    "example": 2
                  },
                  {
                    "name": "startDate",
                    "kind": "optional",
                    "type": "string",
                    "description": "Card start date in format MMYY",
                    "example": "0121"
                  },
                  {
                    "name": "cardScheme",
                    "kind": "optional",
                    "type": "string",
                    "description": "Name of card scheme (determined from matching start of card number against issuer data)",
                    "example": "Mastercard"
                  },
                  {
                    "name": "cardFunding",
                    "kind": "optional",
                    "type": "string",
                    "description": "Type of card (determined from matching start of card number against issuer data)",
                    "example": "Credit"
                  },
                  {
                    "name": "cardCategory",
                    "kind": "optional",
                    "type": "string",
                    "description": "Category of card (determined from matching start of card number against issuer data)",
                    "example": "Acquirer Only"
                  },
                  {
                    "name": "cardCountry",
                    "kind": "optional",
                    "type": "string",
                    "description": "ISO 3166-1 alpha-2 code of country that issued the card (determined from matching start of card number against issuer data)",
                    "example": "GB"
                  },
                  {
                    "name": "bank",
                    "kind": "optional",
                    "type": "string",
                    "description": "Name of bank that issued the card (determined from matching start of card number against issuer data)",
                    "example": "Santander Uk Plc"
                  },
                  {
                    "name": "cardHolderName",
                    "kind": "optional",
                    "type": "string",
                    "description": "Name of card holder as supplied on request",
                    "example": "John Doe"
                  },
                  {
                    "name": "ownerType",
                    "kind": "optional",
                    "type": "string<Personal | Commercial | >",
                    "description": "[Conditional] Indicator of whether a card is personal or commercial, if known\n",
                    "example": "Personal"
                  }
                ]
              },
              {
                "name": "billingAddress",
                "kind": "optional",
                "type": "object",
                "description": "",
                "modelRef": "#/components/schemas/cardAddressResponseAttributes",
                "customType": "cardAddressResponseAttributes",
                "schema": [],
                "complexType": "allOf",
                "complexItems": [
                  {
                    "name": "cardAddressCommonAttributes",
                    "description": "",
                    "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                    "schema": [
                      {
                        "name": "address1",
                        "kind": "optional",
                        "type": "string",
                        "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                        "example": "CardHolder House"
                      },
                      {
                        "name": "address2",
                        "kind": "optional",
                        "type": "string",
                        "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                        "example": "1 CardHolder Street"
                      },
                      {
                        "name": "town",
                        "kind": "optional",
                        "type": "string",
                        "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                        "example": "CardHolder Town"
                      },
                      {
                        "name": "postCode",
                        "kind": "required",
                        "type": "string",
                        "description": "Postcode of the card holder's address.",
                        "example": "AB1 2CD"
                      },
                      {
                        "name": "state",
                        "kind": "optional",
                        "type": "string",
                        "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                        "example": "FL"
                      }
                    ]
                  },
                  {
                    "name": "object",
                    "description": "",
                    "schema": [
                      {
                        "name": "countryCode",
                        "kind": "optional",
                        "type": "integer",
                        "description": "ISO 3166-1 (3 digit) country code of the card holder's address.   If the first digit of the\nof the code is 0 this will not be shown\n",
                        "example": 826
                      }
                    ]
                  }
                ]
              },
              {
                "name": "consumer",
                "kind": "optional",
                "type": "object",
                "description": "",
                "modelRef": "#/components/schemas/consumerResponse",
                "customType": "consumerResponse",
                "schema": [
                  {
                    "name": "yourConsumerReference",
                    "kind": "optional",
                    "type": "string",
                    "description": "Your unique reference to anonymously identify your customer.",
                    "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                  }
                ]
              },
              {
                "name": "device",
                "kind": "optional",
                "type": "object",
                "description": "[Conditional] If clientDetails was provided containing a kdeviceid\n",
                "modelRef": "#/components/schemas/deviceResponse",
                "customType": "deviceResponse",
                "schema": [
                  {
                    "name": "identifier",
                    "kind": "optional",
                    "type": "string",
                    "description": "Judopay generated GUID associated with the kdeviceid passed in the clientDetails request attribute",
                    "example": "d73b4a7b58ce4e54a3bd73b7eda061e6"
                  }
                ]
              },
              {
                "name": "yourPaymentMetaData",
                "kind": "optional",
                "type": "object",
                "description": "Merchant metadata passed with transaction request.\n",
                "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                "schema": []
              },
              {
                "name": "threeDSecure",
                "kind": "optional",
                "type": "object",
                "description": "[Conditional] Only returned for transactions using 3DS\n",
                "modelRef": "#/components/schemas/threeDSecureCompletedResponse",
                "customType": "threeDSecureCompletedResponse",
                "schema": [
                  {
                    "name": "attempted",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "Did the consumer attempt to authenticate through 3DSecure",
                    "example": true
                  },
                  {
                    "name": "result",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Outcome of the 3DSecure authentication, only present on initial receipt response, not historic receipts\n",
                    "example": "PASSED"
                  },
                  {
                    "name": "eci",
                    "kind": "optional",
                    "type": "string",
                    "description": "Electronic Commerce Indicator returned by 3DS servers indicating outcome of authentication",
                    "example": "05"
                  },
                  {
                    "name": "challengeRequestIndicator",
                    "kind": "optional",
                    "type": "string<NoPreference | NoChallenge | ChallengePreferred | ChallengeAsMandate | ChallengeWithWhitelistPrompt | >",
                    "description": "[Conditional] Challenge request indicator that was used for 3DS authentication\n",
                    "example": "ChallengeMandated"
                  },
                  {
                    "name": "scaExemption",
                    "kind": "optional",
                    "type": "string<TrustedBeneficiary | TransactionRiskAnalysis | DataShareOnly | ScaAlreadyPerformed | >",
                    "description": "[Conditional] SCA exemption that was used for 3DS authentication\n",
                    "example": ""
                  }
                ]
              },
              {
                "name": "risks",
                "kind": "optional",
                "type": "object",
                "description": "",
                "modelRef": "#/components/schemas/riskParametersResponse",
                "customType": "riskParametersResponse",
                "schema": [
                  {
                    "name": "postCodeCheck",
                    "kind": "optional",
                    "type": "string<PASSED | FAILED | UNKNOWN>",
                    "description": "Indication of whether supplied postCode was verified",
                    "example": "PASSED"
                  },
                  {
                    "name": "cv2Check",
                    "kind": "optional",
                    "type": "string<PASSED | FAILED | NOT_PROCESSED | NOT_SUBMITTED | NOT_SUPPORTED | NOT_CHECKED | SUSPICIOUS | UNKNOWN>",
                    "description": "Indication of whether supplied cv2 was verified",
                    "example": "PASSED"
                  },
                  {
                    "name": "merchantSuggestion",
                    "kind": "optional",
                    "type": "string",
                    "description": "Suggestion action for the merchant from the risk engine",
                    "example": "Allow"
                  }
                ]
              },
              {
                "name": "disableNetworkTokenisation",
                "kind": "optional",
                "type": "boolean",
                "description": "[Conditional] true if the request explicitly disabled network tokens for this transaction\n",
                "example": true
              },
              {
                "name": "networkTokenisationDetails",
                "kind": "optional",
                "type": "object",
                "description": "",
                "modelRef": "#/components/schemas/networkTokenisationDetailsResponse",
                "customType": "networkTokenisationDetailsResponse",
                "schema": [
                  {
                    "name": "networkTokenProvisioned",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "Indicates if a new network token was created during the course of this transaction",
                    "example": true
                  },
                  {
                    "name": "networkTokenUsed",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "Indicates if this transaction was completed using a network token",
                    "example": true
                  },
                  {
                    "name": "virtualPan",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "example": "",
                    "schema": [
                      {
                        "name": "lastFour",
                        "kind": "optional",
                        "type": "string",
                        "description": "Last four digits of the virtual PAN used",
                        "example": "1234"
                      },
                      {
                        "name": "expiryDate",
                        "kind": "optional",
                        "type": "string",
                        "description": "Expiry date of the virtual PAN in format MMYY",
                        "example": "0129"
                      }
                    ]
                  }
                ]
              }
            ],
            "modelRef": "#/components/schemas/transactionReceiptResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "400",
        "description": "Bad request if any of the required request parameters are not supplied",
        "jsonExample": "",
        "isExpanded": true
      },
      {
        "statusCode": "401",
        "description": "Unauthorized",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Unauthorized",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "403",
        "description": "Forbidden if token used does not have required permission",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Forbidden",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "4y1kt_M8olCuVGo-vqKfS",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location 'https://api-sandbox.judopay.com/transactions/savecard' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json' \\\n--header 'Api-Version: string' \\\n--data '{\n  \"cardNumber\": \"1234567890123456\",\n  \"expiryDate\": \"01/28\",\n  \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\",\n  \"cardAddress\": {\n    \"postCode\": \"AB1 2CD\"\n  }\n}'"
        },
        {
          "id": "lDNGA0MUGxKRW3Guzxo4X",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\nmyHeaders.append(\"Api-Version\", \"string\");\n\nvar raw = JSON.stringify({\n   \"cardNumber\": \"1234567890123456\",\n   \"expiryDate\": \"01/28\",\n   \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\",\n   \"cardAddress\": {\n      \"postCode\": \"AB1 2CD\"\n   }\n});\n\nvar requestOptions = {\n   method: 'POST',\n   headers: myHeaders,\n   body: raw,\n   redirect: 'follow'\n};\n\nfetch(\"https://api-sandbox.judopay.com/transactions/savecard\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "V2XlD3zZouoJ1gKWo6xB6",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api-sandbox.judopay.com/transactions/savecard\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Post.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\nrequest[\"Api-Version\"] = \"string\"\nrequest.body = JSON.dump({\n   \"cardNumber\": \"1234567890123456\",\n   \"expiryDate\": \"01/28\",\n   \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\",\n   \"cardAddress\": {\n      \"postCode\": \"AB1 2CD\"\n   }\n})\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "aN6zR8x1grf2pJEF3mR-o",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api-sandbox.judopay.com/transactions/savecard\"\n\npayload = json.dumps({\n   \"cardNumber\": \"1234567890123456\",\n   \"expiryDate\": \"01/28\",\n   \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\",\n   \"cardAddress\": {\n      \"postCode\": \"AB1 2CD\"\n   }\n})\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json',\n   'Api-Version': 'string'\n}\n\nresponse = requests.request(\"POST\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "4y1kt_M8olCuVGo-vqKfS"
    },
    "results": {
      "languages": [
        {
          "id": "-6R3ajq9ovAWtjaXv3LJQ",
          "language": "200",
          "code": "// Successful response \n{\n  \"receiptId\": \"1001131610340495360\",\n  \"originalReceiptId\": \"1001124307998347264\",\n  \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n  \"type\": \"PreAuth\",\n  \"createdAt\": \"2025-02-05T16:28:32.8596+00:00\",\n  \"result\": \"Success\",\n  \"message\": \"AuthCode: 123456\",\n  \"judoId\": 100100100,\n  \"merchantName\": \"Test Merchant\",\n  \"appearsOnStatementAs\": \"APL*/TestMerchant       \",\n  \"originalAmount\": \"10.99\",\n  \"amountCollected\": \"1.99\",\n  \"netAmount\": \"1.00\",\n  \"amount\": \"1.00\",\n  \"currency\": \"GBP\",\n  \"recurringPaymentType\": \"MIT\",\n  \"acquirerTransactionId\": \"33666277256892153705\",\n  \"externalBankResponseCode\": \"A\",\n  \"authCode\": \"123456\",\n  \"walletType\": 1,\n  \"riskScore\": 0,\n  \"paymentNetworkTransactionId\": \"123456789012345\",\n  \"allowIncrement\": true,\n  \"isIncrementalAuth\": true,\n  \"emailAddress\": \"test.user@judopay.com\",\n  \"cardDetails\": {\n    \"cardLastfour\": \"1234\",\n    \"endDate\": \"1225\",\n    \"cardToken\": \"Ck3AeNlBfjvs9d61MNZiG0gtCvijqvKr\",\n    \"cardType\": 2,\n    \"startDate\": \"0121\",\n    \"cardScheme\": \"Mastercard\",\n    \"cardFunding\": \"Credit\",\n    \"cardCategory\": \"Acquirer Only\",\n    \"cardCountry\": \"GB\",\n    \"bank\": \"Santander Uk Plc\",\n    \"cardHolderName\": \"John Doe\",\n    \"ownerType\": \"Personal\"\n  },\n  \"billingAddress\": {},\n  \"consumer\": {\n    \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\"\n  },\n  \"device\": {\n    \"identifier\": \"d73b4a7b58ce4e54a3bd73b7eda061e6\"\n  },\n  \"yourPaymentMetaData\": {},\n  \"threeDSecure\": {\n    \"attempted\": true,\n    \"result\": \"PASSED\",\n    \"eci\": \"05\",\n    \"challengeRequestIndicator\": \"ChallengeMandated\",\n    \"scaExemption\": \"\"\n  },\n  \"risks\": {\n    \"postCodeCheck\": \"PASSED\",\n    \"cv2Check\": \"PASSED\",\n    \"merchantSuggestion\": \"Allow\"\n  },\n  \"disableNetworkTokenisation\": true,\n  \"networkTokenisationDetails\": {\n    \"networkTokenProvisioned\": true,\n    \"networkTokenUsed\": true,\n    \"virtualPan\": {\n      \"lastFour\": \"1234\",\n      \"expiryDate\": \"0129\"\n    }\n  }\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Successful response \n{\n  \"receiptId\": \"1001131610340495360\",\n  \"originalReceiptId\": \"1001124307998347264\",\n  \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n  \"type\": \"PreAuth\",\n  \"createdAt\": \"2025-02-05T16:28:32.8596+00:00\",\n  \"result\": \"Success\",\n  \"message\": \"AuthCode: 123456\",\n  \"judoId\": 100100100,\n  \"merchantName\": \"Test Merchant\",\n  \"appearsOnStatementAs\": \"APL*/TestMerchant       \",\n  \"originalAmount\": \"10.99\",\n  \"amountCollected\": \"1.99\",\n  \"netAmount\": \"1.00\",\n  \"amount\": \"1.00\",\n  \"currency\": \"GBP\",\n  \"recurringPaymentType\": \"MIT\",\n  \"acquirerTransactionId\": \"33666277256892153705\",\n  \"externalBankResponseCode\": \"A\",\n  \"authCode\": \"123456\",\n  \"walletType\": 1,\n  \"riskScore\": 0,\n  \"paymentNetworkTransactionId\": \"123456789012345\",\n  \"allowIncrement\": true,\n  \"isIncrementalAuth\": true,\n  \"emailAddress\": \"test.user@judopay.com\",\n  \"cardDetails\": {\n    \"cardLastfour\": \"1234\",\n    \"endDate\": \"1225\",\n    \"cardToken\": \"Ck3AeNlBfjvs9d61MNZiG0gtCvijqvKr\",\n    \"cardType\": 2,\n    \"startDate\": \"0121\",\n    \"cardScheme\": \"Mastercard\",\n    \"cardFunding\": \"Credit\",\n    \"cardCategory\": \"Acquirer Only\",\n    \"cardCountry\": \"GB\",\n    \"bank\": \"Santander Uk Plc\",\n    \"cardHolderName\": \"John Doe\",\n    \"ownerType\": \"Personal\"\n  },\n  \"billingAddress\": {},\n  \"consumer\": {\n    \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\"\n  },\n  \"device\": {\n    \"identifier\": \"d73b4a7b58ce4e54a3bd73b7eda061e6\"\n  },\n  \"yourPaymentMetaData\": {},\n  \"threeDSecure\": {\n    \"attempted\": true,\n    \"result\": \"PASSED\",\n    \"eci\": \"05\",\n    \"challengeRequestIndicator\": \"ChallengeMandated\",\n    \"scaExemption\": \"\"\n  },\n  \"risks\": {\n    \"postCodeCheck\": \"PASSED\",\n    \"cv2Check\": \"PASSED\",\n    \"merchantSuggestion\": \"Allow\"\n  },\n  \"disableNetworkTokenisation\": true,\n  \"networkTokenisationDetails\": {\n    \"networkTokenProvisioned\": true,\n    \"networkTokenUsed\": true,\n    \"virtualPan\": {\n      \"lastFour\": \"1234\",\n      \"expiryDate\": \"0129\"\n    }\n  }\n}"
            },
            {
              "label": "SaveCardWithCardHolderNameResponse",
              "code": ""
            }
          ]
        },
        {
          "id": "VWXOEjX9t4VICCNeOiY_m",
          "language": "400",
          "code": "// Bad request if any of the required request parameters are not supplied \n"
        },
        {
          "id": "b9wPO05G-umNXktG6nUkU",
          "language": "401",
          "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Unauthorized",
              "code": ""
            }
          ]
        },
        {
          "id": "dl55V7FWmK9-LgAGYw60k",
          "language": "403",
          "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Forbidden",
              "code": ""
            }
          ]
        }
      ],
      "selectedLanguageId": "-6R3ajq9ovAWtjaXv3LJQ"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}