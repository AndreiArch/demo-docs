---
title: /transactions/{transactionType}
createdAt: Tue Feb 03 2026 08:50:33 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "8OuWkxSv6Pncfl7Te9Gzd",
  "type": "api-oas-v2",
  "data": {
    "method": "GET",
    "url": "https://api-sandbox.judopay.com/transactions/{transactionType}",
    "servers": [
      {
        "url": "https://api-sandbox.judopay.com/transactions/{transactionType}",
        "description": "Sandbox environment"
      }
    ],
    "name": "",
    "description": "<p>Return a list of transactions of the given transactionType associated with the given query.   Please note: The records returned by this endpoint should not be relied upon for real-time processing.</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [
        {
          "kind": "required",
          "name": "transactionType",
          "type": "string",
          "example": "payments",
          "description": "Type of transactions that are to be returned."
        }
      ],
      "headerParameters": [
        {
          "kind": "required",
          "name": "Api-Version",
          "type": "string",
          "example": "6.23",
          "description": "The version of this API."
        }
      ],
      "queryParameters": [
        {
          "kind": "optional",
          "name": "pageSize",
          "type": "integer",
          "example": 10,
          "description": "<p>The number of records to display per page (1-500).</p>",
          "default": 10
        },
        {
          "kind": "optional",
          "name": "offset",
          "type": "integer",
          "example": 0,
          "description": "<p>Zero-based index of the first record in page.   This should be a multiple of pageSize. e.g. with a pageSize of 100, offset would be 0,100,200 etc.</p>",
          "default": 0
        },
        {
          "kind": "optional",
          "name": "sort",
          "type": "string",
          "example": "time-descending",
          "description": "Determines how the list is sorted.",
          "default": "time-descending"
        },
        {
          "kind": "optional",
          "name": "from",
          "type": "string",
          "example": "28/01/2025",
          "description": "<p>Earliest date used to find transactions (DD/MM/YYYY).  Start of day in Europe/London timezone is assumed.  If from and to are both not specified, then transactions from the past month are queried.</p>"
        },
        {
          "kind": "optional",
          "name": "to",
          "type": "string",
          "example": "15/02/2025",
          "description": "<p>Latest date used to find transactions (DD/MM/YYYY).  Start of day in Europe/London timezone is assumed.  If from and to are both not specified, then transactions from the past month are queried.</p>"
        },
        {
          "kind": "optional",
          "name": "yourPaymentReference",
          "type": "string",
          "example": "d991e31f-81f0-49e0-82aa-80b7e5ffaacd",
          "description": "<p>If specified, will only match transactions with this yourPaymentReference.</p>"
        },
        {
          "kind": "optional",
          "name": "yourConsumerReference",
          "type": "string",
          "example": "61588279-231e-4413-a8bc-4ff08088278c",
          "description": "<p>If specified, will only match transactions with this yourConsumerReference.</p>"
        }
      ],
      "bodyDataParameters": [],
      "formDataParameters": [],
      "oAuthParameters": [
        {
          "id": "TokenSecretAuth",
          "name": "TokenSecretAuth",
          "kind": "optional",
          "type": "http",
          "description": "<p>This is the typical authorisation scenario to use, specify your token in Username and secret in Password.</p>\n<p>Sent as Base64 encoded string representing token</p><div></div> in Authorization header.<p></p>",
          "scheme": "basic"
        }
      ]
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "Successful response",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "listTransactionsResponse",
            "schema": [
              {
                "name": "resultCount",
                "kind": "optional",
                "type": "number",
                "description": "Total number of transactions that match the criteria.   Note: This is currently capped at 10000 for performance reasons\n",
                "example": 135
              },
              {
                "name": "pageSize",
                "kind": "optional",
                "type": "integer",
                "description": "Number of transactions to return in a page",
                "example": 10
              },
              {
                "name": "offset",
                "kind": "optional",
                "type": "integer",
                "description": "Zero-based index of first transaction in page",
                "example": 0
              },
              {
                "name": "results",
                "kind": "optional",
                "type": "array",
                "description": "A page of transaction results",
                "modelRef": "#/components/schemas/transactionReceiptListResponse",
                "customType": "transactionReceiptListResponse[]",
                "schema": [
                  {
                    "name": "receiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "Judopay's reference for the transaction.",
                    "example": "1001131610340495360"
                  },
                  {
                    "name": "originalReceiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Judopay's reference for any linked transaction (for collections, refunds and voids)\n",
                    "example": "1001124307998347264"
                  },
                  {
                    "name": "yourPaymentReference",
                    "kind": "optional",
                    "type": "string",
                    "description": "Your unique reference for this payment.",
                    "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
                  },
                  {
                    "name": "type",
                    "kind": "optional",
                    "type": "string<Payment | Refund | PreAuth | VOID | Collection | Save | Register | CheckCard>",
                    "description": "The type of the transaction.",
                    "example": "PreAuth"
                  },
                  {
                    "name": "createdAt",
                    "kind": "optional",
                    "type": "string<date-time>",
                    "description": "Date and time of creation.",
                    "example": "2025-02-05T16:28:32.8596+00:00"
                  },
                  {
                    "name": "result",
                    "kind": "optional",
                    "type": "string",
                    "description": "Result of transaction.",
                    "example": "Success"
                  },
                  {
                    "name": "message",
                    "kind": "optional",
                    "type": "string",
                    "description": "Message detailing the outcome.",
                    "example": "AuthCode: 123456"
                  },
                  {
                    "name": "judoId",
                    "kind": "optional",
                    "type": "integer",
                    "description": "Unique merchant and/or location ID supplied by Judopay.",
                    "example": 100100100
                  },
                  {
                    "name": "appearsOnStatementAs",
                    "kind": "optional",
                    "type": "string",
                    "description": "Merchant description as it appears on the consumer's statement.",
                    "example": "APL*/TestMerchant       "
                  },
                  {
                    "name": "originalAmount",
                    "kind": "optional",
                    "type": "string",
                    "description": "Amount of original transaction (not affected by refunds or collections).",
                    "example": "10.99"
                  },
                  {
                    "name": "amountCollected",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional - PreAuth and Register only] Amount that has been collected on original pre-authorisation.\n",
                    "example": "1.99"
                  },
                  {
                    "name": "netAmount",
                    "kind": "optional",
                    "type": "string",
                    "description": "For payments and refunds, this is the original sale amount mines the total of all refunds.   For preauths,\nincremental auths and collections, this is the original preauth amount plus the total of all incremental\nauths minus the total of all collections.  For voids, this is equal to the original preauth amount.\n",
                    "example": "1.00"
                  },
                  {
                    "name": "amount",
                    "kind": "optional",
                    "type": "string",
                    "description": "The amount of this transaction, for refunds and collections the amount that has been refunded or collected in this transaction.",
                    "example": "1.00"
                  },
                  {
                    "name": "currency",
                    "kind": "optional",
                    "type": "string",
                    "description": "The ISO-217 alphabetic code of the currency of the transaction",
                    "example": "GBP"
                  },
                  {
                    "name": "postCodeCheckResult",
                    "kind": "optional",
                    "type": "string",
                    "description": "Show results of post code checks\n",
                    "example": "Passed"
                  },
                  {
                    "name": "walletType",
                    "kind": "optional",
                    "type": "integer",
                    "description": "[Conditional] For digital wallet transactions, the type of wallet (1=ApplePay, 2=AndroidPay, 4=GooglePay)\n",
                    "example": 1
                  },
                  {
                    "name": "allowIncrement",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true for customer initiated pre-auths that had the allowIncrement request attribute set to true\n",
                    "example": true
                  },
                  {
                    "name": "isIncrementalAuth",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true for calls to POST /transactions/incrementalAuth\n",
                    "example": true
                  },
                  {
                    "name": "cardDetails",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/cardDetailsListResponse",
                    "customType": "cardDetailsListResponse",
                    "schema": [
                      {
                        "name": "cardLastfour",
                        "kind": "optional",
                        "type": "string",
                        "description": "Last four digits of card",
                        "example": "1234"
                      },
                      {
                        "name": "endDate",
                        "kind": "optional",
                        "type": "string",
                        "description": "Card expiry date in format MMYY",
                        "example": "1225"
                      },
                      {
                        "name": "cardType",
                        "kind": "optional",
                        "type": "integer",
                        "description": "Integer representing the type of card, see Reference Codes - Card Types on https://docs.judopay.com/Content/Developer%20Tools/Codes.htm#CardTypes",
                        "example": 2
                      }
                    ]
                  },
                  {
                    "name": "consumer",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/consumerResponse",
                    "customType": "consumerResponse",
                    "schema": [
                      {
                        "name": "yourConsumerReference",
                        "kind": "optional",
                        "type": "string",
                        "description": "Your unique reference to anonymously identify your customer.",
                        "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                      }
                    ]
                  },
                  {
                    "name": "yourPaymentMetaData",
                    "kind": "optional",
                    "type": "object",
                    "description": "Merchant metadata passed with transaction request.\n",
                    "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                    "schema": []
                  },
                  {
                    "name": "threeDSecure",
                    "kind": "optional",
                    "type": "object",
                    "description": "[Conditional] Only returned for transactions using 3DS\n",
                    "modelRef": "#/components/schemas/threeDSecureCompletedResponse",
                    "customType": "threeDSecureCompletedResponse",
                    "schema": [
                      {
                        "name": "attempted",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Did the consumer attempt to authenticate through 3DSecure",
                        "example": true
                      },
                      {
                        "name": "result",
                        "kind": "optional",
                        "type": "string",
                        "description": "[Conditional] Outcome of the 3DSecure authentication, only present on initial receipt response, not historic receipts\n",
                        "example": "PASSED"
                      },
                      {
                        "name": "eci",
                        "kind": "optional",
                        "type": "string",
                        "description": "Electronic Commerce Indicator returned by 3DS servers indicating outcome of authentication",
                        "example": "05"
                      },
                      {
                        "name": "challengeRequestIndicator",
                        "kind": "optional",
                        "type": "string<NoPreference | NoChallenge | ChallengePreferred | ChallengeAsMandate | ChallengeWithWhitelistPrompt | >",
                        "description": "[Conditional] Challenge request indicator that was used for 3DS authentication\n",
                        "example": "ChallengeMandated"
                      },
                      {
                        "name": "scaExemption",
                        "kind": "optional",
                        "type": "string<TrustedBeneficiary | TransactionRiskAnalysis | DataShareOnly | ScaAlreadyPerformed | >",
                        "description": "[Conditional] SCA exemption that was used for 3DS authentication\n",
                        "example": ""
                      }
                    ]
                  }
                ]
              },
              {
                "name": "sort",
                "kind": "optional",
                "type": "string",
                "description": "Sort order of the transactions as specified in the request",
                "example": "time-descending"
              }
            ],
            "modelRef": "#/components/schemas/listTransactionsResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "401",
        "description": "Unauthorized",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Unauthorized",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "403",
        "description": "Forbidden if token used does not have required permission",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Forbidden",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "yrpy8t1cBVhnb0xSPnwnO",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --globoff 'https://api-sandbox.judopay.com/transactions/{transactionType}?pageSize=10&offset=integer&sort=time-descending' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json' \\\n--header 'Api-Version: string'"
        },
        {
          "id": "5p6OulsuUfO8wdcfyYqsc",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\nmyHeaders.append(\"Api-Version\", \"string\");\n\nvar requestOptions = {\n   method: 'GET',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api-sandbox.judopay.com/transactions/{transactionType}?pageSize=10&offset=integer&sort=time-descending\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "jGOspj7GsdlNsPGQr6lv8",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api-sandbox.judopay.com/transactions/{transactionType}?pageSize=10&offset=integer&sort=time-descending\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Get.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\nrequest[\"Api-Version\"] = \"string\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "1EX0uILc58QLYpYfqCucT",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api-sandbox.judopay.com/transactions/{transactionType}?pageSize=10&offset=integer&sort=time-descending\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json',\n   'Api-Version': 'string'\n}\n\nresponse = requests.request(\"GET\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "yrpy8t1cBVhnb0xSPnwnO"
    },
    "results": {
      "languages": [
        {
          "id": "oYDz5s9qeudG0ollzfpmX",
          "language": "200",
          "code": "// Successful response \n{\n  \"resultCount\": 135,\n  \"pageSize\": 10,\n  \"offset\": 0,\n  \"results\": [\n    {\n      \"receiptId\": \"1001131610340495360\",\n      \"originalReceiptId\": \"1001124307998347264\",\n      \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n      \"type\": \"PreAuth\",\n      \"createdAt\": \"2025-02-05T16:28:32.8596+00:00\",\n      \"result\": \"Success\",\n      \"message\": \"AuthCode: 123456\",\n      \"judoId\": 100100100,\n      \"appearsOnStatementAs\": \"APL*/TestMerchant       \",\n      \"originalAmount\": \"10.99\",\n      \"amountCollected\": \"1.99\",\n      \"netAmount\": \"1.00\",\n      \"amount\": \"1.00\",\n      \"currency\": \"GBP\",\n      \"postCodeCheckResult\": \"Passed\",\n      \"walletType\": 1,\n      \"allowIncrement\": true,\n      \"isIncrementalAuth\": true,\n      \"cardDetails\": {\n        \"cardLastfour\": \"1234\",\n        \"endDate\": \"1225\",\n        \"cardType\": 2\n      },\n      \"consumer\": {\n        \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\"\n      },\n      \"yourPaymentMetaData\": {},\n      \"threeDSecure\": {\n        \"attempted\": true,\n        \"result\": \"PASSED\",\n        \"eci\": \"05\",\n        \"challengeRequestIndicator\": \"ChallengeMandated\",\n        \"scaExemption\": \"\"\n      }\n    }\n  ],\n  \"sort\": \"time-descending\"\n}"
        },
        {
          "id": "TZ3RuNN7VFqnjRKukkiHe",
          "language": "401",
          "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Unauthorized",
              "code": ""
            }
          ]
        },
        {
          "id": "guZ8EgQSqQ9l5EgFQ2v0V",
          "language": "403",
          "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Forbidden",
              "code": ""
            }
          ]
        }
      ],
      "selectedLanguageId": "oYDz5s9qeudG0ollzfpmX"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}