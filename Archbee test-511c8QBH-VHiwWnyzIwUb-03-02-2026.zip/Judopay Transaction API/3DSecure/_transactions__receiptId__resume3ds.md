---
title: /transactions/{receiptId}/resume3ds
createdAt: Tue Feb 03 2026 08:50:33 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "_eU3Fmk5QhGJ88BQctHQ9",
  "type": "api-oas-v2",
  "data": {
    "method": "PUT",
    "url": "https://api-sandbox.judopay.com/transactions/{receiptId}/resume3ds",
    "servers": [
      {
        "url": "https://api-sandbox.judopay.com/transactions/{receiptId}/resume3ds",
        "description": "Sandbox environment"
      }
    ],
    "name": "",
    "description": "<p>Use /resume3ds when authenticating with 3D Secure 2, following the 3D Secure 2 device details being successfully completed by the consumer.</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [
        {
          "kind": "required",
          "name": "receiptId",
          "type": "string",
          "example": "1001131610340495360",
          "description": "<p>Judopay’s reference, that identifies the transaction.  Get the receiptId from the response of the\ninitial request.</p>"
        }
      ],
      "headerParameters": [
        {
          "kind": "required",
          "name": "Api-Version",
          "type": "string",
          "example": "6.23",
          "description": "The version of this API."
        }
      ],
      "queryParameters": [],
      "bodyDataParameters": [
        {
          "kind": "required",
          "name": "body",
          "type": "object",
          "description": "",
          "customType": "resume3dsRequest",
          "schema": [
            {
              "name": "cv2",
              "kind": "optional",
              "type": "string",
              "description": "The 3 or 4 digit number on the back of a credit card. Also known as the card verification value (CVV) or security code.  If not specified, contact Judopay support to confirm gateway settings are configured to reflect this.",
              "example": "123"
            },
            {
              "name": "threeDSecure",
              "kind": "required",
              "type": "object",
              "description": "",
              "example": "",
              "schema": [
                {
                  "name": "methodCompletion",
                  "kind": "required",
                  "type": "string<Yes | No | Unavailable>",
                  "description": "REQUIRED. Indicates whether the 3D Secure method (device details) check was completed successfully.",
                  "example": "Yes"
                }
              ]
            },
            {
              "name": "primaryAccountDetails",
              "kind": "optional",
              "type": "object",
              "description": "Information about the primary account holder of the transaction.  Used for MCC 6012, MCC 6051 and MCC 7299 accounts only.  Does not need to be specified if these details were set on a payment session associated with this transaction.",
              "example": "",
              "schema": [
                {
                  "name": "name",
                  "kind": "required",
                  "type": "string",
                  "description": "Surname of the recipient as registered with the account.",
                  "example": "Doe"
                },
                {
                  "name": "accountNumber",
                  "kind": "required",
                  "type": "string",
                  "description": "Up to the first 10 digits of the primary account number of the recipient.",
                  "example": "12345678"
                },
                {
                  "name": "dateOfBirth",
                  "kind": "required",
                  "type": "string",
                  "description": "Date of birth of the recipient in yyyy-mm-dd format. If the recipient is a business, then the\nvalue should be set to \"0000-00-00\"\n",
                  "example": "1980-01-31"
                },
                {
                  "name": "postCode",
                  "kind": "required",
                  "type": "string",
                  "description": "Postcode registered against the recipient's account.",
                  "example": "AB1 2CD"
                }
              ]
            }
          ],
          "modelRef": "#/components/schemas/resume3dsRequest",
          "complexItems": [
            {
              "name": "object",
              "schema": [
                {
                  "name": "cv2",
                  "kind": "optional",
                  "type": "string",
                  "description": "The 3 or 4 digit number on the back of a credit card. Also known as the card verification value (CVV) or security code.  If not specified, contact Judopay support to confirm gateway settings are configured to reflect this.",
                  "example": "123"
                },
                {
                  "name": "threeDSecure",
                  "kind": "required",
                  "type": "object",
                  "description": "",
                  "example": "",
                  "schema": [
                    {
                      "name": "methodCompletion",
                      "kind": "required",
                      "type": "string<Yes | No | Unavailable>",
                      "description": "REQUIRED. Indicates whether the 3D Secure method (device details) check was completed successfully.",
                      "example": "Yes"
                    }
                  ]
                }
              ]
            },
            {
              "name": "object",
              "schema": [
                {
                  "name": "primaryAccountDetails",
                  "kind": "optional",
                  "type": "object",
                  "description": "Information about the primary account holder of the transaction.  Used for MCC 6012, MCC 6051 and MCC 7299 accounts only.  Does not need to be specified if these details were set on a payment session associated with this transaction.",
                  "example": "",
                  "schema": [
                    {
                      "name": "name",
                      "kind": "required",
                      "type": "string",
                      "description": "Surname of the recipient as registered with the account.",
                      "example": "Doe"
                    },
                    {
                      "name": "accountNumber",
                      "kind": "required",
                      "type": "string",
                      "description": "Up to the first 10 digits of the primary account number of the recipient.",
                      "example": "12345678"
                    },
                    {
                      "name": "dateOfBirth",
                      "kind": "required",
                      "type": "string",
                      "description": "Date of birth of the recipient in yyyy-mm-dd format. If the recipient is a business, then the\nvalue should be set to \"0000-00-00\"\n",
                      "example": "1980-01-31"
                    },
                    {
                      "name": "postCode",
                      "kind": "required",
                      "type": "string",
                      "description": "Postcode registered against the recipient's account.",
                      "example": "AB1 2CD"
                    }
                  ]
                }
              ],
              "modelRef": "#/components/schemas/primaryAccountDetailsRequest",
              "customType": "primaryAccountDetailsRequest"
            }
          ],
          "complexType": "allOf",
          "isExpanded": true
        }
      ],
      "formDataParameters": [],
      "oAuthParameters": [
        {
          "id": "TokenSecretAuth",
          "name": "TokenSecretAuth",
          "kind": "optional",
          "type": "http",
          "description": "<p>This is the typical authorisation scenario to use, specify your token in Username and secret in Password.</p>\n<p>Sent as Base64 encoded string representing token</p><div></div> in Authorization header.<p></p>",
          "scheme": "basic"
        },
        {
          "id": "PaymentSessionAuthToken",
          "name": "Api-Token",
          "kind": "optional",
          "type": "apiKey",
          "description": "<p>For Payment Session authentication, supply the token used to authenticate the call to generate a payment session</p>\n<p>PaymentSessionAuthReference section must also be completed.</p>",
          "in": "header"
        },
        {
          "id": "PaymentSessionAuthReference",
          "name": "Payment-Session",
          "kind": "optional",
          "type": "apiKey",
          "description": "<p>For Payment Session authentication, supply the reference returned in the create payment session response</p>\n<p>PaymentSessionAuthToken section must also be completed.</p>",
          "in": "header"
        }
      ]
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "Successful response",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "schema": [],
            "complexItems": [
              {
                "name": "object",
                "schema": [
                  {
                    "name": "receiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "Judopay's reference for the transaction.",
                    "example": "1001131610340495360"
                  },
                  {
                    "name": "originalReceiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Judopay's reference for any linked transaction (for collections, refunds and voids)\n",
                    "example": "1001124307998347264"
                  },
                  {
                    "name": "yourPaymentReference",
                    "kind": "optional",
                    "type": "string",
                    "description": "Your unique reference for this payment.",
                    "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
                  },
                  {
                    "name": "type",
                    "kind": "optional",
                    "type": "string<Payment | Refund | PreAuth | VOID | Collection | Save | Register | CheckCard>",
                    "description": "The type of the transaction.",
                    "example": "PreAuth"
                  },
                  {
                    "name": "createdAt",
                    "kind": "optional",
                    "type": "string<date-time>",
                    "description": "Date and time of creation.",
                    "example": "2025-02-05T16:28:32.8596+00:00"
                  },
                  {
                    "name": "result",
                    "kind": "optional",
                    "type": "string",
                    "description": "Result of transaction.",
                    "example": "Success"
                  },
                  {
                    "name": "message",
                    "kind": "optional",
                    "type": "string",
                    "description": "Message detailing the outcome.",
                    "example": "AuthCode: 123456"
                  },
                  {
                    "name": "judoId",
                    "kind": "optional",
                    "type": "integer",
                    "description": "Unique merchant and/or location ID supplied by Judopay.",
                    "example": 100100100
                  },
                  {
                    "name": "merchantName",
                    "kind": "optional",
                    "type": "string",
                    "description": "Merchant's trading name.",
                    "example": "Test Merchant"
                  },
                  {
                    "name": "appearsOnStatementAs",
                    "kind": "optional",
                    "type": "string",
                    "description": "Merchant description as it appears on the consumer's statement.",
                    "example": "APL*/TestMerchant       "
                  },
                  {
                    "name": "originalAmount",
                    "kind": "optional",
                    "type": "string",
                    "description": "Amount of original transaction (not affected by refunds or collections).",
                    "example": "10.99"
                  },
                  {
                    "name": "amountCollected",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional - PreAuth and Void only] Amount that has been collected on original pre-authorisation.\n",
                    "example": "1.99"
                  },
                  {
                    "name": "netAmount",
                    "kind": "optional",
                    "type": "string",
                    "description": "For payments, preauths and voids this is equal to the amount on the request.  For incremental auths this is\nthe original preauth amount plus the total of all incremental auths. For collections, this is the original\npreauth amount plus the total of all incremental auths minus the total of all collections.  For refunds,\nthis is the original sale amount minus the total of all refunds.\n",
                    "example": "1.00"
                  },
                  {
                    "name": "amount",
                    "kind": "optional",
                    "type": "string",
                    "description": "The amount of this transaction, for refunds and collections the amount that has been refunded or collected in this transaction.",
                    "example": "1.00"
                  },
                  {
                    "name": "currency",
                    "kind": "optional",
                    "type": "string",
                    "description": "The ISO-217 alphabetic code of the currency of the transaction",
                    "example": "GBP"
                  },
                  {
                    "name": "recurringPaymentType",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Type of recurring payment (RECURRING for scheduled, MIT for non-scheduled)\n",
                    "example": "MIT"
                  },
                  {
                    "name": "acquirerTransactionId",
                    "kind": "optional",
                    "type": "string",
                    "description": "The unique ID of the transaction set by the acquirer.",
                    "example": "33666277256892153705"
                  },
                  {
                    "name": "externalBankResponseCode",
                    "kind": "optional",
                    "type": "string",
                    "description": "Response code set by the acquirer.",
                    "example": "A"
                  },
                  {
                    "name": "authCode",
                    "kind": "optional",
                    "type": "string",
                    "description": "Authorisation code set by acquirer",
                    "example": "123456"
                  },
                  {
                    "name": "walletType",
                    "kind": "optional",
                    "type": "integer",
                    "description": "[Conditional] For digital wallet transactions, the type of wallet (1=ApplePay, 2=AndroidPay, 4=GooglePay)\n",
                    "example": 1
                  },
                  {
                    "name": "riskScore",
                    "kind": "optional",
                    "type": "integer",
                    "description": "Consumers risk score\n",
                    "example": 0
                  },
                  {
                    "name": "paymentNetworkTransactionId",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Unique identifier of the transaction returned by the payment network/ card scheme.\n",
                    "example": "123456789012345"
                  },
                  {
                    "name": "allowIncrement",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true for customer initiated pre-auths that had the allowIncrement request attribute set to true\n",
                    "example": true
                  },
                  {
                    "name": "isIncrementalAuth",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true for calls to POST /transactions/incrementalAuth\n",
                    "example": true
                  },
                  {
                    "name": "emailAddress",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] email address of consumer, if supplied on the request\n",
                    "example": "test.user@judopay.com"
                  },
                  {
                    "name": "cardDetails",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/cardDetailsResponse",
                    "customType": "cardDetailsResponse",
                    "schema": [
                      {
                        "name": "cardLastfour",
                        "kind": "optional",
                        "type": "string",
                        "description": "Last four digits of card",
                        "example": "1234"
                      },
                      {
                        "name": "endDate",
                        "kind": "optional",
                        "type": "string",
                        "description": "Card expiry date in format MMYY",
                        "example": "1225"
                      },
                      {
                        "name": "cardToken",
                        "kind": "optional",
                        "type": "string",
                        "description": "Tokenized representation of card which can be used in future transactions instead of card number",
                        "example": "Ck3AeNlBfjvs9d61MNZiG0gtCvijqvKr"
                      },
                      {
                        "name": "cardType",
                        "kind": "optional",
                        "type": "integer",
                        "description": "Integer representing the type of card, see Reference Codes - Card Types on https://docs.judopay.com/Content/Developer%20Tools/Codes.htm#CardTypes",
                        "example": 2
                      },
                      {
                        "name": "startDate",
                        "kind": "optional",
                        "type": "string",
                        "description": "Card start date in format MMYY",
                        "example": "0121"
                      },
                      {
                        "name": "cardScheme",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of card scheme (determined from matching start of card number against issuer data)",
                        "example": "Mastercard"
                      },
                      {
                        "name": "cardFunding",
                        "kind": "optional",
                        "type": "string",
                        "description": "Type of card (determined from matching start of card number against issuer data)",
                        "example": "Credit"
                      },
                      {
                        "name": "cardCategory",
                        "kind": "optional",
                        "type": "string",
                        "description": "Category of card (determined from matching start of card number against issuer data)",
                        "example": "Acquirer Only"
                      },
                      {
                        "name": "cardCountry",
                        "kind": "optional",
                        "type": "string",
                        "description": "ISO 3166-1 alpha-2 code of country that issued the card (determined from matching start of card number against issuer data)",
                        "example": "GB"
                      },
                      {
                        "name": "bank",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of bank that issued the card (determined from matching start of card number against issuer data)",
                        "example": "Santander Uk Plc"
                      },
                      {
                        "name": "cardHolderName",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of card holder as supplied on request",
                        "example": "John Doe"
                      },
                      {
                        "name": "ownerType",
                        "kind": "optional",
                        "type": "string<Personal | Commercial | >",
                        "description": "[Conditional] Indicator of whether a card is personal or commercial, if known\n",
                        "example": "Personal"
                      }
                    ]
                  },
                  {
                    "name": "billingAddress",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/cardAddressResponseAttributes",
                    "customType": "cardAddressResponseAttributes",
                    "schema": [],
                    "complexType": "allOf",
                    "complexItems": [
                      {
                        "name": "cardAddressCommonAttributes",
                        "description": "",
                        "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                        "schema": [
                          {
                            "name": "address1",
                            "kind": "optional",
                            "type": "string",
                            "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                            "example": "CardHolder House"
                          },
                          {
                            "name": "address2",
                            "kind": "optional",
                            "type": "string",
                            "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                            "example": "1 CardHolder Street"
                          },
                          {
                            "name": "town",
                            "kind": "optional",
                            "type": "string",
                            "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                            "example": "CardHolder Town"
                          },
                          {
                            "name": "postCode",
                            "kind": "required",
                            "type": "string",
                            "description": "Postcode of the card holder's address.",
                            "example": "AB1 2CD"
                          },
                          {
                            "name": "state",
                            "kind": "optional",
                            "type": "string",
                            "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                            "example": "FL"
                          }
                        ]
                      },
                      {
                        "name": "object",
                        "description": "",
                        "schema": [
                          {
                            "name": "countryCode",
                            "kind": "optional",
                            "type": "integer",
                            "description": "ISO 3166-1 (3 digit) country code of the card holder's address.   If the first digit of the\nof the code is 0 this will not be shown\n",
                            "example": 826
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "name": "consumer",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/consumerResponse",
                    "customType": "consumerResponse",
                    "schema": [
                      {
                        "name": "yourConsumerReference",
                        "kind": "optional",
                        "type": "string",
                        "description": "Your unique reference to anonymously identify your customer.",
                        "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                      }
                    ]
                  },
                  {
                    "name": "device",
                    "kind": "optional",
                    "type": "object",
                    "description": "[Conditional] If clientDetails was provided containing a kdeviceid\n",
                    "modelRef": "#/components/schemas/deviceResponse",
                    "customType": "deviceResponse",
                    "schema": [
                      {
                        "name": "identifier",
                        "kind": "optional",
                        "type": "string",
                        "description": "Judopay generated GUID associated with the kdeviceid passed in the clientDetails request attribute",
                        "example": "d73b4a7b58ce4e54a3bd73b7eda061e6"
                      }
                    ]
                  },
                  {
                    "name": "yourPaymentMetaData",
                    "kind": "optional",
                    "type": "object",
                    "description": "Merchant metadata passed with transaction request.\n",
                    "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                    "schema": []
                  },
                  {
                    "name": "threeDSecure",
                    "kind": "optional",
                    "type": "object",
                    "description": "[Conditional] Only returned for transactions using 3DS\n",
                    "modelRef": "#/components/schemas/threeDSecureCompletedResponse",
                    "customType": "threeDSecureCompletedResponse",
                    "schema": [
                      {
                        "name": "attempted",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Did the consumer attempt to authenticate through 3DSecure",
                        "example": true
                      },
                      {
                        "name": "result",
                        "kind": "optional",
                        "type": "string",
                        "description": "[Conditional] Outcome of the 3DSecure authentication, only present on initial receipt response, not historic receipts\n",
                        "example": "PASSED"
                      },
                      {
                        "name": "eci",
                        "kind": "optional",
                        "type": "string",
                        "description": "Electronic Commerce Indicator returned by 3DS servers indicating outcome of authentication",
                        "example": "05"
                      },
                      {
                        "name": "challengeRequestIndicator",
                        "kind": "optional",
                        "type": "string<NoPreference | NoChallenge | ChallengePreferred | ChallengeAsMandate | ChallengeWithWhitelistPrompt | >",
                        "description": "[Conditional] Challenge request indicator that was used for 3DS authentication\n",
                        "example": "ChallengeMandated"
                      },
                      {
                        "name": "scaExemption",
                        "kind": "optional",
                        "type": "string<TrustedBeneficiary | TransactionRiskAnalysis | DataShareOnly | ScaAlreadyPerformed | >",
                        "description": "[Conditional] SCA exemption that was used for 3DS authentication\n",
                        "example": ""
                      }
                    ]
                  },
                  {
                    "name": "risks",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/riskParametersResponse",
                    "customType": "riskParametersResponse",
                    "schema": [
                      {
                        "name": "postCodeCheck",
                        "kind": "optional",
                        "type": "string<PASSED | FAILED | UNKNOWN>",
                        "description": "Indication of whether supplied postCode was verified",
                        "example": "PASSED"
                      },
                      {
                        "name": "cv2Check",
                        "kind": "optional",
                        "type": "string<PASSED | FAILED | NOT_PROCESSED | NOT_SUBMITTED | NOT_SUPPORTED | NOT_CHECKED | SUSPICIOUS | UNKNOWN>",
                        "description": "Indication of whether supplied cv2 was verified",
                        "example": "PASSED"
                      },
                      {
                        "name": "merchantSuggestion",
                        "kind": "optional",
                        "type": "string",
                        "description": "Suggestion action for the merchant from the risk engine",
                        "example": "Allow"
                      }
                    ]
                  },
                  {
                    "name": "disableNetworkTokenisation",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true if the request explicitly disabled network tokens for this transaction\n",
                    "example": true
                  },
                  {
                    "name": "networkTokenisationDetails",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/networkTokenisationDetailsResponse",
                    "customType": "networkTokenisationDetailsResponse",
                    "schema": [
                      {
                        "name": "networkTokenProvisioned",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Indicates if a new network token was created during the course of this transaction",
                        "example": true
                      },
                      {
                        "name": "networkTokenUsed",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Indicates if this transaction was completed using a network token",
                        "example": true
                      },
                      {
                        "name": "virtualPan",
                        "kind": "optional",
                        "type": "object",
                        "description": "",
                        "example": "",
                        "schema": [
                          {
                            "name": "lastFour",
                            "kind": "optional",
                            "type": "string",
                            "description": "Last four digits of the virtual PAN used",
                            "example": "1234"
                          },
                          {
                            "name": "expiryDate",
                            "kind": "optional",
                            "type": "string",
                            "description": "Expiry date of the virtual PAN in format MMYY",
                            "example": "0129"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "modelRef": "#/components/schemas/transactionReceiptResponse",
                "customType": "transactionReceiptResponse"
              },
              {
                "name": "object",
                "schema": [
                  {
                    "name": "challengeUrl",
                    "kind": "optional",
                    "type": "string",
                    "description": "URL to direct consumer to to complete challenge",
                    "example": "https://acs2.test.gpe.cz/tds/challenge/brw/ea510e00-90ab-41eb-8a54-482e20fc2a36"
                  },
                  {
                    "name": "cReq",
                    "kind": "optional",
                    "type": "string",
                    "description": "Encoded value that should be POSTed to the challengeUrl",
                    "example": "ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjEuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICI4ZThkNjZlNy0zZjVjLTQxNDItOTllMi1jZjhhYTg4MGExMzEiLAogICJhY3NUcmFuc0lEIiA6ICJlYTUxMGUwMC05MGFiLTQxZWItOGE1NC00ODJlMjBmYzJhMzYiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwMSIKfQ=="
                  },
                  {
                    "name": "version",
                    "kind": "optional",
                    "type": "string",
                    "description": "ThreeDSecure version",
                    "example": "2.2.0"
                  },
                  {
                    "name": "receiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "Judopay's reference for the transaction.",
                    "example": "1001131610340495360"
                  },
                  {
                    "name": "result",
                    "kind": "optional",
                    "type": "string",
                    "description": "Result of transaction .",
                    "example": "Challenge completion is needed for 3D Secure 2"
                  },
                  {
                    "name": "message",
                    "kind": "optional",
                    "type": "string",
                    "description": "Message detailing the outcome.",
                    "example": "Issuer ACS has responded with a Challenge URL"
                  },
                  {
                    "name": "md",
                    "kind": "optional",
                    "type": "string",
                    "description": "Encoded string representing ThreeDSecure transaction details.",
                    "example": "ewogICJ0aHJlZURTU2VydmVyVHJhbnNJRCIgOiAiOGU4ZDY2ZTctM2Y1Yy00MTQyLTk5ZTItY2Y4YWE4ODBhMTMxIiwKICAidGhyZWVEU01ldGhvZE5vdGlmaWNhdGlvblVSTCIgOiAiaHR0cHM6Ly9hcGkua2FyYXRlcGF5LmNvbS9vcmRlci8zZHMvbWV0aG9kTm90aWZpY2F0aW9uIgp9"
                  }
                ],
                "modelRef": "#/components/schemas/threeDSecureTwoChallengeRequiredResponse",
                "customType": "threeDSecureTwoChallengeRequiredResponse"
              }
            ],
            "complexType": "oneOf",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "400",
        "description": "Bad request (Api-Version header missing, or request body attributes invalid)",
        "jsonExample": "",
        "isExpanded": true
      },
      {
        "statusCode": "401",
        "description": "Unauthorized",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Unauthorized",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "DP5AJw1XmV4pypiuJwoYb",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --globoff --request PUT 'https://api-sandbox.judopay.com/transactions/{receiptId}/resume3ds' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json' \\\n--header 'Api-Version: string' \\\n--data '{\n  \"threeDSecure\": {\n    \"methodCompletion\": \"Yes\"\n  },\n  \"primaryAccountDetails\": {\n    \"name\": \"Doe\",\n    \"accountNumber\": \"12345678\",\n    \"dateOfBirth\": \"1980-01-31\",\n    \"postCode\": \"AB1 2CD\"\n  }\n}'"
        },
        {
          "id": "ER9uteBzgKv0NZ4WhEs3I",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\nmyHeaders.append(\"Api-Version\", \"string\");\n\nvar raw = JSON.stringify({\n   \"threeDSecure\": {\n      \"methodCompletion\": \"Yes\"\n   },\n   \"primaryAccountDetails\": {\n      \"name\": \"Doe\",\n      \"accountNumber\": \"12345678\",\n      \"dateOfBirth\": \"1980-01-31\",\n      \"postCode\": \"AB1 2CD\"\n   }\n});\n\nvar requestOptions = {\n   method: 'PUT',\n   headers: myHeaders,\n   body: raw,\n   redirect: 'follow'\n};\n\nfetch(\"https://api-sandbox.judopay.com/transactions/{receiptId}/resume3ds\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "ZBso-UUeHbEn0W_C4pLDh",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api-sandbox.judopay.com/transactions/{receiptId}/resume3ds\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Put.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\nrequest[\"Api-Version\"] = \"string\"\nrequest.body = JSON.dump({\n   \"threeDSecure\": {\n      \"methodCompletion\": \"Yes\"\n   },\n   \"primaryAccountDetails\": {\n      \"name\": \"Doe\",\n      \"accountNumber\": \"12345678\",\n      \"dateOfBirth\": \"1980-01-31\",\n      \"postCode\": \"AB1 2CD\"\n   }\n})\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "Sih6WS-svbta1oYWZMQVo",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api-sandbox.judopay.com/transactions/{receiptId}/resume3ds\"\n\npayload = json.dumps({\n   \"threeDSecure\": {\n      \"methodCompletion\": \"Yes\"\n   },\n   \"primaryAccountDetails\": {\n      \"name\": \"Doe\",\n      \"accountNumber\": \"12345678\",\n      \"dateOfBirth\": \"1980-01-31\",\n      \"postCode\": \"AB1 2CD\"\n   }\n})\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json',\n   'Api-Version': 'string'\n}\n\nresponse = requests.request(\"PUT\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "DP5AJw1XmV4pypiuJwoYb"
    },
    "results": {
      "languages": [
        {
          "id": "xOLdMROwUWfq9X1_gGd4t",
          "language": "200",
          "code": "// Successful response \n{}"
        },
        {
          "id": "QysWqKnUSNFV51jEscMDp",
          "language": "400",
          "code": "// Bad request (Api-Version header missing, or request body attributes invalid) \n"
        },
        {
          "id": "uIlsq835whXOyw4C5Et2z",
          "language": "401",
          "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Unauthorized",
              "code": ""
            }
          ]
        }
      ],
      "selectedLanguageId": "xOLdMROwUWfq9X1_gGd4t"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}