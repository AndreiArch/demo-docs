---
title: Cancel an open payment session
createdAt: Tue Feb 03 2026 08:50:33 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "fwTC4W41j9GwNWVlgvB96",
  "type": "api-oas-v2",
  "data": {
    "method": "PUT",
    "url": "https://api-sandbox.judopay.com/paymentsession/{reference}/cancel",
    "servers": [
      {
        "url": "https://api-sandbox.judopay.com/paymentsession/{reference}/cancel",
        "description": "Sandbox environment"
      }
    ],
    "name": "Cancel an open payment session",
    "description": "<p>Update the status of an Open payment session to Cancelled, preventing it from being used in the future.</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [
        {
          "kind": "required",
          "name": "reference",
          "type": "string",
          "example": "5QcAAAMAAAAKAAAACwAAADFDcIhHlx3-cY5r3uSHYqRSp-Mliyb_6iBtmJfkgy4pUWDeRg",
          "description": "<p>Judo reference for a payment session, returned in response to creation of session.</p>"
        }
      ],
      "headerParameters": [
        {
          "kind": "required",
          "name": "Api-Version",
          "type": "string",
          "example": "6.23",
          "description": "The version of this API."
        }
      ],
      "queryParameters": [],
      "bodyDataParameters": [
        {
          "kind": "required",
          "name": "body",
          "type": "object",
          "description": "",
          "schema": [],
          "isExpanded": true
        }
      ],
      "formDataParameters": [],
      "oAuthParameters": [
        {
          "id": "TokenSecretAuth",
          "name": "TokenSecretAuth",
          "kind": "optional",
          "type": "http",
          "description": "<p>This is the typical authorisation scenario to use, specify your token in Username and secret in Password.</p>\n<p>Sent as Base64 encoded string representing token</p><div></div> in Authorization header.<p></p>",
          "scheme": "basic"
        }
      ]
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "Successful response",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "paymentSessionCancelResponse",
            "schema": [
              {
                "name": "reference",
                "kind": "optional",
                "type": "string",
                "description": "Judo internal reference for this payment session.",
                "example": "5QcAAAQAAAAPAAAACAAAABtGgvhBrF9BHTN7nqn1e0J4hVVmi-y27dGPjWBMtls3Gj_XDg"
              },
              {
                "name": "status",
                "kind": "optional",
                "type": "string",
                "description": "New status of payment session.",
                "example": "Cancelled"
              }
            ],
            "modelRef": "#/components/schemas/paymentSessionCancelResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "400",
        "description": "Bad request (Api-Version header missing, or payment session is not in Open status)",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Bad request (Api-Version header missing, or payment session is not in Open status) \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Payment Session not open",
            "code": ""
          },
          {
            "label": "Api-Version missing",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "401",
        "description": "Unauthorized",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Unauthorized",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "403",
        "description": "Forbidden if token used does not have required permission",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Forbidden",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "404",
        "description": "Payment session reference not found",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Payment session reference not found \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Reference not found",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "vzr0B1gdnxP53t1TkRvKE",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --globoff --request PUT 'https://api-sandbox.judopay.com/paymentsession/{reference}/cancel' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json' \\\n--header 'Api-Version: string'"
        },
        {
          "id": "lb6uRA8xxXWm-Lru8EKrG",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\nmyHeaders.append(\"Api-Version\", \"string\");\n\nvar requestOptions = {\n   method: 'PUT',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api-sandbox.judopay.com/paymentsession/{reference}/cancel\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "ptXPLaUnfA3ceAYD8257W",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api-sandbox.judopay.com/paymentsession/{reference}/cancel\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Put.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\nrequest[\"Api-Version\"] = \"string\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "9OioDnko2egdS9zqyJwlv",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api-sandbox.judopay.com/paymentsession/{reference}/cancel\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json',\n   'Api-Version': 'string'\n}\n\nresponse = requests.request(\"PUT\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "vzr0B1gdnxP53t1TkRvKE"
    },
    "results": {
      "languages": [
        {
          "id": "ukRdjt1V_aOOlPXVmi4Pz",
          "language": "200",
          "code": "// Successful response \n{\n  \"reference\": \"5QcAAAQAAAAPAAAACAAAABtGgvhBrF9BHTN7nqn1e0J4hVVmi-y27dGPjWBMtls3Gj_XDg\",\n  \"status\": \"Cancelled\"\n}"
        },
        {
          "id": "SmdddtKtSPYN-e-Jap-aE",
          "language": "400",
          "code": "// Bad request (Api-Version header missing, or payment session is not in Open status) \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Bad request (Api-Version header missing, or payment session is not in Open status) \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Payment Session not open",
              "code": ""
            },
            {
              "label": "Api-Version missing",
              "code": ""
            }
          ]
        },
        {
          "id": "9RodceMDKZqolIzqN-so3",
          "language": "401",
          "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Unauthorized",
              "code": ""
            }
          ]
        },
        {
          "id": "BXaIr-EgCe5keYO0a_xOH",
          "language": "403",
          "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Forbidden",
              "code": ""
            }
          ]
        },
        {
          "id": "i5-0dKmLlnIRoelsVXoWV",
          "language": "404",
          "code": "// Payment session reference not found \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Payment session reference not found \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Reference not found",
              "code": ""
            }
          ]
        }
      ],
      "selectedLanguageId": "ukRdjt1V_aOOlPXVmi4Pz"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}