---
title: Create a generic payment session
createdAt: Tue Feb 03 2026 08:50:33 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "eMG9yKW13TQG5DW7PjX--",
  "type": "api-oas-v2",
  "data": {
    "method": "POST",
    "url": "https://api-sandbox.judopay.com/paymentsession",
    "servers": [
      {
        "url": "https://api-sandbox.judopay.com/paymentsession",
        "description": "Sandbox environment"
      }
    ],
    "name": "Create a generic payment session",
    "description": "Create a payment session without specifying a payment operation.  webPaymentOperation will be 0.\n",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [
        {
          "kind": "required",
          "name": "Api-Version",
          "type": "string",
          "example": "6.23",
          "description": "The version of this API."
        }
      ],
      "queryParameters": [],
      "bodyDataParameters": [
        {
          "kind": "required",
          "name": "body",
          "type": "object",
          "description": "",
          "customType": "paymentSessionRequestForPreAuths",
          "schema": [
            {
              "name": "judoId",
              "kind": "required",
              "type": "string",
              "description": "REQUIRED. Unique merchant and/or location ID supplied by Judopay.  Do not include spaces or dashes.  If not specified, then your default judoId will be used.",
              "example": "100100100"
            },
            {
              "name": "yourConsumerReference",
              "kind": "required",
              "type": "string",
              "description": "REQUIRED. Unique reference to anonymously identify your customer.  Advisable to use GUIDs.",
              "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
            },
            {
              "name": "yourPaymentReference",
              "kind": "required",
              "type": "string",
              "description": "REQUIRED. Your unique reference for this payment. This value should be unique in order to protect your customers against duplicate transactions. With a server side integration, if a payment reference is not supplied, the transaction will not be processed.",
              "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
            },
            {
              "name": "yourPaymentMetaData",
              "kind": "required",
              "type": "object",
              "description": "Optional key-value map for additional metadata associated with this transaction.   Will be stored but not processed or passed to gateways.   Do not include sensitive information like card numbers.",
              "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
              "schema": []
            },
            {
              "name": "currency",
              "kind": "required",
              "type": "string",
              "description": "The ISO-4217 alphabetic code for the currency to use for the transaction, only required if different from the currency set during onboarding (default is GBP)",
              "example": "GBP"
            },
            {
              "name": "amount",
              "kind": "optional",
              "type": "number<float>",
              "description": "The amount to process. Format for default currencies is to two decimal places.  For currencies using a different structure please contact Judopay for support.",
              "example": 10.99
            },
            {
              "name": "cardAddress",
              "kind": "optional",
              "type": "object",
              "description": "",
              "modelRef": "#/components/schemas/cardAddressWebPaymentRequest",
              "customType": "cardAddressWebPaymentRequest",
              "schema": [],
              "complexType": "allOf",
              "complexItems": [
                {
                  "name": "cardAddressRequestAttributes",
                  "description": "",
                  "modelRef": "#/components/schemas/cardAddressRequestAttributes",
                  "schema": [
                    {
                      "name": "address1",
                      "kind": "required",
                      "type": "string",
                      "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                      "example": "CardHolder House"
                    },
                    {
                      "name": "address2",
                      "kind": "required",
                      "type": "string",
                      "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                      "example": "1 CardHolder Street"
                    },
                    {
                      "name": "town",
                      "kind": "required",
                      "type": "string",
                      "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                      "example": "CardHolder Town"
                    },
                    {
                      "name": "postCode",
                      "kind": "required",
                      "type": "string",
                      "description": "Postcode of the card holder's address.",
                      "example": "AB1 2CD"
                    },
                    {
                      "name": "state",
                      "kind": "required",
                      "type": "string",
                      "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                      "example": "FL"
                    },
                    {
                      "name": "countryCode",
                      "kind": "required",
                      "type": "string",
                      "description": "ISO 3166-1 (3 digit) country code of the card holder's address.",
                      "example": "826"
                    }
                  ]
                },
                {
                  "name": "object",
                  "description": "",
                  "schema": [
                    {
                      "name": "cardHolderName",
                      "kind": "optional",
                      "type": "string",
                      "description": "Name of card holder.",
                      "example": "John Doe"
                    }
                  ]
                }
              ]
            },
            {
              "name": "expiryDate",
              "kind": "optional",
              "type": "string<date-time>",
              "description": "Date and time of expiry (default is 30 minutes from creation)",
              "example": "2026-02-05T16:28:32.8596+00:00"
            },
            {
              "name": "isPayByLink",
              "kind": "optional",
              "type": "boolean",
              "description": "Flag indicating whether this session should be shown in the Pay By Link section in Portal.",
              "example": "",
              "default": false
            },
            {
              "name": "isJudoAccept",
              "kind": "optional",
              "type": "boolean",
              "description": "Flag indicating whether this session should be shown in the Judo Accept section in Portal.",
              "example": "",
              "default": false
            },
            {
              "name": "successUrl",
              "kind": "optional",
              "type": "string",
              "description": "For web payments, this is the URL to which the customer is redirected if their transaction is successful.  If not set, then the default success url specified on your account is used.\n",
              "example": "https://my.site.com/success"
            },
            {
              "name": "cancelUrl",
              "kind": "optional",
              "type": "string",
              "description": "For web payments, this is the URL to which the customer is redirected if they cancel the transaction or if the transaction fails.  If not set, then the default cancel url specified on your account is used.\n",
              "example": "https://my.site.com/cancel"
            },
            {
              "name": "emailAddress",
              "kind": "optional",
              "type": "string",
              "description": "(Optional) Email address of consumer, recommended but not required for 3DS2 authentication.",
              "example": "test.user@judopay.com"
            },
            {
              "name": "mobileNumber",
              "kind": "optional",
              "type": "string",
              "description": "(Optional) Phone number of consumer, recommended for 3DS2 authentication, but not required.   Must be set if phoneCountryCode is set.",
              "example": "7999999999"
            },
            {
              "name": "phoneCountryCode",
              "kind": "optional",
              "type": "string",
              "description": "(Optional) Phone country code matching mobileNumber, recommended for 3DS2 authentication, but not required.   Should be set if mobileNumber is set, defaulted to 44 if not.",
              "example": "44",
              "default": "44"
            },
            {
              "name": "threeDSecure",
              "kind": "optional",
              "type": "object",
              "description": "",
              "example": "",
              "schema": [
                {
                  "name": "challengeRequestIndicator",
                  "kind": "optional",
                  "type": "string",
                  "description": "Indicates whether a challenge is requested for this transaction (this may be over-ruled by the issuer).   Should not be specified in the same request as scaExemption\n",
                  "example": "challengePreferred",
                  "default": "noPreference",
                  "modelRef": "#/components/schemas/challengeRequestIndicatorRequest",
                  "customType": "challengeRequestIndicatorRequest",
                  "schema": []
                },
                {
                  "name": "scaExemption",
                  "kind": "optional",
                  "type": "string",
                  "description": "Indicates reason why challenge may not be necessary (this may be over-ruled by the issuer).   Should not be specified in the same request as challengeRequestIndicator\n",
                  "example": "transactionRiskAnalysis",
                  "modelRef": "#/components/schemas/scaExemptionRequest",
                  "customType": "scaExemptionRequest",
                  "schema": []
                }
              ]
            },
            {
              "name": "hideBillingInfo",
              "kind": "optional",
              "type": "boolean",
              "description": "(Optional) This flag can be used to determine whether the 'Billing information' page is shown on the Webpayments UI",
              "example": true,
              "default": true
            },
            {
              "name": "hideReviewInfo",
              "kind": "optional",
              "type": "boolean",
              "description": "(Optional) This flag can be used to determine whether the 'Review and Confirm' page is shown on the Webpayments UI",
              "example": true,
              "default": true
            },
            {
              "name": "disableNetworkTokenisation",
              "kind": "optional",
              "type": "boolean",
              "description": "(Optional) Set to true to specify that network tokenisation should not be used for the associated\ntransaction, even if network token registration has been enabled on the account.\n",
              "example": true,
              "default": false
            },
            {
              "name": "primaryAccountDetails",
              "kind": "optional",
              "type": "object",
              "description": "Information about the primary account holder of the transaction.  Used for MCC 6012, MCC 6051 and MCC 7299 accounts only.  Does not need to be specified if these details were set on a payment session associated with this transaction.",
              "example": "",
              "schema": [
                {
                  "name": "name",
                  "kind": "required",
                  "type": "string",
                  "description": "Surname of the recipient as registered with the account.",
                  "example": "Doe"
                },
                {
                  "name": "accountNumber",
                  "kind": "required",
                  "type": "string",
                  "description": "Up to the first 10 digits of the primary account number of the recipient.",
                  "example": "12345678"
                },
                {
                  "name": "dateOfBirth",
                  "kind": "required",
                  "type": "string",
                  "description": "Date of birth of the recipient in yyyy-mm-dd format. If the recipient is a business, then the\nvalue should be set to \"0000-00-00\"\n",
                  "example": "1980-01-31"
                },
                {
                  "name": "postCode",
                  "kind": "required",
                  "type": "string",
                  "description": "Postcode registered against the recipient's account.",
                  "example": "AB1 2CD"
                }
              ]
            },
            {
              "name": "allowIncrement",
              "kind": "optional",
              "type": "boolean",
              "description": "Set to true to create a session for customer initiated pre-auths that allow the merchant to increment\nthe amount before it is fully collected.\n",
              "example": true
            }
          ],
          "modelRef": "#/components/schemas/paymentSessionRequestForPreAuths",
          "complexItems": [
            {
              "name": "object",
              "schema": [
                {
                  "name": "judoId",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique merchant and/or location ID supplied by Judopay.  Do not include spaces or dashes.  If not specified, then your default judoId will be used.",
                  "example": "100100100"
                },
                {
                  "name": "yourConsumerReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Unique reference to anonymously identify your customer.  Advisable to use GUIDs.",
                  "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                },
                {
                  "name": "yourPaymentReference",
                  "kind": "required",
                  "type": "string",
                  "description": "REQUIRED. Your unique reference for this payment. This value should be unique in order to protect your customers against duplicate transactions. With a server side integration, if a payment reference is not supplied, the transaction will not be processed.",
                  "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
                },
                {
                  "name": "yourPaymentMetaData",
                  "kind": "required",
                  "type": "object",
                  "description": "Optional key-value map for additional metadata associated with this transaction.   Will be stored but not processed or passed to gateways.   Do not include sensitive information like card numbers.",
                  "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                  "schema": []
                },
                {
                  "name": "currency",
                  "kind": "required",
                  "type": "string",
                  "description": "The ISO-4217 alphabetic code for the currency to use for the transaction, only required if different from the currency set during onboarding (default is GBP)",
                  "example": "GBP"
                },
                {
                  "name": "amount",
                  "kind": "optional",
                  "type": "number<float>",
                  "description": "The amount to process. Format for default currencies is to two decimal places.  For currencies using a different structure please contact Judopay for support.",
                  "example": 10.99
                },
                {
                  "name": "cardAddress",
                  "kind": "optional",
                  "type": "object",
                  "description": "",
                  "modelRef": "#/components/schemas/cardAddressWebPaymentRequest",
                  "customType": "cardAddressWebPaymentRequest",
                  "schema": [],
                  "complexType": "allOf",
                  "complexItems": [
                    {
                      "name": "cardAddressRequestAttributes",
                      "description": "",
                      "modelRef": "#/components/schemas/cardAddressRequestAttributes",
                      "schema": [
                        {
                          "name": "address1",
                          "kind": "required",
                          "type": "string",
                          "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder House"
                        },
                        {
                          "name": "address2",
                          "kind": "required",
                          "type": "string",
                          "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                          "example": "1 CardHolder Street"
                        },
                        {
                          "name": "town",
                          "kind": "required",
                          "type": "string",
                          "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                          "example": "CardHolder Town"
                        },
                        {
                          "name": "postCode",
                          "kind": "required",
                          "type": "string",
                          "description": "Postcode of the card holder's address.",
                          "example": "AB1 2CD"
                        },
                        {
                          "name": "state",
                          "kind": "required",
                          "type": "string",
                          "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                          "example": "FL"
                        },
                        {
                          "name": "countryCode",
                          "kind": "required",
                          "type": "string",
                          "description": "ISO 3166-1 (3 digit) country code of the card holder's address.",
                          "example": "826"
                        }
                      ]
                    },
                    {
                      "name": "object",
                      "description": "",
                      "schema": [
                        {
                          "name": "cardHolderName",
                          "kind": "optional",
                          "type": "string",
                          "description": "Name of card holder.",
                          "example": "John Doe"
                        }
                      ]
                    }
                  ]
                },
                {
                  "name": "expiryDate",
                  "kind": "optional",
                  "type": "string<date-time>",
                  "description": "Date and time of expiry (default is 30 minutes from creation)",
                  "example": "2026-02-05T16:28:32.8596+00:00"
                },
                {
                  "name": "isPayByLink",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "Flag indicating whether this session should be shown in the Pay By Link section in Portal.",
                  "example": "",
                  "default": false
                },
                {
                  "name": "isJudoAccept",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "Flag indicating whether this session should be shown in the Judo Accept section in Portal.",
                  "example": "",
                  "default": false
                },
                {
                  "name": "successUrl",
                  "kind": "optional",
                  "type": "string",
                  "description": "For web payments, this is the URL to which the customer is redirected if their transaction is successful.  If not set, then the default success url specified on your account is used.\n",
                  "example": "https://my.site.com/success"
                },
                {
                  "name": "cancelUrl",
                  "kind": "optional",
                  "type": "string",
                  "description": "For web payments, this is the URL to which the customer is redirected if they cancel the transaction or if the transaction fails.  If not set, then the default cancel url specified on your account is used.\n",
                  "example": "https://my.site.com/cancel"
                },
                {
                  "name": "emailAddress",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Email address of consumer, recommended but not required for 3DS2 authentication.",
                  "example": "test.user@judopay.com"
                },
                {
                  "name": "mobileNumber",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Phone number of consumer, recommended for 3DS2 authentication, but not required.   Must be set if phoneCountryCode is set.",
                  "example": "7999999999"
                },
                {
                  "name": "phoneCountryCode",
                  "kind": "optional",
                  "type": "string",
                  "description": "(Optional) Phone country code matching mobileNumber, recommended for 3DS2 authentication, but not required.   Should be set if mobileNumber is set, defaulted to 44 if not.",
                  "example": "44",
                  "default": "44"
                },
                {
                  "name": "threeDSecure",
                  "kind": "optional",
                  "type": "object",
                  "description": "",
                  "example": "",
                  "schema": [
                    {
                      "name": "challengeRequestIndicator",
                      "kind": "optional",
                      "type": "string",
                      "description": "Indicates whether a challenge is requested for this transaction (this may be over-ruled by the issuer).   Should not be specified in the same request as scaExemption\n",
                      "example": "challengePreferred",
                      "default": "noPreference",
                      "modelRef": "#/components/schemas/challengeRequestIndicatorRequest",
                      "customType": "challengeRequestIndicatorRequest",
                      "schema": []
                    },
                    {
                      "name": "scaExemption",
                      "kind": "optional",
                      "type": "string",
                      "description": "Indicates reason why challenge may not be necessary (this may be over-ruled by the issuer).   Should not be specified in the same request as challengeRequestIndicator\n",
                      "example": "transactionRiskAnalysis",
                      "modelRef": "#/components/schemas/scaExemptionRequest",
                      "customType": "scaExemptionRequest",
                      "schema": []
                    }
                  ]
                },
                {
                  "name": "hideBillingInfo",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "(Optional) This flag can be used to determine whether the 'Billing information' page is shown on the Webpayments UI",
                  "example": true,
                  "default": true
                },
                {
                  "name": "hideReviewInfo",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "(Optional) This flag can be used to determine whether the 'Review and Confirm' page is shown on the Webpayments UI",
                  "example": true,
                  "default": true
                },
                {
                  "name": "disableNetworkTokenisation",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "(Optional) Set to true to specify that network tokenisation should not be used for the associated\ntransaction, even if network token registration has been enabled on the account.\n",
                  "example": true,
                  "default": false
                },
                {
                  "name": "primaryAccountDetails",
                  "kind": "optional",
                  "type": "object",
                  "description": "Information about the primary account holder of the transaction.  Used for MCC 6012, MCC 6051 and MCC 7299 accounts only.  Does not need to be specified if these details were set on a payment session associated with this transaction.",
                  "example": "",
                  "schema": [
                    {
                      "name": "name",
                      "kind": "required",
                      "type": "string",
                      "description": "Surname of the recipient as registered with the account.",
                      "example": "Doe"
                    },
                    {
                      "name": "accountNumber",
                      "kind": "required",
                      "type": "string",
                      "description": "Up to the first 10 digits of the primary account number of the recipient.",
                      "example": "12345678"
                    },
                    {
                      "name": "dateOfBirth",
                      "kind": "required",
                      "type": "string",
                      "description": "Date of birth of the recipient in yyyy-mm-dd format. If the recipient is a business, then the\nvalue should be set to \"0000-00-00\"\n",
                      "example": "1980-01-31"
                    },
                    {
                      "name": "postCode",
                      "kind": "required",
                      "type": "string",
                      "description": "Postcode registered against the recipient's account.",
                      "example": "AB1 2CD"
                    }
                  ]
                }
              ],
              "modelRef": "#/components/schemas/paymentSessionRequest",
              "customType": "paymentSessionRequest"
            },
            {
              "name": "object",
              "schema": [
                {
                  "name": "allowIncrement",
                  "kind": "optional",
                  "type": "boolean",
                  "description": "Set to true to create a session for customer initiated pre-auths that allow the merchant to increment\nthe amount before it is fully collected.\n",
                  "example": true
                }
              ]
            }
          ],
          "complexType": "allOf",
          "isExpanded": true
        }
      ],
      "formDataParameters": [],
      "oAuthParameters": [
        {
          "id": "TokenSecretAuth",
          "name": "TokenSecretAuth",
          "kind": "optional",
          "type": "http",
          "description": "<p>This is the typical authorisation scenario to use, specify your token in Username and secret in Password.</p>\n<p>Sent as Base64 encoded string representing token</p><div></div> in Authorization header.<p></p>",
          "scheme": "basic"
        }
      ]
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "Successful response",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "paymentSessionResponse",
            "schema": [
              {
                "name": "expiryDate",
                "kind": "optional",
                "type": "string<date-time>",
                "description": "Date and time of expiry of payment session",
                "example": "2026-02-05T16:28:32.8596+00:00"
              },
              {
                "name": "reference",
                "kind": "optional",
                "type": "string",
                "description": "Judo internal reference for this payment session.",
                "example": "5QcAAAQAAAAPAAAACAAAABtGgvhBrF9BHTN7nqn1e0J4hVVmi-y27dGPjWBMtls3Gj_XDg"
              }
            ],
            "modelRef": "#/components/schemas/paymentSessionResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "400",
        "description": "Bad request (Api-Version header missing, or request body attributes invalid)",
        "jsonExample": "",
        "isExpanded": true
      },
      {
        "statusCode": "401",
        "description": "Unauthorized",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Unauthorized",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "403",
        "description": "Forbidden if token used does not have required permission",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Forbidden",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "ILjn4LFr_gI49IJhyMOoY",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location 'https://api-sandbox.judopay.com/paymentsession' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json' \\\n--header 'Api-Version: string' \\\n--data '{\n  \"judoId\": \"100100100\",\n  \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\",\n  \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n  \"yourPaymentMetaData\": \"{\\\"internalLocationRef\\\":\\\"Example\\\",\\\"internalId\\\":99}\",\n  \"currency\": \"GBP\",\n  \"cardAddress\": {\n    \"address1\": \"CardHolder House\",\n    \"address2\": \"1 CardHolder Street\",\n    \"town\": \"CardHolder Town\",\n    \"postCode\": \"AB1 2CD\",\n    \"state\": \"FL\",\n    \"countryCode\": \"826\"\n  },\n  \"phoneCountryCode\": \"44\",\n  \"threeDSecure\": {\n    \"challengeRequestIndicator\": \"noPreference\"\n  },\n  \"hideBillingInfo\": true,\n  \"hideReviewInfo\": true,\n  \"primaryAccountDetails\": {\n    \"name\": \"Doe\",\n    \"accountNumber\": \"12345678\",\n    \"dateOfBirth\": \"1980-01-31\",\n    \"postCode\": \"AB1 2CD\"\n  }\n}'"
        },
        {
          "id": "ZPujPPNWOPmn5yOgXfT2r",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\nmyHeaders.append(\"Api-Version\", \"string\");\n\nvar raw = JSON.stringify({\n   \"judoId\": \"100100100\",\n   \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\",\n   \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n   \"yourPaymentMetaData\": \"{\\\"internalLocationRef\\\":\\\"Example\\\",\\\"internalId\\\":99}\",\n   \"currency\": \"GBP\",\n   \"cardAddress\": {\n      \"address1\": \"CardHolder House\",\n      \"address2\": \"1 CardHolder Street\",\n      \"town\": \"CardHolder Town\",\n      \"postCode\": \"AB1 2CD\",\n      \"state\": \"FL\",\n      \"countryCode\": \"826\"\n   },\n   \"phoneCountryCode\": \"44\",\n   \"threeDSecure\": {\n      \"challengeRequestIndicator\": \"noPreference\"\n   },\n   \"hideBillingInfo\": true,\n   \"hideReviewInfo\": true,\n   \"primaryAccountDetails\": {\n      \"name\": \"Doe\",\n      \"accountNumber\": \"12345678\",\n      \"dateOfBirth\": \"1980-01-31\",\n      \"postCode\": \"AB1 2CD\"\n   }\n});\n\nvar requestOptions = {\n   method: 'POST',\n   headers: myHeaders,\n   body: raw,\n   redirect: 'follow'\n};\n\nfetch(\"https://api-sandbox.judopay.com/paymentsession\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "msiN0VEluyLsST_GlnzEb",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api-sandbox.judopay.com/paymentsession\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Post.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\nrequest[\"Api-Version\"] = \"string\"\nrequest.body = JSON.dump({\n   \"judoId\": \"100100100\",\n   \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\",\n   \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n   \"yourPaymentMetaData\": \"{\\\"internalLocationRef\\\":\\\"Example\\\",\\\"internalId\\\":99}\",\n   \"currency\": \"GBP\",\n   \"cardAddress\": {\n      \"address1\": \"CardHolder House\",\n      \"address2\": \"1 CardHolder Street\",\n      \"town\": \"CardHolder Town\",\n      \"postCode\": \"AB1 2CD\",\n      \"state\": \"FL\",\n      \"countryCode\": \"826\"\n   },\n   \"phoneCountryCode\": \"44\",\n   \"threeDSecure\": {\n      \"challengeRequestIndicator\": \"noPreference\"\n   },\n   \"hideBillingInfo\": true,\n   \"hideReviewInfo\": true,\n   \"primaryAccountDetails\": {\n      \"name\": \"Doe\",\n      \"accountNumber\": \"12345678\",\n      \"dateOfBirth\": \"1980-01-31\",\n      \"postCode\": \"AB1 2CD\"\n   }\n})\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "tboO_oc5KjcnPLbXNMtKX",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api-sandbox.judopay.com/paymentsession\"\n\npayload = json.dumps({\n   \"judoId\": \"100100100\",\n   \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\",\n   \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n   \"yourPaymentMetaData\": \"{\\\"internalLocationRef\\\":\\\"Example\\\",\\\"internalId\\\":99}\",\n   \"currency\": \"GBP\",\n   \"cardAddress\": {\n      \"address1\": \"CardHolder House\",\n      \"address2\": \"1 CardHolder Street\",\n      \"town\": \"CardHolder Town\",\n      \"postCode\": \"AB1 2CD\",\n      \"state\": \"FL\",\n      \"countryCode\": \"826\"\n   },\n   \"phoneCountryCode\": \"44\",\n   \"threeDSecure\": {\n      \"challengeRequestIndicator\": \"noPreference\"\n   },\n   \"hideBillingInfo\": True,\n   \"hideReviewInfo\": True,\n   \"primaryAccountDetails\": {\n      \"name\": \"Doe\",\n      \"accountNumber\": \"12345678\",\n      \"dateOfBirth\": \"1980-01-31\",\n      \"postCode\": \"AB1 2CD\"\n   }\n})\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json',\n   'Api-Version': 'string'\n}\n\nresponse = requests.request(\"POST\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "ILjn4LFr_gI49IJhyMOoY"
    },
    "results": {
      "languages": [
        {
          "id": "aiXaM8c6XAJwD9axmieWX",
          "language": "200",
          "code": "// Successful response \n{\n  \"expiryDate\": \"2026-02-05T16:28:32.8596+00:00\",\n  \"reference\": \"5QcAAAQAAAAPAAAACAAAABtGgvhBrF9BHTN7nqn1e0J4hVVmi-y27dGPjWBMtls3Gj_XDg\"\n}"
        },
        {
          "id": "Mn3GAA5XD49yDVkYc78OW",
          "language": "400",
          "code": "// Bad request (Api-Version header missing, or request body attributes invalid) \n"
        },
        {
          "id": "w0dILPqLbXha8j8IY80e7",
          "language": "401",
          "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Unauthorized",
              "code": ""
            }
          ]
        },
        {
          "id": "xTohH6husivfLdCwESpw2",
          "language": "403",
          "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Forbidden",
              "code": ""
            }
          ]
        }
      ],
      "selectedLanguageId": "aiXaM8c6XAJwD9axmieWX"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}