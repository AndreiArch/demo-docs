---
title: Retrieve the details of a single payment session for a preauth
createdAt: Tue Feb 03 2026 08:50:33 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:51:00 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "-_K6GJd8pewYEA_HXE5aS",
  "type": "api-oas-v2",
  "data": {
    "method": "GET",
    "url": "https://api-sandbox.judopay.com/webpayments/preauths/{reference}",
    "servers": [
      {
        "url": "https://api-sandbox.judopay.com/webpayments/preauths/{reference}",
        "description": "Sandbox environment"
      }
    ],
    "name": "Retrieve the details of a single payment session for a preauth",
    "description": "<p>Return the details of a single payment session associated with a pre-authorisation with the given reference.</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [
        {
          "kind": "required",
          "name": "reference",
          "type": "string",
          "example": "5QcAAAMAAAAKAAAACwAAADFDcIhHlx3-cY5r3uSHYqRSp-Mliyb_6iBtmJfkgy4pUWDeRg",
          "description": "<p>Judo reference for a payment session, returned in response to creation of session.</p>"
        }
      ],
      "headerParameters": [
        {
          "kind": "required",
          "name": "Api-Version",
          "type": "string",
          "example": "6.23",
          "description": "The version of this API."
        }
      ],
      "queryParameters": [],
      "bodyDataParameters": [],
      "formDataParameters": [],
      "oAuthParameters": [
        {
          "id": "TokenSecretAuth",
          "name": "TokenSecretAuth",
          "kind": "optional",
          "type": "http",
          "description": "<p>This is the typical authorisation scenario to use, specify your token in Username and secret in Password.</p>\n<p>Sent as Base64 encoded string representing token</p><div></div> in Authorization header.<p></p>",
          "scheme": "basic"
        }
      ]
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "Successful response",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "paymentSessionHistoricResponse",
            "schema": [
              {
                "name": "amount",
                "kind": "optional",
                "type": "number<float>",
                "description": "The amount to process. Format for default currencies is to two decimal places.  For currencies using a different structure please contact Judopay for support.\n",
                "example": 10.99
              },
              {
                "name": "cardAddress",
                "kind": "optional",
                "type": "object",
                "description": "",
                "complexType": "allOf",
                "complexItems": [
                  {
                    "name": "cardAddressResponseAttributes",
                    "description": "",
                    "modelRef": "#/components/schemas/cardAddressResponseAttributes",
                    "schema": [
                      {
                        "name": "address1",
                        "kind": "required",
                        "type": "string",
                        "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                        "example": "CardHolder House"
                      },
                      {
                        "name": "address2",
                        "kind": "required",
                        "type": "string",
                        "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                        "example": "1 CardHolder Street"
                      },
                      {
                        "name": "town",
                        "kind": "required",
                        "type": "string",
                        "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                        "example": "CardHolder Town"
                      },
                      {
                        "name": "postCode",
                        "kind": "required",
                        "type": "string",
                        "description": "Postcode of the card holder's address.",
                        "example": "AB1 2CD"
                      },
                      {
                        "name": "state",
                        "kind": "required",
                        "type": "string",
                        "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                        "example": "FL"
                      },
                      {
                        "name": "countryCode",
                        "kind": "required",
                        "type": "integer",
                        "description": "ISO 3166-1 (3 digit) country code of the card holder's address.   If the first digit of the\nof the code is 0 this will not be shown\n",
                        "example": 826
                      }
                    ]
                  },
                  {
                    "name": "object",
                    "description": "",
                    "schema": [
                      {
                        "name": "cardHolderName",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of card holder.",
                        "example": "John Doe"
                      }
                    ]
                  }
                ],
                "schema": []
              },
              {
                "name": "clientIpAddress",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] IP address of caller, if provided in the session creation\n",
                "example": "1.2.3.4"
              },
              {
                "name": "clientUserAgent",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] User agent of caller, if provided in the session creation\n",
                "example": "Mozilla/5.0"
              },
              {
                "name": "companyName",
                "kind": "optional",
                "type": "string",
                "description": "Trading name associated with JudoId specified for this session\n",
                "example": "Test Merchant"
              },
              {
                "name": "currency",
                "kind": "optional",
                "type": "string",
                "description": "The ISO-4217 alphabetic code for the currency associated with the payment session",
                "example": "GBP"
              },
              {
                "name": "expiryDate",
                "kind": "optional",
                "type": "string<date-time>",
                "description": "Date and time of expiry of payment session",
                "example": "2026-02-05T16:28:32.8596+00:00"
              },
              {
                "name": "judoId",
                "kind": "optional",
                "type": "string",
                "description": "Unique merchant and/or location ID supplied by Judopay used for this session\n",
                "example": "100100100"
              },
              {
                "name": "paymentCancelUrl",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] Merchant page to POST to after unsuccessful hosted web payment operations using this payment session, if defined on the API application associated with the authentication details\n",
                "example": "https://my.web.site/cancel"
              },
              {
                "name": "paymentSuccessUrl",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] Merchant page to POST to after successful hosted web payment operations using this payment session, if defined on the API application associated with the authentication details\n",
                "example": "https://my.web.site/success"
              },
              {
                "name": "reference",
                "kind": "optional",
                "type": "string",
                "description": "Unique Judo generated reference for this payment session",
                "example": "5QcAAAIAAAAMAAAADwAAAPwlgcQCLU6sLrNhi8kt1vEoVLwiFJc2EKTqT7JXb2xeQRqyYw"
              },
              {
                "name": "allowedCardTyes",
                "kind": "optional",
                "type": "array",
                "description": "List of integer codes matching card types defined on https://docs.judopay.com/Content/Developer_Tools/Codes.htm?Highlight=codes#Card\n",
                "example": "[1,2,3,10,11,12]",
                "itemType": "integer",
                "customType": "integer[]",
                "itemExample": "",
                "itemDefault": ""
              },
              {
                "name": "response",
                "kind": "optional",
                "type": "object",
                "description": "Details provided when payment session was first created.\n",
                "example": "",
                "schema": [
                  {
                    "name": "postUrl",
                    "kind": "optional",
                    "type": "string",
                    "description": "Prefix of URL directing to Judo hosted Web Payments user interface",
                    "example": "https://pay-sandbox.judopay.com/v2"
                  },
                  {
                    "name": "reference",
                    "kind": "optional",
                    "type": "string",
                    "description": "Suffix to above URL to identify web payment",
                    "example": "5QcAAAIAAAAMAAAADwAAAPwlgcQCLU6sLrNhi8kt1vEoVLwiFJc2EKTqT7JXb2xeQRqyYw"
                  }
                ]
              },
              {
                "name": "status",
                "kind": "optional",
                "type": "string<Open | Success | Expired | Cancelled>",
                "description": "Current state of the payment session",
                "example": "Success"
              },
              {
                "name": "transactionType",
                "kind": "optional",
                "type": "string<Payment | PreAuth | CheckCard | >",
                "description": "[Conditional] Intended use of payment session, if specified on creation\n",
                "example": "PreAuth"
              },
              {
                "name": "yourConsumerReference",
                "kind": "optional",
                "type": "string",
                "description": "Your unique reference to anonymously identify your customer for this session",
                "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
              },
              {
                "name": "yourPaymentMetaData",
                "kind": "optional",
                "type": "object",
                "description": "[Conditional] Key-value map for additional metadata associated with this transaction, if specified on session creation\n",
                "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                "schema": []
              },
              {
                "name": "yourPaymentReference",
                "kind": "optional",
                "type": "string",
                "description": "Your unique reference for this payment session",
                "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
              },
              {
                "name": "receipt",
                "kind": "optional",
                "type": "object",
                "description": "",
                "modelRef": "#/components/schemas/transactionReceiptHistoricResponse",
                "customType": "transactionReceiptHistoricResponse",
                "schema": [
                  {
                    "name": "receiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "Judopay's reference for the transaction.",
                    "example": "1001131610340495360"
                  },
                  {
                    "name": "originalReceiptId",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Judopay's reference for any linked transaction (for collections, refunds and voids)\n",
                    "example": "1001124307998347264"
                  },
                  {
                    "name": "yourPaymentReference",
                    "kind": "optional",
                    "type": "string",
                    "description": "Your unique reference for this payment.",
                    "example": "6482c678-cad3-4efd-b081-aeae7a89a134"
                  },
                  {
                    "name": "type",
                    "kind": "optional",
                    "type": "string<Payment | Refund | PreAuth | VOID | Collection | Save | Register | CheckCard>",
                    "description": "The type of the transaction.",
                    "example": "PreAuth"
                  },
                  {
                    "name": "createdAt",
                    "kind": "optional",
                    "type": "string<date-time>",
                    "description": "Date and time of creation.",
                    "example": "2025-02-05T16:28:32.8596+00:00"
                  },
                  {
                    "name": "result",
                    "kind": "optional",
                    "type": "string",
                    "description": "Result of transaction.",
                    "example": "Success"
                  },
                  {
                    "name": "message",
                    "kind": "optional",
                    "type": "string",
                    "description": "Message detailing the outcome.",
                    "example": "AuthCode: 123456"
                  },
                  {
                    "name": "judoId",
                    "kind": "optional",
                    "type": "integer",
                    "description": "Unique merchant and/or location ID supplied by Judopay.",
                    "example": 100100100
                  },
                  {
                    "name": "merchantName",
                    "kind": "optional",
                    "type": "string",
                    "description": "Merchant's trading name.",
                    "example": "Test Merchant"
                  },
                  {
                    "name": "appearsOnStatementAs",
                    "kind": "optional",
                    "type": "string",
                    "description": "Merchant description as it appears on the consumer's statement.",
                    "example": "APL*/TestMerchant       "
                  },
                  {
                    "name": "originalAmount",
                    "kind": "optional",
                    "type": "string",
                    "description": "Amount of original transaction (not affected by refunds or collections).",
                    "example": "10.99"
                  },
                  {
                    "name": "amountCollected",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional - PreAuth and Register only] Amount that has been collected on original pre-authorisation.\n",
                    "example": "1.99"
                  },
                  {
                    "name": "netAmount",
                    "kind": "optional",
                    "type": "string",
                    "description": "For payments and refunds, this is the original sale amount mines the total of all refunds.   For preauths,\nincremental auths and collections, this is the original preauth amount plus the total of all incremental\nauths minus the total of all collections.  For voids, this is equal to the original preauth amount.\n",
                    "example": "1.00"
                  },
                  {
                    "name": "amount",
                    "kind": "optional",
                    "type": "string",
                    "description": "The amount of this transaction, for refunds and collections the amount that has been refunded or collected in this transaction.",
                    "example": "1.00"
                  },
                  {
                    "name": "currency",
                    "kind": "optional",
                    "type": "string",
                    "description": "The ISO-217 alphabetic code of the currency of the transaction",
                    "example": "GBP"
                  },
                  {
                    "name": "recurringPaymentType",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Type of recurring payment (RECURRING for scheduled, MIT for non-scheduled)\n",
                    "example": "MIT"
                  },
                  {
                    "name": "acquirerTransactionId",
                    "kind": "optional",
                    "type": "string",
                    "description": "The unique ID of the transaction set by the acquirer.",
                    "example": "33666277256892153705"
                  },
                  {
                    "name": "externalBankResponseCode",
                    "kind": "optional",
                    "type": "string",
                    "description": "Response code set by the acquirer.",
                    "example": "A"
                  },
                  {
                    "name": "authCode",
                    "kind": "optional",
                    "type": "string",
                    "description": "Authorisation code set by acquirer",
                    "example": "123456"
                  },
                  {
                    "name": "postCodeCheckResult",
                    "kind": "optional",
                    "type": "string",
                    "description": "Show results of post code checks\n",
                    "example": "Passed"
                  },
                  {
                    "name": "walletType",
                    "kind": "optional",
                    "type": "integer",
                    "description": "[Conditional] For digital wallet transactions, the type of wallet (1=ApplePay, 2=AndroidPay, 4=GooglePay)\n",
                    "example": 1
                  },
                  {
                    "name": "acquirer",
                    "kind": "optional",
                    "type": "string",
                    "description": "Name of acquirer\n",
                    "example": "MyBank"
                  },
                  {
                    "name": "webPaymentReference",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Judo identifier for associated web payment reference (if the transaction was associated with a payment session)\n",
                    "example": "5QcAAAMAAAASAAAADAAAAHaKm0p0p-Ew6VrBhPxjxvMLinJOMZEJWG_K7kJ53UdvRGQ3qA"
                  },
                  {
                    "name": "noOfAuthAttempts",
                    "kind": "optional",
                    "type": "integer",
                    "description": "[Conditional] This indicates the number of authentication attempts made for transactions using the associated payment session reference.\n",
                    "example": 1
                  },
                  {
                    "name": "paymentNetworkTransactionId",
                    "kind": "optional",
                    "type": "string",
                    "description": "[Conditional] Unique identifier of the transaction returned by the payment network/ card scheme.\n",
                    "example": "123456789012345"
                  },
                  {
                    "name": "allowIncrement",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true for customer initiated pre-auths that had the allowIncrement request attribute set to true\n",
                    "example": true
                  },
                  {
                    "name": "isIncrementalAuth",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true for calls to POST /transactions/incrementalAuth\n",
                    "example": true
                  },
                  {
                    "name": "disableNetworkTokenisation",
                    "kind": "optional",
                    "type": "boolean",
                    "description": "[Conditional] true if the request explicitly disabled network tokens for this transaction\n",
                    "example": true
                  },
                  {
                    "name": "cardDetails",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/cardDetailsResponse",
                    "customType": "cardDetailsResponse",
                    "schema": [
                      {
                        "name": "cardLastfour",
                        "kind": "optional",
                        "type": "string",
                        "description": "Last four digits of card",
                        "example": "1234"
                      },
                      {
                        "name": "endDate",
                        "kind": "optional",
                        "type": "string",
                        "description": "Card expiry date in format MMYY",
                        "example": "1225"
                      },
                      {
                        "name": "cardToken",
                        "kind": "optional",
                        "type": "string",
                        "description": "Tokenized representation of card which can be used in future transactions instead of card number",
                        "example": "Ck3AeNlBfjvs9d61MNZiG0gtCvijqvKr"
                      },
                      {
                        "name": "cardType",
                        "kind": "optional",
                        "type": "integer",
                        "description": "Integer representing the type of card, see Reference Codes - Card Types on https://docs.judopay.com/Content/Developer%20Tools/Codes.htm#CardTypes",
                        "example": 2
                      },
                      {
                        "name": "startDate",
                        "kind": "optional",
                        "type": "string",
                        "description": "Card start date in format MMYY",
                        "example": "0121"
                      },
                      {
                        "name": "cardScheme",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of card scheme (determined from matching start of card number against issuer data)",
                        "example": "Mastercard"
                      },
                      {
                        "name": "cardFunding",
                        "kind": "optional",
                        "type": "string",
                        "description": "Type of card (determined from matching start of card number against issuer data)",
                        "example": "Credit"
                      },
                      {
                        "name": "cardCategory",
                        "kind": "optional",
                        "type": "string",
                        "description": "Category of card (determined from matching start of card number against issuer data)",
                        "example": "Acquirer Only"
                      },
                      {
                        "name": "cardCountry",
                        "kind": "optional",
                        "type": "string",
                        "description": "ISO 3166-1 alpha-2 code of country that issued the card (determined from matching start of card number against issuer data)",
                        "example": "GB"
                      },
                      {
                        "name": "bank",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of bank that issued the card (determined from matching start of card number against issuer data)",
                        "example": "Santander Uk Plc"
                      },
                      {
                        "name": "cardHolderName",
                        "kind": "optional",
                        "type": "string",
                        "description": "Name of card holder as supplied on request",
                        "example": "John Doe"
                      },
                      {
                        "name": "ownerType",
                        "kind": "optional",
                        "type": "string<Personal | Commercial | >",
                        "description": "[Conditional] Indicator of whether a card is personal or commercial, if known\n",
                        "example": "Personal"
                      }
                    ]
                  },
                  {
                    "name": "billingAddress",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/cardAddressResponseAttributes",
                    "customType": "cardAddressResponseAttributes",
                    "schema": [],
                    "complexType": "allOf",
                    "complexItems": [
                      {
                        "name": "cardAddressCommonAttributes",
                        "description": "",
                        "modelRef": "#/components/schemas/cardAddressCommonAttributes",
                        "schema": [
                          {
                            "name": "address1",
                            "kind": "optional",
                            "type": "string",
                            "description": "First line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                            "example": "CardHolder House"
                          },
                          {
                            "name": "address2",
                            "kind": "optional",
                            "type": "string",
                            "description": "Second line of the card holder's address.   Max 50 characters for a 3DS2 enabled API token.",
                            "example": "1 CardHolder Street"
                          },
                          {
                            "name": "town",
                            "kind": "optional",
                            "type": "string",
                            "description": "Town of the card holder's address.   Max 40 characters for a 3DS2 enabled API token.",
                            "example": "CardHolder Town"
                          },
                          {
                            "name": "postCode",
                            "kind": "required",
                            "type": "string",
                            "description": "Postcode of the card holder's address.",
                            "example": "AB1 2CD"
                          },
                          {
                            "name": "state",
                            "kind": "optional",
                            "type": "string",
                            "description": "This attribute can be used by merchants to provide state/province/territory ISO codes (2-char alpha) - specifically for countries where this is required as part of the address (Eg: US, Canada, India, China).\n",
                            "example": "FL"
                          }
                        ]
                      },
                      {
                        "name": "object",
                        "description": "",
                        "schema": [
                          {
                            "name": "countryCode",
                            "kind": "optional",
                            "type": "integer",
                            "description": "ISO 3166-1 (3 digit) country code of the card holder's address.   If the first digit of the\nof the code is 0 this will not be shown\n",
                            "example": 826
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "name": "consumer",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/consumerResponse",
                    "customType": "consumerResponse",
                    "schema": [
                      {
                        "name": "yourConsumerReference",
                        "kind": "optional",
                        "type": "string",
                        "description": "Your unique reference to anonymously identify your customer.",
                        "example": "2b45fd3f-cee5-4e7e-874f-28051db65408"
                      }
                    ]
                  },
                  {
                    "name": "device",
                    "kind": "optional",
                    "type": "object",
                    "description": "[Conditional] If clientDetails was provided containing a kdeviceid\n",
                    "modelRef": "#/components/schemas/deviceResponse",
                    "customType": "deviceResponse",
                    "schema": [
                      {
                        "name": "identifier",
                        "kind": "optional",
                        "type": "string",
                        "description": "Judopay generated GUID associated with the kdeviceid passed in the clientDetails request attribute",
                        "example": "d73b4a7b58ce4e54a3bd73b7eda061e6"
                      }
                    ]
                  },
                  {
                    "name": "yourPaymentMetaData",
                    "kind": "optional",
                    "type": "object",
                    "description": "Merchant metadata passed with transaction request.\n",
                    "example": "{\"internalLocationRef\":\"Example\",\"internalId\":99}",
                    "schema": []
                  },
                  {
                    "name": "threeDSecure",
                    "kind": "optional",
                    "type": "object",
                    "description": "[Conditional] Only returned for transactions using 3DS\n",
                    "modelRef": "#/components/schemas/threeDSecureCompletedResponse",
                    "customType": "threeDSecureCompletedResponse",
                    "schema": [
                      {
                        "name": "attempted",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Did the consumer attempt to authenticate through 3DSecure",
                        "example": true
                      },
                      {
                        "name": "result",
                        "kind": "optional",
                        "type": "string",
                        "description": "[Conditional] Outcome of the 3DSecure authentication, only present on initial receipt response, not historic receipts\n",
                        "example": "PASSED"
                      },
                      {
                        "name": "eci",
                        "kind": "optional",
                        "type": "string",
                        "description": "Electronic Commerce Indicator returned by 3DS servers indicating outcome of authentication",
                        "example": "05"
                      },
                      {
                        "name": "challengeRequestIndicator",
                        "kind": "optional",
                        "type": "string<NoPreference | NoChallenge | ChallengePreferred | ChallengeAsMandate | ChallengeWithWhitelistPrompt | >",
                        "description": "[Conditional] Challenge request indicator that was used for 3DS authentication\n",
                        "example": "ChallengeMandated"
                      },
                      {
                        "name": "scaExemption",
                        "kind": "optional",
                        "type": "string<TrustedBeneficiary | TransactionRiskAnalysis | DataShareOnly | ScaAlreadyPerformed | >",
                        "description": "[Conditional] SCA exemption that was used for 3DS authentication\n",
                        "example": ""
                      }
                    ]
                  },
                  {
                    "name": "risks",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/riskParametersResponse",
                    "customType": "riskParametersResponse",
                    "schema": [
                      {
                        "name": "postCodeCheck",
                        "kind": "optional",
                        "type": "string<PASSED | FAILED | UNKNOWN>",
                        "description": "Indication of whether supplied postCode was verified",
                        "example": "PASSED"
                      },
                      {
                        "name": "cv2Check",
                        "kind": "optional",
                        "type": "string<PASSED | FAILED | NOT_PROCESSED | NOT_SUBMITTED | NOT_SUPPORTED | NOT_CHECKED | SUSPICIOUS | UNKNOWN>",
                        "description": "Indication of whether supplied cv2 was verified",
                        "example": "PASSED"
                      },
                      {
                        "name": "merchantSuggestion",
                        "kind": "optional",
                        "type": "string",
                        "description": "Suggestion action for the merchant from the risk engine",
                        "example": "Allow"
                      }
                    ]
                  },
                  {
                    "name": "networkTokenisationDetails",
                    "kind": "optional",
                    "type": "object",
                    "description": "",
                    "modelRef": "#/components/schemas/networkTokenisationDetailsResponse",
                    "customType": "networkTokenisationDetailsResponse",
                    "schema": [
                      {
                        "name": "networkTokenProvisioned",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Indicates if a new network token was created during the course of this transaction",
                        "example": true
                      },
                      {
                        "name": "networkTokenUsed",
                        "kind": "optional",
                        "type": "boolean",
                        "description": "Indicates if this transaction was completed using a network token",
                        "example": true
                      },
                      {
                        "name": "virtualPan",
                        "kind": "optional",
                        "type": "object",
                        "description": "",
                        "example": "",
                        "schema": [
                          {
                            "name": "lastFour",
                            "kind": "optional",
                            "type": "string",
                            "description": "Last four digits of the virtual PAN used",
                            "example": "1234"
                          },
                          {
                            "name": "expiryDate",
                            "kind": "optional",
                            "type": "string",
                            "description": "Expiry date of the virtual PAN in format MMYY",
                            "example": "0129"
                          }
                        ]
                      }
                    ]
                  }
                ]
              },
              {
                "name": "portalUserRecId",
                "kind": "optional",
                "type": "integer",
                "description": "[Conditional] Internal identifier of user who created payment session (if created through Portal or Accept web app)\n",
                "example": 1509318
              },
              {
                "name": "webPaymentOperation",
                "kind": "optional",
                "type": "integer",
                "description": "0 for Payment, 1 for Register",
                "example": 0
              },
              {
                "name": "isPayByLink",
                "kind": "optional",
                "type": "boolean",
                "description": "[Conditional] Only shown if web payment session was created with isPayBLink value set to true\n",
                "example": true
              },
              {
                "name": "isJudoAccept",
                "kind": "optional",
                "type": "boolean",
                "description": "Flag showing whether session was created with isJudoAccept flag (or from POST /judoaccept/payments )\n",
                "example": false
              },
              {
                "name": "isThreeDSecureTwo",
                "kind": "optional",
                "type": "boolean",
                "description": "[Conditional] Only shown when retrieving a single transaction.   Indication of whether session will require additional input for 3DS2 authentication.\n",
                "example": false
              },
              {
                "name": "mobileNumber",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] Only shown when retrieving a single transaction.   Consumer mobile number specified when session was created.\n",
                "example": "07999999999"
              },
              {
                "name": "phoneCountryCode",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] Only shown when retrieving a single transaction.   Consumer phone country code specified when session was created.\n",
                "example": "44"
              },
              {
                "name": "emailAddress",
                "kind": "optional",
                "type": "string",
                "description": "[Conditional] Only shown when retrieving a single transaction.   Consumer email address specified when session was created.\n",
                "example": "test.user@judopay.com"
              },
              {
                "name": "noOfAuthAttempts",
                "kind": "optional",
                "type": "integer",
                "description": "This indicates the number of authentication attempts made for transactions using this payment session.\n",
                "example": 1
              },
              {
                "name": "shortReference",
                "kind": "optional",
                "type": "string",
                "description": "Judopay generated short reference returned in payByLinkUrl when session is first created\n",
                "example": "p5dqOA"
              }
            ],
            "modelRef": "#/components/schemas/paymentSessionHistoricResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "400",
        "description": "Bad request (Api-Version header missing)",
        "jsonExample": "",
        "isExpanded": true
      },
      {
        "statusCode": "401",
        "description": "Unauthorized",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Unauthorized",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "403",
        "description": "Forbidden if token used does not have required permission",
        "jsonExample": "",
        "isExpanded": true,
        "subExamples": [
          {
            "label": "GENERATED",
            "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
          },
          {
            "label": "Forbidden",
            "code": ""
          }
        ],
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "errorResponse",
            "schema": [
              {
                "name": "requestId",
                "kind": "optional",
                "type": "string",
                "description": "Identifier for this request, it is helpful to provide this to Judopay developer support when requesting help with issues.\n",
                "example": ""
              },
              {
                "name": "message",
                "kind": "optional",
                "type": "string",
                "description": "Description of message, intended for issue diagnosis or display to users.   Do not code against this string as it can change without notice.",
                "example": ""
              },
              {
                "name": "code",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with specific error, will not change over time so this can be coded against",
                "example": 0
              },
              {
                "name": "category",
                "kind": "optional",
                "type": "integer",
                "description": "Numeric code associated with category type of error",
                "example": 0
              }
            ],
            "modelRef": "#/components/schemas/errorResponse",
            "isExpanded": true
          }
        ]
      },
      {
        "statusCode": "404",
        "description": "Reference not found, or doesn't match authentication details, or not for a preauth",
        "jsonExample": "",
        "isExpanded": true
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "pzJlcfcWJQjOnLgSsL5jR",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --globoff 'https://api-sandbox.judopay.com/webpayments/preauths/{reference}' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json' \\\n--header 'Api-Version: string'"
        },
        {
          "id": "Mj3kKjFMKc67WwcJF_MfV",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\nmyHeaders.append(\"Api-Version\", \"string\");\n\nvar requestOptions = {\n   method: 'GET',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api-sandbox.judopay.com/webpayments/preauths/{reference}\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "cFwkZCrpdGqnTfDasKxxr",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api-sandbox.judopay.com/webpayments/preauths/{reference}\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Get.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\nrequest[\"Api-Version\"] = \"string\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "m8SmuglZl0iMrFGGS-Qlp",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api-sandbox.judopay.com/webpayments/preauths/{reference}\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json',\n   'Api-Version': 'string'\n}\n\nresponse = requests.request(\"GET\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "pzJlcfcWJQjOnLgSsL5jR"
    },
    "results": {
      "languages": [
        {
          "id": "Z4IN-HiTO5n4Y9I8XamzF",
          "language": "200",
          "code": "// Successful response \n{\n  \"amount\": 10.99,\n  \"cardAddress\": {},\n  \"clientIpAddress\": \"1.2.3.4\",\n  \"clientUserAgent\": \"Mozilla/5.0\",\n  \"companyName\": \"Test Merchant\",\n  \"currency\": \"GBP\",\n  \"expiryDate\": \"2026-02-05T16:28:32.8596+00:00\",\n  \"judoId\": \"100100100\",\n  \"paymentCancelUrl\": \"https://my.web.site/cancel\",\n  \"paymentSuccessUrl\": \"https://my.web.site/success\",\n  \"reference\": \"5QcAAAIAAAAMAAAADwAAAPwlgcQCLU6sLrNhi8kt1vEoVLwiFJc2EKTqT7JXb2xeQRqyYw\",\n  \"allowedCardTyes\": [\n    0\n  ],\n  \"response\": {\n    \"postUrl\": \"https://pay-sandbox.judopay.com/v2\",\n    \"reference\": \"5QcAAAIAAAAMAAAADwAAAPwlgcQCLU6sLrNhi8kt1vEoVLwiFJc2EKTqT7JXb2xeQRqyYw\"\n  },\n  \"status\": \"Success\",\n  \"transactionType\": \"PreAuth\",\n  \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\",\n  \"yourPaymentMetaData\": {},\n  \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n  \"receipt\": {\n    \"receiptId\": \"1001131610340495360\",\n    \"originalReceiptId\": \"1001124307998347264\",\n    \"yourPaymentReference\": \"6482c678-cad3-4efd-b081-aeae7a89a134\",\n    \"type\": \"PreAuth\",\n    \"createdAt\": \"2025-02-05T16:28:32.8596+00:00\",\n    \"result\": \"Success\",\n    \"message\": \"AuthCode: 123456\",\n    \"judoId\": 100100100,\n    \"merchantName\": \"Test Merchant\",\n    \"appearsOnStatementAs\": \"APL*/TestMerchant       \",\n    \"originalAmount\": \"10.99\",\n    \"amountCollected\": \"1.99\",\n    \"netAmount\": \"1.00\",\n    \"amount\": \"1.00\",\n    \"currency\": \"GBP\",\n    \"recurringPaymentType\": \"MIT\",\n    \"acquirerTransactionId\": \"33666277256892153705\",\n    \"externalBankResponseCode\": \"A\",\n    \"authCode\": \"123456\",\n    \"postCodeCheckResult\": \"Passed\",\n    \"walletType\": 1,\n    \"acquirer\": \"MyBank\",\n    \"webPaymentReference\": \"5QcAAAMAAAASAAAADAAAAHaKm0p0p-Ew6VrBhPxjxvMLinJOMZEJWG_K7kJ53UdvRGQ3qA\",\n    \"noOfAuthAttempts\": 1,\n    \"paymentNetworkTransactionId\": \"123456789012345\",\n    \"allowIncrement\": true,\n    \"isIncrementalAuth\": true,\n    \"disableNetworkTokenisation\": true,\n    \"cardDetails\": {\n      \"cardLastfour\": \"1234\",\n      \"endDate\": \"1225\",\n      \"cardToken\": \"Ck3AeNlBfjvs9d61MNZiG0gtCvijqvKr\",\n      \"cardType\": 2,\n      \"startDate\": \"0121\",\n      \"cardScheme\": \"Mastercard\",\n      \"cardFunding\": \"Credit\",\n      \"cardCategory\": \"Acquirer Only\",\n      \"cardCountry\": \"GB\",\n      \"bank\": \"Santander Uk Plc\",\n      \"cardHolderName\": \"John Doe\",\n      \"ownerType\": \"Personal\"\n    },\n    \"billingAddress\": {},\n    \"consumer\": {\n      \"yourConsumerReference\": \"2b45fd3f-cee5-4e7e-874f-28051db65408\"\n    },\n    \"device\": {\n      \"identifier\": \"d73b4a7b58ce4e54a3bd73b7eda061e6\"\n    },\n    \"yourPaymentMetaData\": {},\n    \"threeDSecure\": {\n      \"attempted\": true,\n      \"result\": \"PASSED\",\n      \"eci\": \"05\",\n      \"challengeRequestIndicator\": \"ChallengeMandated\",\n      \"scaExemption\": \"\"\n    },\n    \"risks\": {\n      \"postCodeCheck\": \"PASSED\",\n      \"cv2Check\": \"PASSED\",\n      \"merchantSuggestion\": \"Allow\"\n    },\n    \"networkTokenisationDetails\": {\n      \"networkTokenProvisioned\": true,\n      \"networkTokenUsed\": true,\n      \"virtualPan\": {\n        \"lastFour\": \"1234\",\n        \"expiryDate\": \"0129\"\n      }\n    }\n  },\n  \"portalUserRecId\": 1509318,\n  \"webPaymentOperation\": 0,\n  \"isPayByLink\": true,\n  \"isJudoAccept\": false,\n  \"isThreeDSecureTwo\": false,\n  \"mobileNumber\": \"07999999999\",\n  \"phoneCountryCode\": \"44\",\n  \"emailAddress\": \"test.user@judopay.com\",\n  \"noOfAuthAttempts\": 1,\n  \"shortReference\": \"p5dqOA\"\n}"
        },
        {
          "id": "X4YgtNE0ZciI164ODPsH6",
          "language": "400",
          "code": "// Bad request (Api-Version header missing) \n"
        },
        {
          "id": "0q8lNiyUy3TdkZzXOmUmM",
          "language": "401",
          "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Unauthorized \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Unauthorized",
              "code": ""
            }
          ]
        },
        {
          "id": "yM7SQXPXQNNuTMpSXxhMc",
          "language": "403",
          "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}",
          "subExamples": [
            {
              "label": "GENERATED",
              "code": "// Forbidden if token used does not have required permission \n{\n  \"requestId\": \"\",\n  \"message\": \"\",\n  \"code\": 0,\n  \"category\": 0\n}"
            },
            {
              "label": "Forbidden",
              "code": ""
            }
          ]
        },
        {
          "id": "Ls-rq9xQin7M1AC2D-w4C",
          "language": "404",
          "code": "// Reference not found, or doesn't match authentication details, or not for a preauth \n"
        }
      ],
      "selectedLanguageId": "Z4IN-HiTO5n4Y9I8XamzF"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}