---
title: asdsadas
slug: TduG-asdsadas
createdAt: Wed Nov 12 2025 18:50:22 GMT+0000 (Coordinated Universal Time)
updatedAt: Thu Nov 13 2025 20:03:38 GMT+0000 (Coordinated Universal Time)
---

:::::Tabs
:::Tab{title="About Profile"}
# Profile at a Glance

Whether you’re just getting started or looking for quick tips, this section will guide you through the basics of using Profile. Each article includes links to related topics, so you can explore more when needed.

This section introduces the core features and functions of Profile that support day-to-day use. It covers general information such as logging in and out, locking your screen, navigating between windows, and customising your workspace. You’ll also find guidance on using filters and search tools to locate information, shortcut keys, layout settings to improve efficiency, and more.

These resources are designed to help all users build confidence and stay productive when working in Profile.

***

#

# Get Started

&#x20;

If you would like to know more about general information related to Profile please contact your Customer Success Manager.

***

# Job Aids

Keep key information within reach. Click below to download printable quick-reference guides:

::File[]{src="https://api.archbee.com/api/presign/yxyCW0bG6KQ6__wrIVPMk/27-WyOs0VIkaKdxfAP62l-20251103-210908.pdf" label="JobAid-IntroductionToProfile.pdf"}

***

# Related Articles

Read the related articles below for more general information about Profile:

- [**Logging into Profile**]()&#x20;
- [**Logging Out of Profile**]()&#x20;
- [**Profile Navigation Overview**]()&#x20;
- [**Using Search Across Profile**]()&#x20;
- [**Navigate the Work Centre Window**]()&#x20;
- [**Navigate Medical Records in Profile**]()&#x20;
- [**Work with Profile Windows**]()&#x20;
- [**Use the Clinical Details Window**]()&#x20;
- [**Use Segment Lists and Record Views**]()&#x20;
- [**Insert and Edit Information in Profile**]()&#x20;
- [**Use Filters Across Profile**]()&#x20;
- [**Changing Place of Service**]()&#x20;
- [**Logging Out of Profile**]()&#x20;
- [**Lock your Screen in Profile**]()&#x20;
- [**Save your Profile Windows Settings**]()&#x20;
- [**Switch Between Open Windows in Profile**]()&#x20;
- [**Using Shortcut Keys**]()&#x20;
:::

::::Tab{title="Frequently Asked Questions"}


# Frequently Asked Questions:

***

## Access & Security

:::ExpandableHeading
### Why is it important to log out or lock my Profile session?

Logging out at the end of your session and locking your screen when stepping away ensures that no unauthorised person can access patient information or your workspace.
:::

:::ExpandableHeading
### What’s the difference between logging out and locking my screen?

Logging out ends your session completely. Locking your screen keeps your session open but prevents others from accessing it until you unlock with your credentials.
:::

***

## Windows & Layout

:::ExpandableHeading
### How do I manage multiple Profile windows at once?

You can switch between open windows using the Window menu or by pressing F2. You can also resize, rearrange, and save window settings so your preferred layout loads automatically.
:::

:::ExpandableHeading
### Can I save my window setup so I don’t have to rearrange every time?

Yes. Use **Edit > Defaults > Set Defaults for This Window** to save size, position, and layout. These will be applied automatically when the window reopens.
:::

***

## Navigation & Views

:::ExpandableHeading
### What are segment lists and record views used for?

Segment lists let you switch between categories of information in the Work Centre, while record views display details about a specific selection. Together, they help you organise and access patient or task data efficiently.&#x20;
:::

:::ExpandableHeading
### How do I quickly find the information I need in Profile?&#x20;

Use filters to narrow lists to relevant items, or use search fields to run database-wide searches. Search fields are marked with an ellipsis (…) and allow both direct entry and drop-down selection
:::

***

## Productivity Tools

:::ExpandableHeading
### Are there shortcut keys to speed up my work in Profile?

Yes. Common shortcuts include Ctrl+N (new patient), Ctrl+F (find patients), F2 (switch windows), and F1 (help). Using shortcuts reduces reliance on menus and speeds up data entry.
:::

:::ExpandableHeading
### Can I restore Profile to default settings if I change too much?

Yes, you can reset defaults under the **Edit > Defaults** menu, or manually revert window layouts and filter settings.
:::

***

# Related Articles

Read the related articles below for more general information about Profile:

- [**Logging into Profile**]()&#x20;
- [**Logging Out of Profile**]()&#x20;
- [**Profile Navigation Overview**]()&#x20;
- [**Using Search Across Profile**]()&#x20;
- [**Navigate the Work Centre Window**]()&#x20;
- [**Navigate Medical Records in Profile**]()&#x20;
- [**Work with Profile Windows**]()&#x20;
- [**Use the Clinical Details Window**]()&#x20;
- [**Use Segment Lists and Record Views**]()&#x20;
- [**Insert and Edit Information in Profile**]()&#x20;
- [**Use Filters Across Profile**]()&#x20;
- [**Changing Place of Service**]()&#x20;
- [**Logging Out of Profile**]()&#x20;
- [**Lock your Screen in Profile**]()&#x20;
- [**Save your Profile Windows Settings**]()&#x20;
- [**Switch Between Open Windows in Profile**]()&#x20;
- [**Searching for Patients**]()&#x20;
- [**Using Shortcut Keys**]()&#x20;
::::
:::::

