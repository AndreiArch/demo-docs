---
title: New test
slug: 20JC-ne
createdAt: Mon Jan 12 2026 14:20:58 GMT+0000 (Coordinated Universal Time)
updatedAt: Mon Feb 02 2026 16:17:26 GMT+0000 (Coordinated Universal Time)
---

### Notes (important for Archbee)

- &#x20;accepts a **GET request with a JSON body**, which is why -Method GET and -Body are both used.&#x20;
- ConvertTo-Json is required so PowerShell sends a proper JSON payload.&#x20;
- The response will typically include a **download link** when exportAsLink = true.&#x20;

If you want, I can also:

[**this is a h1 title**](<./this is a h1 title.md>)&#x20;

- Convert this to **POST** (in case Archbee changes behavior)&#x20;
- Add **error handling**&#x20;
- Save the export link directly to a file or trigger a download

$headers = @\{
&#x20;   "Accept"        = "application/json"
&#x20;   "Content-Type"  = "application/json"
&#x20;   "Authorization" = "Bearer SFFfdkhvMEJSLVN2RVRvYXowMkROfkp2NVZwUW5iWXB0VF9XUkxscWZrLQ=="
}

$body = @\{
&#x20;   teamId = "511c8QBH-VHiwWnyzIwUb"
&#x20;   exportThisSpaceOnly = $true
&#x20;   exportAsLink = $true
} | ConvertTo-Json

$response = Invoke-RestMethod \`
&#x20;   -Uri $uri \`
&#x20;   -Method GET \`
&#x20;   -Headers $headers \`
&#x20;   -Body $body
