---
title: test page
slug: VXxi-conditional-repro
createdAt: Fri Dec 05 2025 14:45:17 GMT+0000 (Coordinated Universal Time)
updatedAt: Thu Jan 15 2026 14:45:27 GMT+0000 (Coordinated Universal Time)
---

:::ApiMethodV2
```json
{
  "name": "Get Cakes",
  "method": "GET",
  "url": "https://api.cakes.com",
  "description": "Get a cake by its ID",
  "tab": "examples",
  "examples": {
    "languages": [
      {
        "id": "UZH5cMYhmr1HnGlyImofI",
        "language": "javascript",
        "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\n\nvar raw = JSON.stringify({\n   \"id\": \"String\"\n});\n\nvar requestOptions = {\n   method: 'GET',\n   headers: myHeaders,\n   body: raw,\n   redirect: 'follow'\n};\n\nfetch(\"https://api.cakes.com\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));",
        "customLabel": ""
      }
    ],
    "selectedLanguageId": "UZH5cMYhmr1HnGlyImofI"
  },
  "results": {
    "languages": [
      {
        "id": "bpNTXpDpoY0_3-Ft6xRDd",
        "language": "200",
        "code": "{\n  \"name\": \"Cake's name\",\n}",
        "customLabel": ""
      },
      {
        "id": "dZVgQhprp5-Q3jAFIDOoO",
        "language": "404",
        "code": "{\n  \"message\": \"Ain't no cake like that.\"\n}",
        "customLabel": ""
      }
    ],
    "selectedLanguageId": "bpNTXpDpoY0_3-Ft6xRDd"
  },
  "request": {
    "pathParameters": [],
    "queryParameters": [],
    "headerParameters": [],
    "bodyDataParameters": [
      {
        "name": "id",
        "kind": "required",
        "type": "array",
        "description": "ID of the cake to get",
        "": "array"
      },
      {
        "name": "Parameter name",
        "kind": "optional",
        "type": "object",
        "description": "",
        "": "object",
        "children": [
          {
            "name": "Parameter name",
            "kind": "optional",
            "type": "string",
            "description": ""
          }
        ],
        "schema": [
          {
            "name": "Parameter name",
            "kind": "optional",
            "type": "string",
            "description": ""
          }
        ]
      }
    ],
    "formDataParameters": []
  },
  "currentNewParameter": {
    "label": "Body Parameter",
    "value": "bodyDataParameters"
  },
  "hasTryItOut": false
}
```
:::

