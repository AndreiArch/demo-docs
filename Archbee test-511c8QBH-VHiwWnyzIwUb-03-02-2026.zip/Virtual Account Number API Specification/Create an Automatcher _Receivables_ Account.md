---
title: Create an Automatcher (Receivables) Account
createdAt: Tue Feb 03 2026 08:48:36 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:49:59 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "JFvcvLUdSRykopgznF40F",
  "type": "api-oas-v2",
  "data": {
    "method": "POST",
    "url": "https://api.mpay.com.au/receivables/v1/create",
    "servers": [
      {
        "url": "https://api.mpay.com.au/receivables/v1/create",
        "description": "Production URL"
      },
      {
        "url": "https://api.m-pay.com.au/receivables/v1/create",
        "description": "Sandbox URL"
      }
    ],
    "name": "Create an Automatcher (Receivables) Account",
    "description": "<p>Creates a new virtual account number. These account numbers can be used along with the returned BSB to receive payments from any bank in Australia.\n\nPayments to an invalid bank-account number, i.e. one that has not been created, will be returned by Monoova to the remitting institution. Each account number has a check digit to minimize common payer errors such as adjacent transposition errors or single-digit typos.\n\nAn optional unique ID can be linked to each account number for your reference. If a unique ID is not provided, Monoova will generate and return one automatically.\n\nIf isActive is omitted, it will default to false. This can be changed to true via the /receivables/v1/status endpoint.\n\nFor the creation of batches of account numbers, please see /receivables/v1/batchCreate.</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [],
      "queryParameters": [],
      "bodyDataParameters": [
        {
          "kind": "required",
          "name": "body",
          "type": "object",
          "description": "",
          "customType": "automatcherCreateBody_V1",
          "schema": [],
          "modelRef": "#/components/schemas/automatcherCreateBody_V1",
          "isExpanded": true
        }
      ],
      "formDataParameters": [],
      "oAuthParameters": []
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "successful validation",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "automatcherStatusResponse_V1",
            "schema": [],
            "modelRef": "#/components/schemas/automatcherStatusResponse_V1",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "W63j5CT0gtPBythCHsl-z",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --request POST 'https://api.mpay.com.au/receivables/v1/create' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json'"
        },
        {
          "id": "YJLHvtn5xjT_TSlBoXW7V",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\n\nvar requestOptions = {\n   method: 'POST',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api.mpay.com.au/receivables/v1/create\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "mZHMltYNGzY70_C9Zn_6-",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api.mpay.com.au/receivables/v1/create\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Post.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "HDcObYSztCV0TGSdG0g1q",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api.mpay.com.au/receivables/v1/create\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json'\n}\n\nresponse = requests.request(\"POST\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "W63j5CT0gtPBythCHsl-z"
    },
    "results": {
      "languages": [
        {
          "id": "lodN_Pd1s0GdKh_XeCedM",
          "language": "200",
          "code": "// successful validation \n{}"
        }
      ],
      "selectedLanguageId": "lodN_Pd1s0GdKh_XeCedM"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}