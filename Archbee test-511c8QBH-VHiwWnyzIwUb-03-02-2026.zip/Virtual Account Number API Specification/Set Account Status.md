---
title: Set Account Status
createdAt: Tue Feb 03 2026 08:48:36 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:49:59 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "Rq4wQhKd9CCqmRk_-bXZN",
  "type": "api-oas-v2",
  "data": {
    "method": "POST",
    "url": "https://api.mpay.com.au/receivables/v1/status",
    "servers": [
      {
        "url": "https://api.mpay.com.au/receivables/v1/status",
        "description": "Production URL"
      },
      {
        "url": "https://api.m-pay.com.au/receivables/v1/status",
        "description": "Sandbox URL"
      }
    ],
    "name": "Set Account Status",
    "description": "<p>Update the status of a virtual account. Accounts can be active or inactive. If an account is inactive, all inbound payments will be rejected and returned to the payer.</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [],
      "queryParameters": [],
      "bodyDataParameters": [
        {
          "kind": "required",
          "name": "body",
          "type": "object",
          "description": "",
          "customType": "automatcherStatusBody_V1",
          "schema": [],
          "modelRef": "#/components/schemas/automatcherStatusBody_V1",
          "isExpanded": true
        }
      ],
      "formDataParameters": [],
      "oAuthParameters": []
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "successful validation",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "automatcherStatusResponse_V1",
            "schema": [],
            "modelRef": "#/components/schemas/automatcherStatusResponse_V1",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "EP66jOUj1qGzYDpiOLv6u",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --request POST 'https://api.mpay.com.au/receivables/v1/status' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json'"
        },
        {
          "id": "4Xnxzy3cdN1ArvVY07Sa6",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\n\nvar requestOptions = {\n   method: 'POST',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api.mpay.com.au/receivables/v1/status\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "A-e5Anorx6ld-BuAAQopu",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api.mpay.com.au/receivables/v1/status\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Post.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "SmZjVNuguaiMj38sz3SeL",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api.mpay.com.au/receivables/v1/status\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json'\n}\n\nresponse = requests.request(\"POST\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "EP66jOUj1qGzYDpiOLv6u"
    },
    "results": {
      "languages": [
        {
          "id": "ZFADXBCMHPOHIgmaDqL1e",
          "language": "200",
          "code": "// successful validation \n{}"
        }
      ],
      "selectedLanguageId": "ZFADXBCMHPOHIgmaDqL1e"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}