---
title: Batch Create
createdAt: Tue Feb 03 2026 08:48:36 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:49:59 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "Q0Lgm-DZ7KCaZNepv0hL2",
  "type": "api-oas-v2",
  "data": {
    "method": "POST",
    "url": "https://api.mpay.com.au/receivables/v1/batchCreate",
    "servers": [
      {
        "url": "https://api.mpay.com.au/receivables/v1/batchCreate",
        "description": "Production URL"
      },
      {
        "url": "https://api.m-pay.com.au/receivables/v1/batchCreate",
        "description": "Sandbox URL"
      }
    ],
    "name": "Batch Create",
    "description": "<p>The batch create API has the same functionality as the /receivables/v1/create endpoint however it allows you to create up to 50,000 accounts in a single call by submitting a file. We recommend this for circumstances where more than 100 accounts need to be created within a short time period.\n\nCreation of accounts with isActive=true is restricted to 1000. Multiple batches cannot be requested at the same time, you have to wait for the completion of a batch before requesting a new one.\n\nThe Batch Create API also supports a lightweight option whereby many accounts can be created by submitting a single line. This option automatically sets isActive = true, hence you can only request the creation of 1000 accounts in one request. For this method, all accounts will be created with the same specified name, and clientuniqueidâ€™s cannot be specified will be automatically generated.</p>",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [],
      "queryParameters": [],
      "bodyDataParameters": [],
      "formDataParameters": [],
      "oAuthParameters": []
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "successful validation",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "string<binary>",
            "description": "",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "cr3x0yCHW62e0X4kWA9oe",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --request POST 'https://api.mpay.com.au/receivables/v1/batchCreate' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json'"
        },
        {
          "id": "alZBnZyHmr0rLkOFSxu2E",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\n\nvar requestOptions = {\n   method: 'POST',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api.mpay.com.au/receivables/v1/batchCreate\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "pHNdSBwxS30PNTXo5cRQ8",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api.mpay.com.au/receivables/v1/batchCreate\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Post.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "1BtXcZkYiqTNsUL4uTLaf",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api.mpay.com.au/receivables/v1/batchCreate\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json'\n}\n\nresponse = requests.request(\"POST\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "cr3x0yCHW62e0X4kWA9oe"
    },
    "results": {
      "languages": [
        {
          "id": "dImu7OzJ9Tjg23J1K7pqL",
          "language": "200",
          "code": "// successful validation \n\"\""
        }
      ],
      "selectedLanguageId": "dImu7OzJ9Tjg23J1K7pqL"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}