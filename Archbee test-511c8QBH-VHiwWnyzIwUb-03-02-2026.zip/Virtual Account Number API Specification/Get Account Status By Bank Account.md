---
title: Get Account Status By Bank Account
createdAt: Tue Feb 03 2026 08:48:36 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:49:59 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "c0Hzf9F7uV9v3UdnAQkk9",
  "type": "api-oas-v2",
  "data": {
    "method": "GET",
    "url": "https://api.mpay.com.au/receivables/v1/statusByBankAccount/{bankAccountNumber}",
    "servers": [
      {
        "url": "https://api.mpay.com.au/receivables/v1/statusByBankAccount/{bankAccountNumber}",
        "description": "Production URL"
      },
      {
        "url": "https://api.m-pay.com.au/receivables/v1/statusByBankAccount/{bankAccountNumber}",
        "description": "Sandbox URL"
      }
    ],
    "name": "Get Account Status By Bank Account",
    "description": "This API is used for checking the status of a bank account using the bank account number. This API will only return statuses for virtual accounts belonging to the parent mAccount.",
    "contentType": "application/json",
    "request": {
      "pathParameters": [
        {
          "kind": "required",
          "name": "bankAccountNumber",
          "type": "string",
          "description": "The account number of the virtual account."
        }
      ],
      "headerParameters": [],
      "queryParameters": [
        {
          "kind": "optional",
          "name": "bsb",
          "type": "string",
          "description": ""
        }
      ],
      "bodyDataParameters": [],
      "formDataParameters": [],
      "oAuthParameters": []
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "successful validation",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "automatcherStatusResponse_V1",
            "schema": [],
            "modelRef": "#/components/schemas/automatcherStatusResponse_V1",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "zr4fzBq4ZDrlkAg71Rkou",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --globoff 'https://api.mpay.com.au/receivables/v1/statusByBankAccount/{bankAccountNumber}' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json'"
        },
        {
          "id": "MDIIkqQFqoSESjh-n4P3o",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\n\nvar requestOptions = {\n   method: 'GET',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api.mpay.com.au/receivables/v1/statusByBankAccount/{bankAccountNumber}\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "AkJ1CA32VrvBO_gpocvwt",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api.mpay.com.au/receivables/v1/statusByBankAccount/{bankAccountNumber}\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Get.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "kJJ1_BKNP3auRor0yvVVw",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api.mpay.com.au/receivables/v1/statusByBankAccount/{bankAccountNumber}\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json'\n}\n\nresponse = requests.request(\"GET\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "zr4fzBq4ZDrlkAg71Rkou"
    },
    "results": {
      "languages": [
        {
          "id": "6a21fM-hBfKVCxLpkB_uE",
          "language": "200",
          "code": "// successful validation \n{}"
        }
      ],
      "selectedLanguageId": "6a21fM-hBfKVCxLpkB_uE"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}