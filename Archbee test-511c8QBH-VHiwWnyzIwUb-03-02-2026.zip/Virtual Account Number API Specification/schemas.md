---
title: schemas
createdAt: Tue Feb 03 2026 08:48:36 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:49:59 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "E84uGcqGhpeZKzUZ-9g7k",
  "type": "api-oas-v2",
  "data": {
    "method": "AUTOMATCHERCREATEBODY_V1",
    "url": "https://api.mpay.com.auschemas",
    "servers": [
      {
        "url": "https://api.mpay.com.auschemas",
        "description": "Production URL"
      },
      {
        "url": "https://api.m-pay.com.auschemas",
        "description": "Sandbox URL"
      }
    ],
    "name": "",
    "description": "",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [],
      "queryParameters": [],
      "bodyDataParameters": [],
      "formDataParameters": [],
      "oAuthParameters": []
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "",
        "jsonExample": ""
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "q4D35FR96Uas3Y1_IwiHJ",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --request AUTOMATCHERCREATEBODY_V1 'https://api.mpay.com.auschemas' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json'"
        },
        {
          "id": "vR8Hp3wJOPIUX9-MWc5T-",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\n\nvar requestOptions = {\n   method: 'AUTOMATCHERCREATEBODY_V1',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api.mpay.com.auschemas\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "Kbd0HNHgEAhX20WvtXf8B",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nclass Net::HTTP::Automatchercreatebody_v1 < Net::HTTPRequest\n   METHOD = \"AUTOMATCHERCREATEBODY_V1\"\n   REQUEST_HAS_BODY = false\n   RESPONSE_HAS_BODY = true\nend\n\nurl = URI(\"https://api.mpay.com.auschemas\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Automatchercreatebody_v1.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "SZf4Uwt4nOBG-G_EW72UP",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api.mpay.com.auschemas\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json'\n}\n\nresponse = requests.request(\"AUTOMATCHERCREATEBODY_V1\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "q4D35FR96Uas3Y1_IwiHJ"
    },
    "results": {
      "languages": [
        {
          "id": "FRv2-yhNcDlcdx8K5aRW2",
          "language": "200",
          "code": ""
        }
      ],
      "selectedLanguageId": "FRv2-yhNcDlcdx8K5aRW2"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}