---
title: Get Account Status By ClientUniqueId
createdAt: Tue Feb 03 2026 08:48:36 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:49:59 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "QPwIBvvge0mto9Xc28urr",
  "type": "api-oas-v2",
  "data": {
    "method": "GET",
    "url": "https://api.mpay.com.au/receivables/v1/statusByClientID/{clientUniqueId}",
    "servers": [
      {
        "url": "https://api.mpay.com.au/receivables/v1/statusByClientID/{clientUniqueId}",
        "description": "Production URL"
      },
      {
        "url": "https://api.m-pay.com.au/receivables/v1/statusByClientID/{clientUniqueId}",
        "description": "Sandbox URL"
      }
    ],
    "name": "Get Account Status By ClientUniqueId",
    "description": "This API is used for checking the status of a bank account using the clientUniqueId provided when the account was created.",
    "contentType": "application/json",
    "request": {
      "pathParameters": [
        {
          "kind": "required",
          "name": "clientUniqueId",
          "type": "string",
          "description": "The identifier assigned to the account when it was created."
        }
      ],
      "headerParameters": [],
      "queryParameters": [
        {
          "kind": "optional",
          "name": "bsb",
          "type": "string",
          "description": ""
        }
      ],
      "bodyDataParameters": [],
      "formDataParameters": [],
      "oAuthParameters": []
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "successful validation",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "object",
            "description": "",
            "customType": "automatcherStatusResponse_V1",
            "schema": [],
            "modelRef": "#/components/schemas/automatcherStatusResponse_V1",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "8kYn36q2ySjgwn9u6qFuc",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --globoff 'https://api.mpay.com.au/receivables/v1/statusByClientID/{clientUniqueId}' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json'"
        },
        {
          "id": "3R2SYYimKTkDldHmg4m73",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\n\nvar requestOptions = {\n   method: 'GET',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api.mpay.com.au/receivables/v1/statusByClientID/{clientUniqueId}\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "oqRKnCiKiKG5TudWvUlLw",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api.mpay.com.au/receivables/v1/statusByClientID/{clientUniqueId}\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Get.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "DjalYw5-rMcdJhIooB_wg",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api.mpay.com.au/receivables/v1/statusByClientID/{clientUniqueId}\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json'\n}\n\nresponse = requests.request(\"GET\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "8kYn36q2ySjgwn9u6qFuc"
    },
    "results": {
      "languages": [
        {
          "id": "BvJn_fEoh8R-sh_kogTNp",
          "language": "200",
          "code": "// successful validation \n{}"
        }
      ],
      "selectedLanguageId": "BvJn_fEoh8R-sh_kogTNp"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}