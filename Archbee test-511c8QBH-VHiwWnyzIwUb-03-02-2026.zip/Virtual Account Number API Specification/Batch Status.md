---
title: Batch Status
createdAt: Tue Feb 03 2026 08:48:36 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:49:59 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "iPmlmHshT_hx1Yo89HelQ",
  "type": "api-oas-v2",
  "data": {
    "method": "POST",
    "url": "https://api.mpay.com.au/receivables/v1/batchStatus",
    "servers": [
      {
        "url": "https://api.mpay.com.au/receivables/v1/batchStatus",
        "description": "Production URL"
      },
      {
        "url": "https://api.m-pay.com.au/receivables/v1/batchStatus",
        "description": "Sandbox URL"
      }
    ],
    "name": "Batch Status",
    "description": "Get the status of a request to the batchCreate endpoint.",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [],
      "queryParameters": [],
      "bodyDataParameters": [],
      "formDataParameters": [],
      "oAuthParameters": []
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "successful validation",
        "jsonExample": "",
        "isExpanded": true,
        "schema": [
          {
            "kind": "optional",
            "type": "string<binary>",
            "description": "",
            "isExpanded": true
          }
        ]
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "ruWht97vvz9mEEpk-TlyJ",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --request POST 'https://api.mpay.com.au/receivables/v1/batchStatus' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json'"
        },
        {
          "id": "4atl-cIGqjASERVZgd73V",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\n\nvar requestOptions = {\n   method: 'POST',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api.mpay.com.au/receivables/v1/batchStatus\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "5Tv7xR0o3aj3s94BSU39d",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nurl = URI(\"https://api.mpay.com.au/receivables/v1/batchStatus\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Post.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "bO_aQEFTB6EE2SPLqeJn7",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api.mpay.com.au/receivables/v1/batchStatus\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json'\n}\n\nresponse = requests.request(\"POST\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "ruWht97vvz9mEEpk-TlyJ"
    },
    "results": {
      "languages": [
        {
          "id": "J7sd1L9A9i3rBXtT4H8DT",
          "language": "200",
          "code": "// successful validation \n\"\""
        }
      ],
      "selectedLanguageId": "J7sd1L9A9i3rBXtT4H8DT"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}