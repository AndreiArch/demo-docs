---
title: securitySchemes
createdAt: Tue Feb 03 2026 08:48:36 GMT+0000 (Coordinated Universal Time)
updatedAt: Tue Feb 03 2026 08:49:59 GMT+0000 (Coordinated Universal Time)
---

{
  "id": "x3EW2ie9jgfS-y4WyokbC",
  "type": "api-oas-v2",
  "data": {
    "method": "BASICAUTH",
    "url": "https://api.mpay.com.ausecuritySchemes",
    "servers": [
      {
        "url": "https://api.mpay.com.ausecuritySchemes",
        "description": "Production URL"
      },
      {
        "url": "https://api.m-pay.com.ausecuritySchemes",
        "description": "Sandbox URL"
      }
    ],
    "name": "",
    "description": "",
    "contentType": "application/json",
    "request": {
      "pathParameters": [],
      "headerParameters": [],
      "queryParameters": [],
      "bodyDataParameters": [],
      "formDataParameters": [],
      "oAuthParameters": []
    },
    "responses": [
      {
        "statusCode": "200",
        "description": "",
        "jsonExample": ""
      }
    ],
    "hasXCodeSamples": false,
    "examples": {
      "languages": [
        {
          "id": "LsnwFUZ0Z6SHaEUQDXNb1",
          "language": "curl",
          "label": "cURL",
          "code": "curl --location --request BASICAUTH 'https://api.mpay.com.ausecuritySchemes' \\\n--header 'Accept: application/json' \\\n--header 'Content-Type: application/json'"
        },
        {
          "id": "rpuQz3ftuYBe5vUscPYrR",
          "language": "javascript",
          "label": "javascript",
          "code": "var myHeaders = new Headers();\nmyHeaders.append(\"Accept\", \"application/json\");\nmyHeaders.append(\"Content-Type\", \"application/json\");\n\nvar requestOptions = {\n   method: 'BASICAUTH',\n   headers: myHeaders,\n   redirect: 'follow'\n};\n\nfetch(\"https://api.mpay.com.ausecuritySchemes\", requestOptions)\n   .then(response => response.text())\n   .then(result => console.log(result))\n   .catch(error => console.log('error', error));"
        },
        {
          "id": "LMsrdnU8T7U8QBPBsVTzQ",
          "language": "ruby",
          "label": "Ruby",
          "code": "require \"uri\"\nrequire \"json\"\nrequire \"net/http\"\n\nclass Net::HTTP::Basicauth < Net::HTTPRequest\n   METHOD = \"BASICAUTH\"\n   REQUEST_HAS_BODY = false\n   RESPONSE_HAS_BODY = true\nend\n\nurl = URI(\"https://api.mpay.com.ausecuritySchemes\")\n\nhttps = Net::HTTP.new(url.host, url.port)\nhttps.use_ssl = true\n\nrequest = Net::HTTP::Basicauth.new(url)\nrequest[\"Accept\"] = \"application/json\"\nrequest[\"Content-Type\"] = \"application/json\"\n\nresponse = https.request(request)\nputs response.read_body\n"
        },
        {
          "id": "Ev5CMa-DRk0YJPKyVkVlN",
          "language": "python",
          "label": "Python",
          "code": "import requests\nimport json\n\nurl = \"https://api.mpay.com.ausecuritySchemes\"\n\npayload = {}\nheaders = {\n   'Accept': 'application/json',\n   'Content-Type': 'application/json'\n}\n\nresponse = requests.request(\"BASICAUTH\", url, headers=headers, data=payload)\n\nprint(response.text)\n"
        }
      ],
      "selectedLanguageId": "LsnwFUZ0Z6SHaEUQDXNb1"
    },
    "results": {
      "languages": [
        {
          "id": "g7UEWQFA7N6_t3YJnZ4AJ",
          "language": "200",
          "code": ""
        }
      ],
      "selectedLanguageId": "g7UEWQFA7N6_t3YJnZ4AJ"
    }
  },
  "children": [
    {
      "text": ""
    }
  ]
}